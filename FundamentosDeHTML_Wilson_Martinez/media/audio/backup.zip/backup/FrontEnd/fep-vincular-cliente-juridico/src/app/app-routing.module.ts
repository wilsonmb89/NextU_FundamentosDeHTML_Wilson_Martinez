import { NgModule, InjectionToken } from '@angular/core';
import { Routes, RouterModule, ActivatedRouteSnapshot } from '@angular/router';
import { NotFoundComponent } from './shared/components/not-found/not-found.component';

const externalUrlProvider = new InjectionToken('externalUrlRedirectResolver');

const routes: Routes = [
  { path: 'task/:taskId/consultar-cliente-juridico', loadChildren: './pages/search-customer/search-customer.module#SearchCustomerModule' },
  { path: 'task/:taskId/cargar-informacion-representante-legal', loadChildren: './pages/legal-representative/legal-representative.module#LegalRepresentativeModule' },
  { path: 'task/:taskId/cargar-informacion-empresa', loadChildren: './pages/company-information/company-information.module#CompanyInformationModule' },
  { path: 'task/:taskId/verificar-documentacion', loadChildren: './pages/check-documents/check-documents.module#CheckDocumentsModule' },
  { path: 'task/:taskId/cargar-informacion-ordenantes', loadChildren: './pages/order-officer/order-officer.module#OrderOfficerModule' },
  { path: 'task/:taskId/cargar-informacion-accionistas', loadChildren: './pages/shareholder/shareholder.module#ShareholderModule' },
  { path: 'task/:taskId/cargar-informacion-terceros', loadChildren: './pages/third-party/third-party.module#ThirdPartyModule' },
  { path: 'task/:taskId/cargar-documentacion', loadChildren: './pages/document-customer/document-customer.module#DocumentCustomerModule' },
  { path: 'task/:taskId/verificar-aml', loadChildren: './pages/aml-analyst/aml-analyst.module#AmlAnalystModule' },
  { path: 'task/:taskId/verificar-oficial-cumplimiento', loadChildren: './pages/official-compliance-analyst/official-compliance-analyst.module#OfficialComplianceAnalystModule' },
  { path: 'task/:taskId/generar-formularios', loadChildren: './pages/generate-docs/generate-docs.module#GenerateDocsModule' },
  { path: 'task/:taskId/cargar-informacion-adicional', loadChildren: './pages/additional-information/additional-information.module#AdditionalInformationModule' },
  { path: 'task/:taskId/verificar-datos-actualizacion', loadChildren: './pages/update-form/update-form.module#UpdateFormModule' },
  { path: 'externalRedirect', canActivate: [externalUrlProvider], component: NotFoundComponent }
];

@NgModule({
  providers: [
    {
      provide: externalUrlProvider,
      useValue: (route: ActivatedRouteSnapshot) => {
        const externalUrl = route.paramMap.get('externalUrl');
        window.open(externalUrl, '_self');
      },
    }
  ],
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
