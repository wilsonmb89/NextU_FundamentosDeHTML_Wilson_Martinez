import { Component, OnInit, OnDestroy, ChangeDetectorRef, AfterViewChecked } from '@angular/core';
import { Subscription } from 'rxjs';
import { ComponentCommunicationService } from './services/component-communication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy, AfterViewChecked {

  loadingSuscription: Subscription;
  errorSuscription: Subscription;
  userName: string;
  isLoadingActive: boolean;
  showErrorModal: boolean;
  redirectLogin: boolean;

  constructor(
    private _router: Router,
    private _cdRef: ChangeDetectorRef,
    private _compoComunicationService: ComponentCommunicationService
  ) { }

  ngOnInit() {
    this.redirectLogin = this.showErrorModal = this.isLoadingActive = false;
    this.setSuscription();
  }

  ngOnDestroy() {
    this.loadingSuscription.unsubscribe();
    this.errorSuscription.unsubscribe();
  }

  ngAfterViewChecked() {
    this._cdRef.detectChanges();
  }

  /**
   * Metodo para invocar el evento de guardar y salir a los
   * componentes hijos en el routing
   * @param valueIn valor a enviar en el suscriptor
   */
  callSaveExitEvent(valueIn: boolean) {
    this._compoComunicationService.emmitsaveButton(valueIn);
  }

  /**
   * Metodo para escuchar los cambios del modal de cargando por
   * los componentes hijos
   */
  setSuscription() {
    // Suscripcion del componente del loading
    this.loadingSuscription = this._compoComunicationService.loadingCommunication$.subscribe(
      loadingActiveValue => {
        this.isLoadingActive = loadingActiveValue || false;
      }
    );
    // Suscripcion del componente del modal de error
    this.errorSuscription = this._compoComunicationService.errorCommunication$.subscribe(
      errorData => {
        this.showErrorModal = !!errorData && !!errorData.showErrorModal || false;
        this.redirectLogin = !!errorData && !!errorData.redirectLogin || false;
      }
    );
  }

  /**
  * Metodo para cerrar el modal del error
  * @param value Valor proporcionado por el componente de error Modal
  */
  closeErrorModal(value: boolean) {
    this.showErrorModal = value;
    if (this.redirectLogin) {
      this.redirectUrl('/portal/');
    }
  }

  /**
   * Metodo para navegar a una url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      this._router.navigate(['/externalRedirect', { externalUrl: domain }], {
        skipLocationChange: true,
      });
    }
  }
}
