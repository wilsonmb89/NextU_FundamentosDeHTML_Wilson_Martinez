import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NotFoundComponent } from './shared/components/not-found/not-found.component';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { SafePipe } from './shared/utils/pipes/safe-pipe.pipe';
import { SharedModule } from './shared/shared.module';
import { MaterialModule } from './material/material.module';
import { HeadbarComponent } from './components/headbar/headbar.component';
import { ComponentCommunicationService } from './services/component-communication.service';

@NgModule({
  declarations: [
    SafePipe,
    AppComponent,
    NotFoundComponent,
    SidebarComponent,
    HeadbarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MaterialModule,
    SharedModule
  ],
  providers: [
    ComponentCommunicationService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
