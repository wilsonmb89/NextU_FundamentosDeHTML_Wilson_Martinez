import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnalystCheckTableComponent } from './analyst-check-table.component';

describe('AnalystCheckTableComponent', () => {
  let component: AnalystCheckTableComponent;
  let fixture: ComponentFixture<AnalystCheckTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnalystCheckTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnalystCheckTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
