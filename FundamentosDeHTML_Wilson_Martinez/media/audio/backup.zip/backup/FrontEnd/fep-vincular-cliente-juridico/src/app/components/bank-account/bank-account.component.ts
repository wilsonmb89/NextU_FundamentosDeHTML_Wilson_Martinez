import { Component, OnInit, Output, EventEmitter, OnDestroy } from '@angular/core';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Subscription } from 'rxjs';
import { DatosCuentaBancaria } from 'src/app/utils/models/api-solicitud/DatosCuentaBancaria';
import { CatalogoService } from 'src/app/shared/services/catalogo.service';
import { CatalogoRequest } from 'src/app/shared/utils/mapping/CatalogoRequest';
import { capitalizeText } from 'src/app/shared/utils/functions/transform';

@Component({
  selector: 'app-bank-account',
  templateUrl: './bank-account.component.html',
  styleUrls: ['./bank-account.component.scss']
})
export class BankAccountComponent implements OnInit, OnDestroy {

  CONST_NAME_PAGE = "OPERACIONES_INTERNACIONALES";
  nameComponent = "BankAccountComponent";

  @Output() validEmit: EventEmitter<any> = new EventEmitter();
  @Output() solicitudEmit: EventEmitter<any> = new EventEmitter();

  datosSolicitud: DatosSolicitud;
  formBankAccount: FormGroup;
  propertiesForm: string[];
  formChangesSuscriptor: Subscription;
  bankList = [];

  constructor(
    private _catalogoService: CatalogoService
  ) { }

  ngOnInit() {
    this.getCatalogs();
    this.validEmit.emit(this.formBankAccount.valid);
    this.solicitudEmit.emit(this.datosSolicitud);
  }

  ngOnDestroy() {
    if (!!this.formChangesSuscriptor) {
      this.formChangesSuscriptor.unsubscribe();
    }
  }

  /**
   * Metodo para obtener la data previa en SOR
   * @param dataSolicitud Objeto entregado por el padre
   */
  async getSolicitudSor(dataSolicitud: DatosSolicitud) {
    this.datosSolicitud = dataSolicitud;
    this.formBankAccount = new FormGroup(this.createForm());
    this.updateForm(this.datosSolicitud.clienteJuridico.datosAdicionales.datosCuentaBancaria);
    this.formChangesSuscriptor = this.formBankAccount.valueChanges.subscribe(() => {
      this.datosSolicitud.clienteJuridico.datosAdicionales.datosCuentaBancaria = this.formBankAccount.value;
      this.solicitudEmit.emit(this.datosSolicitud);
      this.validEmit.emit(this.formBankAccount.valid);
    });
  }

  /**
   * Metodo para crear las propiedades del formgroup a partir de
   * un modelo como Datos Cuenta Bancaria
   */
  createForm() {
    const bankAccountDataModel = new DatosCuentaBancaria();
    this.propertiesForm = Object.getOwnPropertyNames(bankAccountDataModel);
    const object = {};
    this.propertiesForm.forEach((item) => {
      object[item] = new FormControl(bankAccountDataModel[item], Validators.required);
    });
    return object;
  }

  /**
   * Actualiza el formulario con la data obtenida en SOR
   * @param datosCuentaBancaria corresponden a los datos de la cuenta bancaria
   * de la solicitud
   */
  updateForm(datosCuentaBancaria: DatosCuentaBancaria) {
    if (!(!!datosCuentaBancaria)) {
      datosCuentaBancaria = new DatosCuentaBancaria();
    }
    this.formBankAccount.get('nombreTitular').setValue(datosCuentaBancaria.nombreTitular);
    this.formBankAccount.get('cedulaCiudadania').setValue(datosCuentaBancaria.cedulaCiudadania);
    this.formBankAccount.get('nombreBanco').setValue(datosCuentaBancaria.nombreBanco);
    this.formBankAccount.get('tipoCuenta').setValue(datosCuentaBancaria.tipoCuenta);
    this.formBankAccount.get('numeroCuenta').setValue(datosCuentaBancaria.numeroCuenta);
  }

  /**
   * Metodo que carga los catalogos de bancos
   */
  async getCatalogs() {
    const catalogoRq = new CatalogoRequest();
    catalogoRq.catalogName = "Banco";
    const catalogoRs = await <any> this._catalogoService.getCatalog(catalogoRq);
    if (!!catalogoRs && !!catalogoRs.catalogName) {
      this.bankList = catalogoRs.items;
      this.bankList.forEach((element) => {
        element.name = (!!element.name) ? capitalizeText(element.name.toLowerCase()) : '';
      });
    }
  }

}
