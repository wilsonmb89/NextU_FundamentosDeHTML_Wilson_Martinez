import { NgModule } from '@angular/core';
import { ItemLegalRepresentativeComponent } from './item-legal-representative/item-legal-representative.component';
import { FormLegalRepresentativeComponent } from './form-legal-representative/form-legal-representative.component';
import { RejectModalComponent } from './modals/reject-modal/reject-modal.component';
import { PdfModalComponent } from './modals/pdf-modal/pdf-modal.component';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';
import { ItemShareholderComponent } from './item-shareholder/item-shareholder.component';
import { FormShareholderComponent } from './form-shareholder/form-shareholder.component';
import { FormAuthorizedComponent } from './form-authorized/form-authorized.component';
import { DocumentsListToVerifyComponent } from './documents-list-to-verify/documents-list-to-verify.component';
import { ViewDocumentsComponent } from './view-documents/view-documents.component';
import { AnalystCheckTableComponent } from './analyst-check-table/analyst-check-table.component';
import { EditProfileAmlComponent } from './edit-profile-aml/edit-profile-aml.component';
import { MaterialModule } from '../material/material.module';
import { OfficialComplianceCheckTableComponent } from './official-compliance-check-table/official-compliance-check-table.component';
import { DocumentViewerComponent } from './document-viewer/document-viewer.component';
import { InternationalOperationsComponent } from './international-operations/international-operations.component';
import { TributaryInformationComponent } from './tributary-information/tributary-information.component';
import { CurrencyMaskModule } from "ng2-currency-mask";
import { DragAndDropComponent } from './drag-and-drop/drag-and-drop.component';
import { DocumentUserListComponent } from './document-user-list/document-user-list.component';
import { FinancialDataComponent } from './financial-data/financial-data.component';
import { PayerTableComponent } from './payer-table/payer-table.component';
import { FormAdditionalInfoComponent } from './form-additional-info/form-additional-info.component';
import { FatcaClasificationComponent } from './fatca-clasification/fatca-clasification.component';
import { BankAccountComponent } from './bank-account/bank-account.component';

@NgModule({
    declarations: [
        ItemLegalRepresentativeComponent,
        FormLegalRepresentativeComponent,
        ItemShareholderComponent,
        FormShareholderComponent,
        RejectModalComponent,
        PdfModalComponent,
        FormAuthorizedComponent,
        DocumentsListToVerifyComponent,
        ViewDocumentsComponent,
        AnalystCheckTableComponent,
        EditProfileAmlComponent,
        OfficialComplianceCheckTableComponent,
        DocumentViewerComponent,
        InternationalOperationsComponent,
        TributaryInformationComponent,
        DragAndDropComponent,
        DocumentUserListComponent,
        FinancialDataComponent,
        PayerTableComponent,
        FormAdditionalInfoComponent,
        FatcaClasificationComponent,
        BankAccountComponent
    ],
    imports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        MaterialModule,
        CurrencyMaskModule
    ],
    exports: [
        ItemLegalRepresentativeComponent,
        FormLegalRepresentativeComponent,
        ItemShareholderComponent,
        FormShareholderComponent,
        RejectModalComponent,
        PdfModalComponent,
        FormAuthorizedComponent,
        DocumentsListToVerifyComponent,
        ViewDocumentsComponent,
        AnalystCheckTableComponent,
        EditProfileAmlComponent,
        OfficialComplianceCheckTableComponent,
        InternationalOperationsComponent,
        DragAndDropComponent,
        DocumentUserListComponent,
        PayerTableComponent,
        FormAdditionalInfoComponent,
        FatcaClasificationComponent
    ]
})
export class ComponentsModule { }
