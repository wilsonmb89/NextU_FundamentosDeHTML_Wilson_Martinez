import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentUserListComponent } from './document-user-list.component';

describe('DocumentUserListComponent', () => {
  let component: DocumentUserListComponent;
  let fixture: ComponentFixture<DocumentUserListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentUserListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentUserListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
