import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Participante } from 'src/app/utils/models/api-solicitud/Participante';

@Component({
  selector: 'app-document-user-list',
  templateUrl: './document-user-list.component.html',
  styleUrls: ['./document-user-list.component.scss']
})
export class DocumentUserListComponent implements OnInit {

  @Input()
  participantList: Participante[];
  @Input()
  participantType: string;
  @Output()
  verDocumentoEmmiter: EventEmitter<any>;
  @Output()
  updateParticipantListEmmiter: EventEmitter<any>;

  constructor() {
    this.verDocumentoEmmiter = new EventEmitter<any>();
    this.updateParticipantListEmmiter = new EventEmitter<any>();
  }

  ngOnInit() {
  }

  /**
   * Metodo para eliminar un participante de la lista de entrada y pedir la actualizacion
   * en el componente padre
   * @param participant Participante a eliminar de la lista
   */
  deleteUser(participant: Participante) {
    const filterParticipantList = this.participantList.filter(part => part !== participant);
    this.participantList = filterParticipantList;
    this.updateParticipantListEmmiter.emit({ "list" : this.participantList, "participantType" : this.participantType });
  }

  /**
   * Metodo para solicitar al componente padre visualizar un documento
   * @param participant Participante que contiene la URL del documento a mostrar
   */
  viewDocument(participant: Participante) {
    const pathFile = participant.datosDocumento.documentosSolicitados["DOC_IDENTIDAD"];
    this.verDocumentoEmmiter.emit({ "pathFile" : pathFile, "participantType" : this.participantType });
  }
}
