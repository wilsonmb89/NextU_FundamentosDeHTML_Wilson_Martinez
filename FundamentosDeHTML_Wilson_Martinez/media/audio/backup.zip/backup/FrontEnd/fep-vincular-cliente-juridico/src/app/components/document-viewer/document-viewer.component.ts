import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { scanUploadDoc, getScanDoc, uploadDoc, getDoc } from 'src/app/utils/mapping/UploadDocMapping';
import { TipoParticipante } from 'src/app/utils/constants/participants.enum';
import { DocumentService } from 'src/app/shared/services/document.service';
import { DatosDocumento } from 'src/app/utils/models/api-solicitud/DatosDocumento';
import { CatalogoService } from 'src/app/shared/services/catalogo.service';
import { CatalogoRequest } from 'src/app/shared/utils/mapping/CatalogoRequest';
import { capitalizeText } from 'src/app/shared/utils/functions/transform';

@Component({
  selector: 'app-document-viewer',
  templateUrl: './document-viewer.component.html',
  styleUrls: ['./document-viewer.component.scss']
})
export class DocumentViewerComponent implements OnInit, OnChanges {
  @Input() model;
  @Input() client;
  @Input() typeParticipant;
  @Output() changeImage: EventEmitter<any>;
  idTypeParticipant: string;
  loading: boolean;
  tiposDocumento: [];
  canAddDocument: boolean;

  urlFile: any;
  constructor(
    public sanitizer: DomSanitizer,
    private _documentService: DocumentService
  ) {
    this.changeImage = new EventEmitter<any>();
    this.loading = false;
  }

  ngOnInit() {
    this.getAcronimoTipoParticipante();
    this.previewFile();
    this.tiposDocumento = [];
  }
  ngOnChanges() {
    this.canAddDocument = this.model.tipoDocumento && this.model.numeroDocumento;
  }

  /**
   * Metodo que captura el documento
   * @param data el contenido del file input, donde se encuentran el documento
   */
  async processDocument(files) {
    this.loading = true;
      const name = this.model.tipoDocumento.split("-")[0] + "-" + this.model.numeroDocumento + ".pdf";
      const uploadDocumentRq = uploadDoc(files.target.files[0], this.idTypeParticipant, this.client.datosGenerales, name);
      const uploadDocumentRs = await this._documentService.uploadDocument(uploadDocumentRq);
      if (!!uploadDocumentRs) {
        this.model.datosDocumento = new DatosDocumento();
        this.model.datosDocumento.documentosSolicitados = {};
        const ruta = this.client.datosGenerales.tipoDocumento.split("-")[1].trim() + "/"
          + this.client.datosGenerales.numeroDocumento.replace(/\D/g, '') + "/" + this.idTypeParticipant + "/" + name;
        this.model.datosDocumento.documentosSolicitados["DOC_IDENTIDAD"] = ruta;
        await this.previewFile();
      }
      this.loading = false;
  }
  /** Metodo para obtener el acronimo del participante */
  getAcronimoTipoParticipante() {
    switch (this.typeParticipant) {
      case TipoParticipante.representanteLegal:
        this.idTypeParticipant = "REP";
        break;
      case TipoParticipante.ordenante:
          this.idTypeParticipant = "ORD";
          break;
      case TipoParticipante.autorizado:
          this.idTypeParticipant = "AUT";
          break;
      case TipoParticipante.accionista:
          this.idTypeParticipant = "ACC";
          break;
      case TipoParticipante.tercero:
          this.idTypeParticipant = "TER";
          break;
      default:
        break;
    }
  }

  async previewFile() {
    if (this.model.datosDocumento) {
      this.loading = true;
      const document = this.model.datosDocumento.documentosSolicitados["DOC_IDENTIDAD"];
      const docRq = getScanDoc(document, this.idTypeParticipant, this.client.datosGenerales);
      const res = await this._documentService.getDocument(docRq);
      const pdf: any = new Blob([res], { type: 'application/pdf' });
      const url = URL.createObjectURL(pdf);
      this.urlFile = this.sanitizer.bypassSecurityTrustResourceUrl(url);
      this.loading = false;
      this.changeImage.emit(this.model);
    }
  }

  /**
   * Metodo para construir el tipo de documento de sor COD-LABEL
   * @param tipoDocumento label de tipo de documento
   */
  getTipoDocumentoCatalog(tipoDocumento: string) {
    if (!!this.tiposDocumento && this.tiposDocumento.length > 0) {
      const tipoDocumentoObj: any = this.tiposDocumento.find(
        (obj: any) => obj.strDescripcion === tipoDocumento
      );
      if (!!tipoDocumentoObj) {
        return (tipoDocumentoObj.name + '-' + tipoDocumentoObj.strDescripcion);
      }
    }
    return "";
  }
}
