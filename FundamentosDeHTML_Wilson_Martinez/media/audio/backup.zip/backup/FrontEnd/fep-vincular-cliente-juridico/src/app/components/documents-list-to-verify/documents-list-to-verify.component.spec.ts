import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentsListToVerifyComponent } from './documents-list-to-verify.component';

describe('DocumentsListToVerifyComponent', () => {
  let component: DocumentsListToVerifyComponent;
  let fixture: ComponentFixture<DocumentsListToVerifyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentsListToVerifyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentsListToVerifyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
