import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CatalogoRequest } from 'src/app/shared/utils/mapping/CatalogoRequest';
import { capitalizeText } from 'src/app/shared/utils/functions/transform';
import { CatalogoService } from 'src/app/shared/services/catalogo.service';

@Component({
  selector: 'app-documents-list-to-verify',
  templateUrl: './documents-list-to-verify.component.html',
  styleUrls: ['./documents-list-to-verify.component.scss']
})
export class DocumentsListToVerifyComponent implements OnInit {
  @Input() listDocuments: any;
  @Output() listChange: EventEmitter<any>;
  propertyNames: any;
  listNameDocuments: any[];
  constructor(private _catalogoService: CatalogoService) {
    this.listChange = new EventEmitter<any>();
  }

  ngOnInit() {
    this.getNamesDocuments();
  }
  async getNamesDocuments() {
    this.listNameDocuments = await this.getCatalog("Documento", null);
    this.propertyNames = Object.getOwnPropertyNames(this.listDocuments);
    this.addNameAndCheck();
  }
  async getCatalog(catalogName: string, id: string) {
    const catalogoRq = new CatalogoRequest();
    catalogoRq.catalogName = catalogName;
    catalogoRq.idParent = id || '';
    const items = await this._catalogoService.getCatalog(catalogoRq);
    return items.items;
  }
  getNameDocument(id: string) {
    return this.listNameDocuments.find(item => item.id === id).name;
  }
  getNameApplicant(property: string) {
    return capitalizeText(property.replace(/[A-Z]/g, " $&").trim());
  }
  addNameAndCheck() {
    this.propertyNames.forEach(item => {
      this.listDocuments[item] = this.listDocuments[item].map(element => {
        element["nombre"] = element["nombre"] ? element["nombre"] : this.getNameDocument(element.tipo);
        element["check"] = element["check"] ? element["check"] : false;
        return element;
      });
    });
    this.listChange.emit(this.listDocuments);
  }
  onClickCheck(event: any, item: any) {
    item.check = event.checked;
  }
}
