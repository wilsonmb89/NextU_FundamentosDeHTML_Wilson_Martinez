import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { DocumentService } from 'src/app/shared/services/document.service';
import { scanUploadDoc } from 'src/app/utils/mapping/UploadDocMapping';
import { getAcronimoTipoParticipante, getTipoDocumentoCodaName } from 'src/app/utils/functions/transform';
import { Participante } from 'src/app/utils/models/api-solicitud/Participante';
import { DatosRepresentanteLegal } from 'src/app/utils/models/api-solicitud/DatosRepresentanteLegal';
import { Accionista } from 'src/app/utils/models/api-solicitud/Accionista';
import { DatosOrdenantes } from 'src/app/utils/models/api-solicitud/DatosOrdenantes';
import { capitalizeText } from 'src/app/shared/utils/functions/transform';
import { DatosDocumento } from 'src/app/utils/models/api-solicitud/DatosDocumento';
import { DatosAccionistas } from 'src/app/utils/models/api-solicitud/DatosAccionistas';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'app-drag-and-drop',
  templateUrl: './drag-and-drop.component.html',
  styleUrls: ['./drag-and-drop.component.scss']
})
export class DragAndDropComponent implements OnInit, OnChanges {

  @Input()
  datosSolicitud: DatosSolicitud;
  @Input()
  participantType: string;
  @Output()
  processDataEmmiter: EventEmitter<boolean>;

  showErrorDDModal: boolean;

  constructor(
    private _documentService: DocumentService,
    private _customerService: CustomerService
  ) {
    this.processDataEmmiter = new EventEmitter<boolean>();
  }

  ngOnInit() {
    this.showErrorDDModal = false;
  }

  ngOnChanges() {
    this.resetFileInput();
  }

  /**
   * Metodo que captura el evento de arrastrar documentos
   * @param data el contenido del file input, donde se encuentran los documentos
   * obtenidos por el drag and drop
   */
  async processDocuments(files) {
    this.processDataEmmiter.emit(true);
    if (!!files && files.length > 0) {
      let contDocErrors = 0;
      for (let x = 0 ; x < files.length ; x++) {
        const scanUploadDocumentRq = scanUploadDoc(files[x], getAcronimoTipoParticipante(this.participantType), this.datosSolicitud.clienteJuridico.datosGenerales);
        const scanUploadDocumentRs = await this._documentService.uploadMultipartDocId(scanUploadDocumentRq);
        if (!!scanUploadDocumentRs) {
          this.saveParticipante(scanUploadDocumentRs);
        } else {
          contDocErrors++;
        }
      }
      if (contDocErrors > 0) {
        this.showErrorDDModal = true;
      }
    }
    this.resetFileInput();
    this.processDataEmmiter.emit(false);
  }

  /**
   * Metodo para limpiar el valor del drag and drop del HTML
   */
  resetFileInput() {
    const fileInput = <HTMLInputElement> document.getElementById('fileExplorer');
    if (!!fileInput) {
      fileInput.value = "";
    }
  }

  /**
   * Metodo para crear un participante de acuerdo de los datos obtenidos por la lectura
   * de un documento seleccionado
   * @param dataDocument contiene los datos para crear un participante de acuerdo al tipo de este
   */
  async saveParticipante(dataDocument: any) {
    if (!!dataDocument) {
      const acronimoParticipante = getAcronimoTipoParticipante(this.participantType);
      let participante: Participante = null;
      switch (acronimoParticipante) {
        case "ORD":
          participante = new DatosOrdenantes();
          break;
        case "ACC":
          participante = new Accionista();
          break;
        case "REP":
          participante = new DatosRepresentanteLegal();
          break;
        default:
          break;
      }
      if (!!participante) {
        participante.nombre = capitalizeText((!!dataDocument.nombres ? (dataDocument.nombres + ' ') : '') + (!!dataDocument.apellidos ? dataDocument.apellidos : ''));
        participante.numeroDocumento = dataDocument.numeroDocumento || '';
        participante.tipoDocumento = getTipoDocumentoCodaName(dataDocument.tipoDocumento || '');
        participante.datosDocumento = new DatosDocumento();
        participante.datosDocumento.documentosSolicitados = {};
        participante.datosDocumento.documentosSolicitados["DOC_IDENTIDAD"] = dataDocument.ruta;
        participante.isCliente = await this.seachCustomer(participante);
        if (participante instanceof DatosRepresentanteLegal) {
          participante.fechaExpedicion = dataDocument.fechaExpedicion || '';
          if (!(!!this.datosSolicitud.clienteJuridico.datosRepresentanteLegal)) {
            this.datosSolicitud.clienteJuridico.datosRepresentanteLegal = [];
          }
          const representanteFind = this.datosSolicitud.clienteJuridico.datosRepresentanteLegal.find((rep) => (rep.tipoDocumento === participante.tipoDocumento && rep.numeroDocumento === participante.numeroDocumento));
          if (!(!!representanteFind)) {
            this.datosSolicitud.clienteJuridico.datosRepresentanteLegal.push(participante);
          }
        } else if (participante instanceof DatosOrdenantes) {
          participante.fechaExpedicion = dataDocument.fechaExpedicion || '';
          if (!(!!this.datosSolicitud.clienteJuridico.datosOrdenantes)) {
            this.datosSolicitud.clienteJuridico.datosOrdenantes = [];
          }
          const ordenanteFind = this.datosSolicitud.clienteJuridico.datosOrdenantes.find((ord) => (ord.tipoDocumento === participante.tipoDocumento && ord.numeroDocumento === participante.numeroDocumento));
          if (!(!!ordenanteFind)) {
            this.datosSolicitud.clienteJuridico.datosOrdenantes.push(participante);
          }
        } else if (participante instanceof Accionista) {
          if (!(!!this.datosSolicitud.clienteJuridico.datosAccionistas)) {
            this.datosSolicitud.clienteJuridico.datosAccionistas = new DatosAccionistas();
            this.datosSolicitud.clienteJuridico.datosAccionistas.accionistas = [];
          }
          const accionistaFind = this.datosSolicitud.clienteJuridico.datosAccionistas.accionistas.find((acc) => (acc.tipoDocumento === participante.tipoDocumento && acc.numeroDocumento === participante.numeroDocumento));
          if (!(!!accionistaFind)) {
            this.datosSolicitud.clienteJuridico.datosAccionistas.accionistas.push(participante);
          }
        }
      }
    }
  }

  /**
   * Metodo para verificar si un participante existe en la base de datos
   * @param participante participante a consultar en la base de datos
   */
  async seachCustomer(participante: Participante) {
    let isCliente = false;
    const numeroIdentificacion = participante.numeroDocumento.replace(/\./g, '') || '';
    const tipoIdentificacion = participante.tipoDocumento.split("-")[0].trim() || '';
    const querySearchCustomer = {
      "query": "query clienteExiste($tipoIdenti: String!, $numIdenti: String!){ clienteExiste(tipoIdentificacion: $tipoIdenti, numeroIdentificacion: $numIdenti){ existe, personaJuridica { datosContactoPJ { comercialRM, nombre, direccion, telefono, pais, departamento, ciudad, correo  } } } }",
      "variables": {
          "tipoIdenti": tipoIdentificacion || "",
          "numIdenti": numeroIdentificacion || ""
      },
      "operationName": "clienteExiste"
    };
    const getCustRs = await this._customerService.getCustomer(querySearchCustomer);
    if (!!getCustRs) {
      isCliente = !!getCustRs.data && !!getCustRs.data.clienteExiste ? getCustRs.data.clienteExiste.existe || false : false;
    }
    return isCliente;
  }

  /**
   * Metodo para cerrar el modal de error
   */
  closeDDError() {
    this.showErrorDDModal = false;
  }
}
