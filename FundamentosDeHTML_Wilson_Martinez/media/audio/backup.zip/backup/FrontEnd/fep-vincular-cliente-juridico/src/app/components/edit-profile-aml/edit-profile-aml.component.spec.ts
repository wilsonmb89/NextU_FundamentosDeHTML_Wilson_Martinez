import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditProfileAmlComponent } from './edit-profile-aml.component';

describe('EditProfileAmlComponent', () => {
  let component: EditProfileAmlComponent;
  let fixture: ComponentFixture<EditProfileAmlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditProfileAmlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditProfileAmlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
