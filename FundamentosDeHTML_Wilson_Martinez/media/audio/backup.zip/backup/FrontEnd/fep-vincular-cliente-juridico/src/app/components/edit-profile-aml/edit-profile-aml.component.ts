import { Component, OnInit, Input, OnChanges, Output, EventEmitter } from '@angular/core';
import { DocumentoSoporte } from 'src/app/utils/models/api-solicitud/DocumentoSoporte';
import { Participante } from 'src/app/utils/models/api-solicitud/Participante';
import { DatosAML } from 'src/app/utils/models/api-solicitud/DatosAML';
import { downloadFile } from 'src/app/shared/utils/functions/utils';
import { deleteDocSoporte, uploadDoc, getDoc } from 'src/app/utils/mapping/UploadDocMapping';
import { DatosGenerales } from 'src/app/utils/models/api-solicitud/DatoGenerales';
import { DocumentService } from 'src/app/shared/services/document.service';
import { convertBase64 } from 'src/app/shared/utils/functions/transform';

@Component({
  selector: 'app-edit-profile-aml',
  templateUrl: './edit-profile-aml.component.html',
  styleUrls: ['./edit-profile-aml.component.scss']
})
export class EditProfileAmlComponent implements OnInit, OnChanges {

  documentosSoporte: Array<DocumentoSoporte>;
  conceptoAML: any;
  pageTitle: string;
  currDate: Date;
  nivelRiesgo: any;
  soporteListas: Array<any>;
  disabledUploadReqDoc: boolean;
  isCliente: string;

  CONST_AML_TYPE = "AML";
  CONST_CUMPLIMIENTO_TYPE = "CUMPLIMIENTO";
  CONST_DOC_SUP_TYPE = "SUP";
  CONST_DOC_ORIGEN_AML = "AML";
  CONST_TYPE_PDF = "data:application/pdf;base64,";

  @Input() analisisType: string;
  @Input() participante: Participante;
  @Input() datosGeneralesClienteJuridico: DatosGenerales;
  @Output() saveDataEmmiter: EventEmitter<Participante>;
  @Output() goBackEmmiter: EventEmitter<boolean>;
  @Output() showLoadingEmmiter: EventEmitter<boolean>;
  @Output() showErrorEmmiter: EventEmitter<boolean>;
  @Output() viewPDFEmmiter: EventEmitter<string>;

  constructor(
    private _documentService: DocumentService
  ) {
    this.saveDataEmmiter = new EventEmitter<Participante>();
    this.goBackEmmiter = new EventEmitter<boolean>();
    this.showLoadingEmmiter = new EventEmitter<boolean>();
    this.showErrorEmmiter = new EventEmitter<boolean>();
    this.viewPDFEmmiter = new EventEmitter<string>();
  }

  ngOnInit() {
    this.disabledUploadReqDoc = false;
    this.currDate = new Date();
    this.initInputData();
  }

  ngOnChanges(changes) {
    this.setSoporteListas();
    this.setNivelRiesgo();
    this.setPageData();
  }

  /**
   * Metodo para cargar la pantalla con la informacion que pueda tener de manera
   * previa el objeto de tipo Participante
   */
  setPageData() {
    if (!!this.participante.documentosSoporte && this.participante.documentosSoporte.length > 0) {
      this.documentosSoporte = this.participante.documentosSoporte;
    } else {
      this.documentosSoporte = new Array<DocumentoSoporte>();
    }
    if (this.analisisType === this.CONST_AML_TYPE && !!this.participante.datosAml) {
      this.conceptoAML = {
        motivo: this.participante.datosAml.motivo || '',
        decision: this.participante.datosAml.decision || ''
      };
    } else if (this.analisisType === this.CONST_CUMPLIMIENTO_TYPE && !!this.participante.datosCumplimiento) {
      this.conceptoAML = {
        motivo: this.participante.datosCumplimiento.motivo || '',
        decision: this.participante.datosCumplimiento.decision || ''
      };
    } else {
      this.conceptoAML = {
        motivo: "",
        decision: ""
      };
    }
  }

  /**
   * Metodo para actualizar el riesgo del participante de acuerdo
   * al cambio de alguno de estos en la seccion Nivel de riesgo
   * @param event corresponde al elemento DOM en el que ocurrio el cambio
   * del checkbox
   */
  updateRisk(event) {
    const id = event.source.id || "";
    switch (id) {
      case "checkbox-pep":
        this.nivelRiesgo.isPep = event.checked;
        break;
      case "checkbox-medios":
        this.nivelRiesgo.isMediosPublicos = event.checked;
        break;
      case "checkbox-siap":
        this.nivelRiesgo.isSiap = event.checked;
        break;
      case "checkbox-scap":
        this.nivelRiesgo.isScap = event.checked;
        break;
      default:
        break;
    }
  }

  /**
   * Metodo para almacenar un archivo soporte de un participante en la solicitud
   * @param file Archivo del filechooser
   * @param fileInput input del filechooser
   */
  async onFileSelected(file: File, fileInput) {
    this.disabledUploadReqDoc = true;
    const prevDoc = this.documentosSoporte.find((obj) => obj.nombre === file.name);
    if (!!file && file.type.match('application/pdf') && !(!!prevDoc)) {
      const documentoSoporte = new DocumentoSoporte();
      documentoSoporte.nombre = file.name;
      documentoSoporte.origen = this.CONST_DOC_ORIGEN_AML;
      documentoSoporte.estado = 'LOADING';
      documentoSoporte.file = await convertBase64(file);
      documentoSoporte.index = this.documentosSoporte.length;
      this.documentosSoporte.push(documentoSoporte);
      const docRq = uploadDoc(file, this.CONST_DOC_SUP_TYPE, this.datosGeneralesClienteJuridico);
      const response = await this._documentService.uploadDocument(docRq);
      if (!!response) {
        this.documentosSoporte[this.documentosSoporte.length - 1].estado = "READY";
      } else {
        this.documentosSoporte.pop();
        this.showErrorEmmiter.emit(false);
      }
    }
    fileInput.value = "";
    this.disabledUploadReqDoc = false;
  }

  /**
   * Metodo para emitir un evento que muestra un PDF en el componente padre
   * @param nombreDocumento nombre del documento a mostrar
   */
  async viewPdf(nombreDocumento) {
    this.viewPDFEmmiter.emit("");
    this.viewPDFEmmiter.emit(await this.convertPdf(nombreDocumento));
  }

  /**
   * Metodo para conversion a URL de tipo PDF
   * @param name Nombre del archivo cargado
   */
  async convertPdf(name: string): Promise<string> {
    const docRq = getDoc(name, this.CONST_DOC_SUP_TYPE, this.datosGeneralesClienteJuridico);
    const res = await this._documentService.getDocument(docRq);
    const pdf: any = new Blob([res], { type: 'application/pdf' });
    const fileURL = URL.createObjectURL(pdf);
    return fileURL;
  }

  /**
   * Metodo para descargar un documento del panel
   * @param documento objeto que contiene la información con el documento a descargar
   */
  downloadSupportDoc(documento: DocumentoSoporte) {
    downloadFile(documento.nombre, documento.file);
  }

  /**
   * Metodo para eliminar un documento soporte de la lista general
   * @param documento objeto que corresponde al documento a eliminar
   */
  async deleteSupportDoc(documento: DocumentoSoporte) {
    if (!!this.datosGeneralesClienteJuridico && documento.origen !== this.CONST_DOC_ORIGEN_AML) {
      this.showLoadingEmmiter.emit(true);
      const deleteDocRq = deleteDocSoporte(documento.nombre, this.CONST_DOC_SUP_TYPE, this.datosGeneralesClienteJuridico, this.participante.numeroDocumento);
      const deleteDocRs = await this._documentService.deleteDocument(deleteDocRq);
      if (!!deleteDocRs) {
        const auxDocsSoporte = this.documentosSoporte.filter((obj) => obj.index !== documento.index);
        this.documentosSoporte = auxDocsSoporte;
      } else {
        this.showErrorEmmiter.emit(false);
      }
      this.showLoadingEmmiter.emit(false);
    }
  }

  /**
   * Metodo para inicializar las variables de entrada en el caso
   * que su valor sea null
   */
  initInputData() {
    this.participante = !(!!this.participante) ? new Participante() : this.participante ;
    this.analisisType = !(!!this.analisisType) ? this.CONST_AML_TYPE : this.analisisType;
    this.isCliente = this.participante.isCliente ? 'Si' : 'No';
  }

  /**
   * Metodo para establecer en una variable del componente el riesgo del cliente
   * con el fin de un uso mas facil durante el comportamiento de la pantalla
   */
  setNivelRiesgo() {
    this.nivelRiesgo = {};
    if (!!this.participante && !!this.participante.datosRiesgo) {
      this.nivelRiesgo.isPep = (!!this.participante.datosRiesgo.isPep && this.participante.datosRiesgo.isPep === 'si');
      this.nivelRiesgo.isMediosPublicos = this.participante.datosRiesgo.isMedia || false;
      this.nivelRiesgo.isSiap = !!this.participante.datosRiesgo.siapRisk && this.participante.datosRiesgo.siapRisk !== 'bajo';
      this.nivelRiesgo.isScap = !!this.participante.datosRiesgo.scapRisk && this.participante.datosRiesgo.scapRisk !== 'bajo';
    }
  }

  /**
   * Metodo para establecer en la pantalla los soportes de la
   * lista segun el riesgo del cliente
   */
  setSoporteListas() {
    this.soporteListas = new Array<any>();
    if (!!this.participante && !!this.participante.datosRiesgo && !!this.participante.datosRiesgo.listasReportado) {
      this.participante.datosRiesgo.listasReportado.forEach(
        (lista) => {
          const soporte = {
            "nombreLista" : lista.nombreLista,
            "nacionalidad" : lista.nacionalidad,
            "identificacion" : lista.identificacion,
            "porcentaje" : lista.porcentaje,
          };
          this.soporteListas.push(soporte);
        }
      );
    }
  }

  /**
   * Metodo que se encarga de emitir el evento de guardar la informacion
   * del participante que se encuentra en la edicion
   */
  saveParticipantData() {
    this.participante.documentosSoporte = this.documentosSoporte;
    this.setDatosRiesgo();
    if (this.analisisType === this.CONST_AML_TYPE) {
      this.setDatosAML();
    } else if (this.analisisType === this.CONST_CUMPLIMIENTO_TYPE) {
      this.setDatosCumplimiento();
    }
    this.saveDataEmmiter.emit(this.participante);
  }

  /**
   * Metodo para regresar a la pantalla principal sin guardar la informacion
   */
  goBack() {
    this.goBackEmmiter.emit(false);
  }

  /**
   * Metodo para establecer los datos de riego de la pantalla al objeto participante
   */
  setDatosRiesgo() {
    this.participante.datosRiesgo.isPep = this.nivelRiesgo.isPep ? 'si' : 'no';
    this.participante.datosRiesgo.isMedia = this.nivelRiesgo.isMediosPublicos;
    this.participante.datosRiesgo.scapRisk = this.nivelRiesgo.isScap ? 'sensible' : 'bajo';
    this.participante.datosRiesgo.siapRisk = this.nivelRiesgo.isSiap ? 'alto' : 'bajo';
  }

  /**
   * Metodo para establecer los datos de AML de la pantala al objeto participante
   */
  setDatosAML() {
    if (!(!!this.participante.datosAml)) {
      this.participante.datosAml = new DatosAML();
    }
    this.participante.datosAml.decision = this.conceptoAML.decision || '';
    this.participante.datosAml.motivo = this.conceptoAML.motivo || '';
    this.participante.datosAml.revisionOk = (!!this.conceptoAML.motivo && this.conceptoAML.motivo.length > 50 && !!this.conceptoAML.decision && this.conceptoAML.decision === "positivo");
  }

  /**
   * Metodo para establecer los datos del Oficial de Cumplimiento de la pantala al objeto participante
   */
  setDatosCumplimiento() {
    if (!(!!this.participante.datosCumplimiento)) {
      this.participante.datosCumplimiento = new DatosAML();
    }
    this.participante.datosCumplimiento.decision = this.conceptoAML.decision || '';
    this.participante.datosCumplimiento.motivo = this.conceptoAML.motivo || '';
    this.participante.datosCumplimiento.revisionOk = (!!this.conceptoAML.motivo && this.conceptoAML.motivo.length > 50 && !!this.conceptoAML.decision && this.conceptoAML.decision === "positivo");
  }
}
