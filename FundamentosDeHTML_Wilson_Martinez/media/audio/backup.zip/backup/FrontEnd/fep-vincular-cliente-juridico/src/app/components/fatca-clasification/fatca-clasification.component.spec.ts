import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FatcaClasificationComponent } from './fatca-clasification.component';

describe('FatcaClasificationComponent', () => {
  let component: FatcaClasificationComponent;
  let fixture: ComponentFixture<FatcaClasificationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FatcaClasificationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FatcaClasificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
