import { Component, OnInit, OnDestroy, Output, EventEmitter, AfterViewInit, ElementRef } from '@angular/core';
import { CatalogoRequest } from 'src/app/shared/utils/mapping/CatalogoRequest';
import { CatalogoService } from 'src/app/shared/services/catalogo.service';
import { capitalizeText } from 'src/app/shared/utils/functions/transform';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { idValueCatalogValidator } from 'src/app/shared/utils/validations/CustomValidators';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { DatosClasificacionFatca } from 'src/app/utils/models/api-solicitud/DatosClasificacionFatca';
import { setScrolIntoView } from 'src/app/shared/utils/functions/utils';

@Component({
  selector: 'app-fatca-clasification',
  templateUrl: './fatca-clasification.component.html',
  styleUrls: ['./fatca-clasification.component.scss']
})
export class FatcaClasificationComponent implements OnInit, OnDestroy, AfterViewInit {
  formFatcaClasification: FormGroup;
  listCountries: any[];
  firstCountry: any;
  filterPais: Observable<string[]>;
  filterOtroPais: Observable<string[]>;
  formChangesSuscriptor: Subscription;

  CONST_NAME_PAGE = "OPERACIONES_INTERNACIONALES";
  nameComponent = "FatcaClasificationComponent";

  @Output() validEmit: EventEmitter<any> = new EventEmitter();
  @Output() solicitudEmit: EventEmitter<any> = new EventEmitter();

  datosSolicitud: DatosSolicitud;

  propertiesForm: string[];
  canAddOtherCountry: boolean;
  hasDescription: boolean;

  constructor(
    private _catalogoService: CatalogoService,
    private _el: ElementRef
  ) {
    this.formFatcaClasification = new FormGroup(this.createForm());
    this.setValidators();
    this.listCountries = new Array();
    this.firstCountry = {};
    this.canAddOtherCountry = false;
    this.hasDescription = false;
    this.datosSolicitud = new DatosSolicitud();
  }

  ngOnInit() { }
  ngOnDestroy() {
    if (!!this.formChangesSuscriptor) {
      this.formChangesSuscriptor.unsubscribe();
    }
  }

  ngAfterViewInit() {
    const inputList = ([].slice.call((<HTMLElement> this._el.nativeElement).querySelectorAll('input:not(.mat-radio-input)'))).concat([].slice.call((<HTMLElement> this._el.nativeElement).getElementsByTagName('textarea')));
    setScrolIntoView(inputList);
  }

  /** Metodo que realiza el cargue del catalogo
   * @param catalogName nombre del catalogo
   * @param id referencia de un catalogo padre
   */
  async getCatalog(catalogName: string, id: string) {
    const catalogoRq = new CatalogoRequest();
    catalogoRq.catalogName = catalogName;
    catalogoRq.idParent = id || '';
    const items = await this._catalogoService.getCatalog(catalogoRq);
    items.items.forEach(element => element.name = capitalizeText(element.name.toLowerCase()));
    return items.items;
  }
  async loadCountries() {
    const listCountries = await this.getCatalog("Pais", null);
    this.listCountries = listCountries;
    this.formFatcaClasification.get("paisResidencia").setValidators([Validators.required, Validators.maxLength(100), idValueCatalogValidator(this.listCountries)]);
    this.formFatcaClasification.get("otroPaisResidencia").setValidators([Validators.maxLength(100), idValueCatalogValidator(this.listCountries)]);
    this.firstCountry = this.listCountries.filter(country => country.name === "Colombia")[0];
    this.filterCountry();
  }
  /** Metodo que filtra asincronicamente los nombres de los paises */
  filterCountry() {
    this.filterPais = this.formFatcaClasification.get("paisResidencia").valueChanges
      .pipe(startWith(''), map(value => this.filterByArray(value, this.listCountries)));
    this.filterOtroPais = this.formFatcaClasification.get("otroPaisResidencia").valueChanges
      .pipe(startWith(''), map(value => this.filterByArray(value, this.listCountries)));
  }
  /**
   * Metodo para filtrar los resultados del catalogo comparado
   * con lo que el usuario escribe
   * @param value Valor proporcionado por el usuario
   */
  private filterByArray(value: string, array: any[]): string[] {
    const filterValue = value ? value.toLowerCase() : "";
    return array.filter(option => !!option && option.name && option.name.toLowerCase().includes(filterValue));
  }
  /** Metodo que agrega o elimina validaciones de formulario */
  setValidators() {
    this.formFatcaClasification.get("entidadInversion").setValidators([]);
    this.formFatcaClasification.get("otraEntidadInversion").setValidators([]);
    this.formFatcaClasification.get("institucionCustodia").setValidators([]);
    this.formFatcaClasification.get("nombreDeLaBolsa").setValidators([]);
    this.formFatcaClasification.get("nombreDeLaEntidad").setValidators([]);
    this.formFatcaClasification.get("otroNumeroIdentificacionTributaria").setValidators([]);
    this.formFatcaClasification.get("descripcionRazonNoTin").setValidators([]);
  }
  /** Metedo que agrega validaciones segun la data existente */
  setValidatorUpdate() {
    if (this.datosSolicitud.clienteJuridico.datosAdicionales.datosClasificacionFatca) {
      const listEntityToValid = ["Institución financiera: Entidad de inversión",
        "Institución financiera: Institución de depósito",
        "Entidades no financieras activas (ENF) listadas en bolsa o relacionadas con entidades cuyas acciones son negociadas en un mercado de valores"];
      const indexEntity = listEntityToValid.indexOf(this.datosSolicitud.clienteJuridico.datosAdicionales.datosClasificacionFatca.tipoEntidad);
      if ( indexEntity > -1) {
        this.addValidatorsForOtions(indexEntity + 1);
      }
    }
  }
  /**
   * Metodo para obtener la data previa en SOR
   * @param dataSolicitud Objeto entregado por el padre
   */
  async getSolicitudSor(dataSolicitud: DatosSolicitud) {
    this.datosSolicitud = dataSolicitud;
    await this.loadCountries();
    this.setValidatorUpdate();
    this.updateForm(this.datosSolicitud.clienteJuridico.datosAdicionales.datosClasificacionFatca);
    this.validEmit.emit(this.formFatcaClasification.valid);
    this.solicitudEmit.emit(this.datosSolicitud);
    this.formChangesSuscriptor = this.formFatcaClasification.valueChanges.subscribe(() => {
      this.datosSolicitud.clienteJuridico.datosAdicionales.datosClasificacionFatca = this.formFatcaClasification.value;
      this.solicitudEmit.emit(this.datosSolicitud);
      this.validEmit.emit(this.formFatcaClasification.valid);
    });
  }

  /**
   * Metodo para crear las propiedades del formgroup a partir de
   * un modelo como Datos Financieros
   */
  createForm() {
    const model = new DatosClasificacionFatca();
    this.propertiesForm = Object.getOwnPropertyNames(new DatosClasificacionFatca());
    const object = {};
    this.propertiesForm.forEach((item) => {
      object[item] = new FormControl(model[item], Validators.required);
    });
    return object;
  }

  /**
   * Actualiza el formulario con la data obtenida en SOR
   * @param datos corresponden a los datos de clasificacion fatca de la solicitud
   */
  updateForm(datos: DatosClasificacionFatca) {
    if (!(!!datos)) {
      datos = new DatosClasificacionFatca();
    }
    this.formFatcaClasification.get('tipoEntidad').setValue(datos.tipoEntidad);
    this.formFatcaClasification.get('entidadInversion').setValue(datos.entidadInversion);
    this.formFatcaClasification.get('otraEntidadInversion').setValue(datos.otraEntidadInversion);
    this.formFatcaClasification.get('institucionCustodia').setValue(datos.institucionCustodia);
    this.formFatcaClasification.get('nombreDeLaBolsa').setValue(datos.nombreDeLaBolsa);
    this.formFatcaClasification.get('nombreDeLaEntidad').setValue(datos.nombreDeLaEntidad);
    this.formFatcaClasification.get('entidadVigilada').setValue(datos.entidadVigilada);
    this.formFatcaClasification.get('emisorInscrito').setValue(datos.emisorInscrito);
    this.formFatcaClasification.get('transfiereFondos').setValue(datos.transfiereFondos);
    this.formFatcaClasification.get('paisResidencia').setValue(datos.paisResidencia);
    this.formFatcaClasification.get('numeroIdentificacionTributaria').setValue(datos.numeroIdentificacionTributaria);
    this.formFatcaClasification.get('otroPaisResidencia').setValue(datos.otroPaisResidencia);
    this.formFatcaClasification.get('otroNumeroIdentificacionTributaria').setValue(datos.otroNumeroIdentificacionTributaria);
    this.formFatcaClasification.get('razonNoTin').setValue(datos.razonNoTin);
    this.formFatcaClasification.get('descripcionRazonNoTin').setValue(datos.descripcionRazonNoTin);
  }
  /** Metodop para agregar otro pais c0n validacion de campos */
  addOtherCountry() {
    this.canAddOtherCountry = true;
    this.formFatcaClasification.get("otroPaisResidencia").setValidators([Validators.required, Validators.maxLength(100), idValueCatalogValidator(this.listCountries)]);
    this.formFatcaClasification.get("otroNumeroIdentificacionTributaria").setValidators([Validators.required]);
    this.formFatcaClasification.get("otroPaisResidencia").reset();
    this.formFatcaClasification.get("otroNumeroIdentificacionTributaria").reset();
    this.validEmit.emit(this.formFatcaClasification.valid);
  }
  /**
   * Metodo para mostrar el nombre en un catalogo
   * @param value Valor proporcionado por el catalogo
   */
  displayName(value) {
    if (!!value) {
      return value.split('-')[1].trim();
    }
  }
  /** Metodo para agregar validaciones segun la entidad
   * @param data datos que entrega el cambio del radio button
  */
  addValidatorsForOtions(data: any) {
    this.setValidators();
    if (data === 1) {
      this.formFatcaClasification.get("entidadInversion").setValidators([Validators.required]);
      this.formFatcaClasification.get("otraEntidadInversion").setValidators([Validators.required]);
    }
    if (data === 2) {
      this.formFatcaClasification.get("institucionCustodia").setValidators([Validators.required]);
    }
    if (data ===  3) {
      this.formFatcaClasification.get("nombreDeLaBolsa").setValidators([Validators.required]);
      this.formFatcaClasification.get("nombreDeLaEntidad").setValidators([Validators.required]);
    }
    this.formFatcaClasification.get("entidadInversion").reset();
    this.formFatcaClasification.get("institucionCustodia").reset();
    this.formFatcaClasification.get("otraEntidadInversion").reset();
    this.formFatcaClasification.get("nombreDeLaBolsa").reset();
    this.formFatcaClasification.get("nombreDeLaEntidad").reset();
    this.formFatcaClasification.updateValueAndValidity();
  }
  /** Metodo que muestra la descripcion del TIN */
  showDescription(data: any) {
    if (data.value === 'La Entidad no está habilitada en el país de residencia para obtener un número de identificación tributaria') {
      this.hasDescription = true;
      this.formFatcaClasification.get("descripcionRazonNoTin").setValidators([Validators.required]);
      this.formFatcaClasification.get("descripcionRazonNoTin").reset();
    } else {
      this.hasDescription = false;
      this.formFatcaClasification.get("descripcionRazonNoTin").setValidators([]);
      this.formFatcaClasification.get("descripcionRazonNoTin").reset();
    }
  }
}
