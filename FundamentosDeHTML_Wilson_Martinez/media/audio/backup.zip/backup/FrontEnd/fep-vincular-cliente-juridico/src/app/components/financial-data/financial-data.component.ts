import { Component, OnInit, Output, EventEmitter, OnDestroy, ElementRef, AfterViewInit } from '@angular/core';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { DatosFinancieros } from 'src/app/utils/models/api-solicitud/DatosFinancieros';
import { Subscription } from 'rxjs';
import { setScrolIntoView } from 'src/app/shared/utils/functions/utils';

@Component({
  selector: 'app-financial-data',
  templateUrl: './financial-data.component.html',
  styleUrls: ['./financial-data.component.scss']
})
export class FinancialDataComponent implements OnInit, OnDestroy, AfterViewInit {

  CONST_NAME_PAGE = "OPERACIONES_INTERNACIONALES";
  nameComponent = "FinancialDataComponent";

  @Output() validEmit: EventEmitter<any> = new EventEmitter();
  @Output() solicitudEmit: EventEmitter<any> = new EventEmitter();

  datosSolicitud: DatosSolicitud;
  formFinancialData: FormGroup;
  propertiesForm: string[];
  formChangesSuscriptor: Subscription;

  constructor(
    private _el: ElementRef
  ) { }

  ngOnInit() {
    this.validEmit.emit(this.formFinancialData.valid);
    this.solicitudEmit.emit(this.datosSolicitud);
  }

  ngOnDestroy() {
    if (!!this.formChangesSuscriptor) {
      this.formChangesSuscriptor.unsubscribe();
    }
  }

  ngAfterViewInit() {
    const inputList = ([].slice.call((<HTMLElement> this._el.nativeElement).querySelectorAll('input:not(.mat-radio-input)'))).concat([].slice.call((<HTMLElement> this._el.nativeElement).getElementsByTagName('textarea')));
    setScrolIntoView(inputList);
  }

  /**
   * Metodo para obtener la data previa en SOR
   * @param dataSolicitud Objeto entregado por el padre
   */
  async getSolicitudSor(dataSolicitud: DatosSolicitud) {
    this.datosSolicitud = dataSolicitud;
    this.formFinancialData = new FormGroup(this.createForm());
    this.setValidators();
    this.updateForm(this.datosSolicitud.clienteJuridico.datosAdicionales.datosFinancieros);
    this.formChangesSuscriptor = this.formFinancialData.valueChanges.subscribe(() => {
      this.datosSolicitud.clienteJuridico.datosAdicionales.datosFinancieros = this.formFinancialData.value;
      this.solicitudEmit.emit(this.datosSolicitud);
      this.validEmit.emit(this.formFinancialData.valid);
    });
  }

  /**
   * Metodo para crear las propiedades del formgroup a partir de
   * un modelo como Datos Financieros
   */
  createForm() {
    const financialDataModel = new DatosFinancieros();
    this.propertiesForm = Object.getOwnPropertyNames(financialDataModel);
    const object = {};
    this.propertiesForm.forEach((item) => {
      object[item] = new FormControl(financialDataModel[item], Validators.required);
    });
    return object;
  }

  /**
   * Actualiza el formulario con la data obtenida en SOR
   * @param datosFinancieros corresponden a los datos financieros de la solicitud
   */
  updateForm(datosFinancieros: DatosFinancieros) {
    if (!(!!datosFinancieros)) {
      datosFinancieros = new DatosFinancieros();
    }
    this.formFinancialData.get('ingresosMensuales').setValue(datosFinancieros.ingresosMensuales);
    this.formFinancialData.get('egresosMensuales').setValue(datosFinancieros.egresosMensuales);
    this.formFinancialData.get('activos').setValue(datosFinancieros.activos);
    this.formFinancialData.get('otrosIngresos').setValue(datosFinancieros.otrosIngresos);
    this.formFinancialData.get('otrosEgresos').setValue(datosFinancieros.otrosEgresos);
    this.formFinancialData.get('pasivos').setValue(datosFinancieros.pasivos);
    this.formFinancialData.get('totalIngresos').setValue(datosFinancieros.totalIngresos);
    this.formFinancialData.get('totalEgresos').setValue(datosFinancieros.totalEgresos);
    this.formFinancialData.get('patrimonio').setValue(datosFinancieros.patrimonio);
    this.formFinancialData.get('detalleIngresos').setValue(datosFinancieros.detalleIngresos);

  }

  /**
   * Metodo para establecer las validaciones correctas del formulario
   */
  setValidators() {
    this.formFinancialData.get('egresosMensuales').setValidators([]);
    this.formFinancialData.get('otrosEgresos').setValidators([]);
    this.formFinancialData.get('totalIngresos').setValidators([]);
    this.formFinancialData.get('totalEgresos').setValidators([]);
    this.formFinancialData.get('patrimonio').setValidators([]);
  }

  /**
   * Metodo para calcular el total de los ingresos en el formulario
   */
  setTotalIngresos() {
    const ingresosMensuales = <number> this.formFinancialData.get('ingresosMensuales').value || 0;
    const otrosIngresos = <number> this.formFinancialData.get('otrosIngresos').value || 0;
    this.formFinancialData.get('totalIngresos').setValue(ingresosMensuales + otrosIngresos);
  }

  /**
   * Metodo para calcular el total de los ingresos en el formulario
   */
  setTotalEgresos() {
    const egresosMensuales = <number> this.formFinancialData.get('egresosMensuales').value || 0;
    const otrosEgresos = <number> this.formFinancialData.get('otrosEgresos').value || 0;
    this.formFinancialData.get('totalEgresos').setValue(egresosMensuales + otrosEgresos);
  }

  /**
   * Metodo para calcular el total de los ingresos en el formulario
   */
  setPatrimonio() {
    const activos = <number> this.formFinancialData.get('activos').value || 0;
    const pasivos = <number> this.formFinancialData.get('pasivos').value || 0;
    this.formFinancialData.get('patrimonio').setValue(activos - pasivos);
  }
}
