import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormAdditionalInfoComponent } from './form-additional-info.component';

describe('FormAdditionalInfoComponent', () => {
  let component: FormAdditionalInfoComponent;
  let fixture: ComponentFixture<FormAdditionalInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormAdditionalInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormAdditionalInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
