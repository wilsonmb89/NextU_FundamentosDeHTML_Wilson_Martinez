import { Component, OnInit, Input, OnDestroy, Output, EventEmitter, AfterViewInit, ElementRef } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Observable, Subscription } from 'rxjs';
import { CATALOGS_DATA_CUSTOMER } from 'src/app/utils/constants/utils.constant';
import { CatalogoRequest } from 'src/app/shared/utils/mapping/CatalogoRequest';
import { capitalizeText } from 'src/app/shared/utils/functions/transform';
import { idValueCatalogValidator, parentValueCatalogValidator } from 'src/app/shared/utils/validations/CustomValidators';
import { startWith, map } from 'rxjs/operators';
import { CatalogoService } from 'src/app/shared/services/catalogo.service';
import { DatosAdicionalesOrdenante } from 'src/app/utils/models/api-solicitud/DatosAdicionalesOrdenante';
import { DatosOrdenantes } from 'src/app/utils/models/api-solicitud/DatosOrdenantes';
import { AddressValidatorDirective } from 'src/app/shared/utils/directives/address-validator.directive';
import { setScrolIntoView } from 'src/app/shared/utils/functions/utils';
import { ValidAddress } from 'src/app/shared/utils/functions/ValidAddress';

@Component({
  selector: 'app-form-additional-info',
  templateUrl: './form-additional-info.component.html',
  styleUrls: ['./form-additional-info.component.scss']
})
export class FormAdditionalInfoComponent implements OnInit, OnDestroy, AfterViewInit {

  textIng: string;
  textEgr: string;
  cities: any[];
  countries: any[];
  departments: any[];
  paisFavorito: any;
  propertiesForm: string[];
  additionalInfo: FormGroup;
  formChangesSuscriptor: Subscription;
  filteredOptionsPais: Observable<any[]>;
  filteredOptionsDepto: Observable<any[]>;
  filteredOptionsCiudad: Observable<any[]>;
  addressValidator = new AddressValidatorDirective();
  @Input() dataParticipantIn: DatosOrdenantes;
  @Output() closeScreenEmit = new EventEmitter<boolean>();
  @Output() dataParticipantOut = new EventEmitter<DatosOrdenantes>();
  @Output() dataSideBar = new EventEmitter<DatosOrdenantes>();

  constructor(
    private _catalogoService: CatalogoService,
    private _el: ElementRef
  ) { }

  ngOnInit() {
    this.textIng = this.textEgr = "";
    this.getData();
    this.loadCatalogs();
  }

  ngOnDestroy() {
    if (!!this.formChangesSuscriptor) {
      this.formChangesSuscriptor.unsubscribe();
    }
  }

  ngAfterViewInit() {
    const inputList = ([].slice.call((<HTMLElement> this._el.nativeElement).querySelectorAll('input:not(.mat-radio-input)'))).concat([].slice.call((<HTMLElement> this._el.nativeElement).getElementsByTagName('textarea')));
    setScrolIntoView(inputList);
  }

  /**
   * Metodo para filtrar los resultados del catalogo comparado
   * con lo que el usuario escribe
   * @param value Valor proporcionado por el usuario
   */
  private _filterCountry(value: string): string[] {
    const filterValue = !!value ? value.toLowerCase() : "";
    return this.countries.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  /**
   * Metodo para filtrar los resultados del catalogo comparado
   * con lo que el usuario escribe
   * @param value Valor proporcionado por el usuario
   */
  private _filterDepartment(value: any): string[] {
    const filterValue = !!value ? value.toLowerCase() : "";
    return this.departments.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  /**
   * Metodo para filtrar los resultados del catalogo comparado
   * con lo que el usuario escribe
   * @param value Valor proporcionado por el usuario
   */
  private _filterCity(value: any): string[] {
    const filterValue = !!value ? value.toLowerCase() : "";
    return this.cities.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  /**
   * Metodo para obtener la info del objeto y
   * mostrarla en pantalla
   */
  getData() {
    this.additionalInfo = new FormGroup(this.createForm());
    this.resetFields(!!this.dataParticipantIn.datosAdicionales && !!this.dataParticipantIn.datosAdicionales.vinculoEmpresa
      ? this.dataParticipantIn.datosAdicionales.vinculoEmpresa : null);
    this.formChangesSuscriptor = this.additionalInfo.valueChanges.subscribe(() => {
      this.dataParticipantIn.datosAdicionales = this.additionalInfo.value;
      this.dataSideBar.emit(this.dataParticipantIn);
    });
    this.updateForm(this.dataParticipantIn.datosAdicionales);
  }

  /**
   * Metodo para crear las propiedades del formgroup a partir de
   * un modelo como Datos Financieros
   */
  createForm() {
    const additionalInfoDataModel = new DatosAdicionalesOrdenante();
    this.propertiesForm = Object.getOwnPropertyNames(additionalInfoDataModel);
    const object = {};
    this.propertiesForm.forEach((item) => {
      if (item !== "direccion") {
        object[item] = new FormControl(additionalInfoDataModel[item], Validators.required);
      } else {
        object[item] = new FormControl(additionalInfoDataModel[item], [Validators.required, this.addressValidator.addressComparison()]);
      }
    });
    return object;
  }

  /**
   * Metodo para establecer las validaciones del formulario de campos de empresa
   * @param value Valor entregado desde el radio Button o desde el metodo getData()
   */
  resetFields(value: string) {
    if (!!value && value === "si") {
      const fields = ['nombreEmpresa', 'direccionEmpresa', 'cargo', 'paisEmpresa', 'deptoEmpresa', 'ciudadEmpresa', 'telEmpresa'];
      fields.forEach(field => {
        this.additionalInfo.get(field).setValidators([]);
        this.additionalInfo.get(field).reset();
      });
    }
  }

  /**
   * Actualiza el formulario con la data obtenida en SOR
   * @param datosAdicionalesOrdenante corresponden a los datos financieros de la solicitud
   */
  updateForm(datosAdicionalesOrdenante: DatosAdicionalesOrdenante) {
    if (!(!!datosAdicionalesOrdenante)) {
      datosAdicionalesOrdenante = new DatosAdicionalesOrdenante();
    }
    this.additionalInfo.setValue(datosAdicionalesOrdenante);
    this.updateDeptoFilter(this.additionalInfo.get('paisEmpresa').value || '', false);
    this.updateCityFilter(this.additionalInfo.get('deptoEmpresa').value || '', false);
    this.countChars();
  }

  /**
   * Metodo para cargar los catalogos del formulario
   */
  loadCatalogs() {
    CATALOGS_DATA_CUSTOMER.forEach(async element => {
      if (element === "Pais") {
        const catalogoRq = new CatalogoRequest();
        catalogoRq.catalogName = element;
        const catalogoRs = await <any> this._catalogoService.getCatalog(catalogoRq);
        if (!!catalogoRs && !!catalogoRs.catalogName) {
          this.countries = catalogoRs.items;
          this.countries.forEach((element) => {
            element.name = (!!element.name) ? capitalizeText(element.name.toLowerCase()) : '';
            if (element.name === "Colombia") { this.paisFavorito = element; }
          });
          this.filteredOptionsPais = this.additionalInfo.get('paisEmpresa').valueChanges.pipe(startWith(''), map(value => this._filterCountry(value)));
          if (!!this.countries) {
            this.additionalInfo.get("paisEmpresa").setValidators([Validators.maxLength(100), idValueCatalogValidator(this.countries)]);
          }
        }
      }
    });
  }

  /**
   * Metodo para consultar un catalogo via REST en api-catalogo
   * @param catalogName nombre del catalogo a consultar
   * @param idParent consulta de la llave padre
   */
  async loadCatalog(catalogName: string, idParent: string) {
    const catalogoRq = new CatalogoRequest();
    catalogoRq.catalogName = catalogName;
    catalogoRq.idParent = idParent || '';
    const catalogoRs = await this._catalogoService.getCatalog(catalogoRq);
    if (!!catalogoRs) {
      catalogoRs.items.forEach((element: any) => {
        element.name = (!!element.name) ? capitalizeText(element.name.toLowerCase()) : '';
      });
    }
    return catalogoRs;
  }

  /**
   * Metodo que actualiza los departamentos del documento de
   * expedicion de acuerdo al país
   * @param idParent hace referencia al id del pais para consultar
   * los departamentos relacionados
   */
  async updateDeptoFilter(idParent: string, resetFields: boolean) {
    if (!!idParent) {
      if (resetFields) {
        this.additionalInfo.get('deptoEmpresa').setValue('');
        this.additionalInfo.get('ciudadEmpresa').setValue('');
      }
      const catalogoRs = await this.loadCatalog('Departamento', (idParent.split('-')[0].trim() || ''));
      this.departments = catalogoRs.items;
      this.filteredOptionsDepto = this.additionalInfo.get('deptoEmpresa').valueChanges.pipe(startWith(''), map(value => this._filterDepartment(value)));
      this.additionalInfo.get("deptoEmpresa").setValidators([Validators.maxLength(100), parentValueCatalogValidator(this.departments)]);
    }
  }

  /**
   * Metodo para actualizar las ciudades de acuerdo al pais ingresado
   * @param idParent hace referencia al id del departamento para consultar
   * las ciudades relacionadas
   */
  async updateCityFilter(idParent: string, resetFields: boolean) {
    if (!!idParent) {
      if (resetFields) {
        this.additionalInfo.get('ciudadEmpresa').setValue('');
      }
      const catalogoRs = await this.loadCatalog('Ciudad', (idParent.split('-')[0].trim() || ''));
      this.cities = catalogoRs.items;
      this.filteredOptionsCiudad = this.additionalInfo.get('ciudadEmpresa').valueChanges.pipe(startWith(''), map(value => this._filterCity(value)));
      this.additionalInfo.get("ciudadEmpresa").setValidators([Validators.maxLength(100), parentValueCatalogValidator(this.cities)]);
    }
  }

  /**
   * Metodo para mostrar el nombre en un catalogo
   * @param value Valor proporcionado por el catalogo
   */
  displayName(value: any) {
    if (!!value && typeof (value) === "string") {
      const formatText = value.split('-');
      return formatText[1].trim();
    }
  }

  /**
   * Metodo para calcular el total de los ingresos en el formulario
   */
  setTotalIngresos() {
    const ingresosMensuales = <number> this.additionalInfo.get('ingresoMensual').value || 0;
    const otrosIngresos = <number> this.additionalInfo.get('otrosIngresos').value || 0;
    this.additionalInfo.get('totalIngresos').setValue(ingresosMensuales + otrosIngresos);
  }

  /**
   * Metodo para calcular el total de los ingresos en el formulario
   */
  setTotalEgresos() {
    const egresosMensuales = <number> this.additionalInfo.get('egresoMensual').value || 0;
    const otrosEgresos = <number> this.additionalInfo.get('otrosEgresos').value || 0;
    this.additionalInfo.get('totalEgresos').setValue(egresosMensuales + otrosEgresos);
  }

  /**
   * Metodo para calcular el total de los ingresos en el formulario
   */
  setPatrimonio() {
    const activos = <number> this.additionalInfo.get('activos').value || 0;
    const pasivos = <number> this.additionalInfo.get('pasivos').value || 0;
    this.additionalInfo.get('patrimonio').setValue(activos - pasivos);
  }

  countChars() {
    this.textIng = this.additionalInfo.get('detalleIngreso').value;
    this.textEgr = this.additionalInfo.get('detalleEgreso').value;
  }

  /**
   * Metodo para emitir los valores del objeto y cerrar la pantalla
   * @param value Valor booleano para saber si emite o no el objeto anteriormente recibido
   */
  submit(value: boolean) {
    if (value) {
      const validAddress = new ValidAddress();
      this.dataParticipantIn.datosAdicionales.direccionEmpresa = validAddress.validacionDireccion(this.dataParticipantIn.datosAdicionales.direccionEmpresa);
      this.dataParticipantOut.emit(this.dataParticipantIn);
    } else {
      if (!this.additionalInfo.valid) {
        this.dataParticipantIn.datosAdicionales = null;
      }
    }
    this.closeScreenEmit.emit(false);
  }

}
