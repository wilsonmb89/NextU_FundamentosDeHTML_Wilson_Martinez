import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormAuthorizedComponent } from './form-authorized.component';

describe('FormAuthorizedComponent', () => {
  let component: FormAuthorizedComponent;
  let fixture: ComponentFixture<FormAuthorizedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormAuthorizedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormAuthorizedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
