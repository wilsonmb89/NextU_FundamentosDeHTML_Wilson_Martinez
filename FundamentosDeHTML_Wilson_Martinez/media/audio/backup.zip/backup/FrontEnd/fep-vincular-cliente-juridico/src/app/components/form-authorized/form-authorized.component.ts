import { Component, OnInit, Input, Output, EventEmitter, AfterViewInit, ElementRef } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { CatalogoRequest } from 'src/app/shared/utils/mapping/CatalogoRequest';
import { capitalizeText } from 'src/app/shared/utils/functions/transform';
import { CatalogoService } from 'src/app/shared/services/catalogo.service';
import { CustomerService } from 'src/app/services/customer.service';
import { setScrolIntoView } from 'src/app/shared/utils/functions/utils';

@Component({
  selector: 'app-form-authorized',
  templateUrl: './form-authorized.component.html',
  styleUrls: ['./form-authorized.component.scss']
})
export class FormAuthorizedComponent implements OnInit, AfterViewInit {
  formAuthorized: FormGroup;
  propertiesForm: string[];
  @Output() data: EventEmitter<any>;
  @Output() change: EventEmitter<any>;
  @Input() model: any;
  @Input() client: any;
  @Input() typeParticipant: any;

  listDocumentType: any[];
  isNumber: boolean;
  uploadType: boolean;

  constructor(
    private _catalogoService: CatalogoService,
    private _customerService: CustomerService,
    private _el: ElementRef
  ) {
    this.data = new EventEmitter<any>();
    this.change = new EventEmitter<any>();
    this.isNumber = true;
    this.getDocumentType();
  }

  ngOnInit() {
    this.uploadType = false;
    this.formAuthorized = new FormGroup(this.createForm());
    this.setValidators();
    this.formAuthorized.valueChanges.subscribe(() => {
      this.model = this.formAuthorized.value;
      this.change.emit(this.formAuthorized);
    });
    this.updateForm();
  }

  ngAfterViewInit() {
    const inputList = ([].slice.call((<HTMLElement> this._el.nativeElement).querySelectorAll('input:not(.mat-radio-input)'))).concat([].slice.call((<HTMLElement> this._el.nativeElement).getElementsByTagName('textarea')));
    setScrolIntoView(inputList);
  }

  createForm() {
    this.propertiesForm = Object.getOwnPropertyNames(this.model);
    const object = {};
    this.propertiesForm.forEach((item) => {
      if (item === "isCliente") {
        object[item] = new FormControl(this.model[item] || false , []);
      } else {
        object[item] = new FormControl(this.model[item], Validators.required);
      }
    });
    return object;
  }
  setValidators() {
    this.formAuthorized.get("nombre").setValidators([Validators.required]);
  }
  async submit() {
    await this.searchCustomer();
    this.data.emit(this.formAuthorized);
  }
  async getDocumentType() {
    const documents = ["1", "2", "7"];
    const typeDocuments = await this.getCatalog("TipoDocumento", null);
    this.listDocumentType = typeDocuments.filter(doc => documents.indexOf(doc.id) > -1);
  }
  validateTypeDocument(item: any) {
    this.formAuthorized.get("numeroDocumento").setValue("");
    this.isNumber = item.value.split("-")[0] === "1";
  }
  /**
   * Metodo para mostrar el nombre en un catalogo
   * @param value Valor proporcionado por el catalogo
   */
  displayName(value) {
    if (!!value) {
      return value.split('-')[1].trim();
    }
  }
  async getCatalog(catalogName: string, id: string) {
    const catalogoRq = new CatalogoRequest();
    catalogoRq.catalogName = catalogName;
    catalogoRq.idParent = id || '';
    const items = await this._catalogoService.getCatalog(catalogoRq);
    items.items.forEach(element => element.name = capitalizeText(element.name.toLowerCase()));
    return items.items;
  }
  updateForm() {
    this.formAuthorized.setValue(this.model);
  }

  /**
   * Metodo para buscar un representante legal en la base de datos de BTG
   */
  async searchCustomer() {
    if (!!this.formAuthorized
        && !!this.formAuthorized.get('numeroDocumento')
        && !!this.formAuthorized.get('numeroDocumento').value
        && !!this.formAuthorized.get('tipoDocumento')
        && !!this.formAuthorized.get('tipoDocumento').value) {
      const numeroIdentificacion = this.formAuthorized.get('numeroDocumento').value.replace(/\./g, '');
      const tipoIdentificacion = this.formAuthorized.get('tipoDocumento').value.split("-")[0].trim();
      const querySearchCustomer = {
        "query": "query clienteExiste($tipoIdenti: String!, $numIdenti: String!){ clienteExiste(tipoIdentificacion: $tipoIdenti, numeroIdentificacion: $numIdenti){ existe, personaJuridica { datosContactoPJ { comercialRM, nombre, direccion, telefono, pais, departamento, ciudad, correo  } } } }",
        "variables": {
            "tipoIdenti": tipoIdentificacion || "",
            "numIdenti": numeroIdentificacion || ""
        },
        "operationName": "clienteExiste"
      };
      const getCustRs = await this._customerService.getCustomer(querySearchCustomer);
      if (!!getCustRs) {
        const isCliente = !!getCustRs.data && !!getCustRs.data.clienteExiste ? getCustRs.data.clienteExiste.existe || false : false;
        this.formAuthorized.get('isCliente').setValue(isCliente);
      }
    }
  }
  /** Metodo que actualiza el formulario cuando se carga el documento */
  updateDocument(data: any) {
    this.formAuthorized.setValue(data);
    const nombre = this.formAuthorized.get("nombre");
    this.uploadType = true;
    nombre.setValue(nombre.value);
  }
}
