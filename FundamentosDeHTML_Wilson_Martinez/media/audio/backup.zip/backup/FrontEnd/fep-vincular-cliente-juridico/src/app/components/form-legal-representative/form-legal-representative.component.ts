import { Component, OnInit, Output, EventEmitter, Input, AfterViewInit, ElementRef } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import * as moment from 'moment';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material';
import { APP_DATE_FORMATS, AppDateAdapter } from 'src/app/shared/utils/functions/adapter';
import { CatalogoService } from 'src/app/shared/services/catalogo.service';
import { CatalogoRequest } from 'src/app/shared/utils/mapping/CatalogoRequest';
import { startWith, map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { parentValueCatalogValidator, idValueCatalogValidator } from 'src/app/shared/utils/validations/CustomValidators';
import { capitalizeText } from 'src/app/shared/utils/functions/transform';
import { CustomerService } from 'src/app/services/customer.service';
import { setScrolIntoView } from 'src/app/shared/utils/functions/utils';
import { ValidAddress } from 'src/app/shared/utils/functions/ValidAddress';

@Component({
  selector: 'app-form-legal-representative',
  templateUrl: './form-legal-representative.component.html',
  styleUrls: ['./form-legal-representative.component.scss'],
  providers: [
    { provide: DateAdapter, useClass: AppDateAdapter },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS }
  ]
})
export class FormLegalRepresentativeComponent implements OnInit, AfterViewInit {
  formLegalRepresentative: FormGroup;
  propertiesForm: string[];
  @Output() data: EventEmitter<any>;
  @Output() change: EventEmitter<any>;
  @Input() model: any;
  @Input() client: any;
  @Input() typeParticipant: any;

  maxDate = moment().subtract(18, 'years').add(1, 'days').format('YYYY-MM-DD');
  listDocumentType: any[];
  listCountries: any[];
  listCIIU: any[];
  listOcupacion: any[];
  firstCountry: any;
  filterPaisExpedicion: Observable<string[]>;
  filterDepartamentoExpedicion: Observable<string[]>;
  filterCiudadExpedicion: Observable<string[]>;
  filterPaisNacimiento: Observable<string[]>;
  filterDepartamentoNacimiento: Observable<string[]>;
  filterCiudadNacimiento: Observable<string[]>;
  filterPaisResidencia: Observable<string[]>;
  filterDepartamentoResidencia: Observable<string[]>;
  filterCiudadResidencia: Observable<string[]>;
  filterOptionsCodigosCiiu: Observable<string[]>;
  filterOptionsOcupacion: Observable<string[]>;
  isNumber: boolean;
  uploadType: boolean;

  constructor(
    private _catalogoService: CatalogoService,
    private _customerService: CustomerService,
    private _el: ElementRef
  ) {
    this.data = new EventEmitter<any>();
    this.change = new EventEmitter<any>();
    this.isNumber = true;
    this.getDocumentType();
  }
  ngOnInit() {
    this.uploadType = false;
    this.formLegalRepresentative = new FormGroup(this.createForm());
    this.formLegalRepresentative.valueChanges.subscribe(() => {
      this.model = this.formLegalRepresentative.value;
      this.change.emit(this.formLegalRepresentative);
    });
    this.loadCountries();
    this.loadCiiu();
    this.loadOcupacion();
    this.updateForm();
  }

  ngAfterViewInit() {
    const inputList = ([].slice.call((<HTMLElement> this._el.nativeElement).querySelectorAll('input:not(.mat-radio-input)'))).concat([].slice.call((<HTMLElement> this._el.nativeElement).getElementsByTagName('textarea')));
    setScrolIntoView(inputList);
  }

  createForm() {
    this.propertiesForm = Object.getOwnPropertyNames(this.model);
    const object = {};
    this.propertiesForm.forEach((item) => {
      if (item === "isCliente") {
        object[item] = new FormControl(this.model[item] || false, []);
      } else if (item === "codigoCIIU" && this.model["ocupacion"] === "OCUP_4 - Otra") {
        object[item] = new FormControl(this.model[item]);
      } else {
        object[item] = new FormControl(this.model[item], Validators.required);
      }
    });
    return object;
  }
  async submit() {
    await this.searchCustomer();
    const validAddress = new ValidAddress();
    this.formLegalRepresentative.get("direccionResidencia").setValue(validAddress.validacionDireccion(this.formLegalRepresentative.get("direccionResidencia").value));
    this.data.emit(this.formLegalRepresentative);
  }
  setValidators() {
    this.formLegalRepresentative.get("nombre").setValidators([Validators.required]);
    this.formLegalRepresentative.get("paisExpedicion").setValidators([Validators.required, Validators.maxLength(100), idValueCatalogValidator(this.listCountries)]);
    this.formLegalRepresentative.get("paisNacimiento").setValidators([Validators.required, Validators.maxLength(100), idValueCatalogValidator(this.listCountries)]);
    this.formLegalRepresentative.get("paisResidencia").setValidators([Validators.required, Validators.maxLength(100), idValueCatalogValidator(this.listCountries)]);
  }
  async getDocumentType() {
    const documents = ["1", "2", "7"];
    const typeDocuments = await this.getCatalog("TipoDocumento", null);
    this.listDocumentType = typeDocuments.filter(doc => documents.indexOf(doc.id) > -1);
  }
  validateTypeDocument(item: any) {
    this.formLegalRepresentative.get("numeroDocumento").setValue("");
    this.isNumber = item.value.split("-")[0] === "1";
  }
  /**
   * Metodo para mostrar el nombre en un catalogo
   * @param value Valor proporcionado por el catalogo
   */
  displayName(value) {
    if (!!value) {
      return value.split('-')[1].trim();
    }
  }
  /** Metodo que realiza el cargue del catalogo
   * @param catalogName nombre del catalogo
   * @param id referencia de un catalogo padre
   */
  async getCatalog(catalogName: string, id: string) {
    const catalogoRq = new CatalogoRequest();
    catalogoRq.catalogName = catalogName;
    catalogoRq.idParent = id || '';
    const items = await this._catalogoService.getCatalog(catalogoRq);
    items.items.forEach(element => element.name = capitalizeText(element.name.toLowerCase()));
    return items.items;
  }

  /**
   * Metodo para cargar el autocomplete de Ocupacion a partir
   * del catalogo de base de datos
   */
  async loadOcupacion() {
    this.listOcupacion = await this.getCatalog("Ocupacion", null);
    if (!!this.listOcupacion) {
      this.formLegalRepresentative.get("ocupacion").setValidators([Validators.required, Validators.maxLength(100), idValueCatalogValidator(this.listOcupacion)]);
      this.filterOptionsOcupacion = this.formLegalRepresentative.get("ocupacion").valueChanges.pipe(startWith(''), map(value => this.filterByArray(value, this.listOcupacion)));
    }
  }

  /**
   * Metodo para cargar el autocomplete de codigos CIIU a partir
   * del catalogo de base de datos
   */
  async loadCiiu() {
    this.listCIIU = await this.getCatalog("CIIU", null);
    if (!!this.listCIIU) {
      this.formLegalRepresentative.get("codigoCIIU").setValidators([Validators.maxLength(100), idValueCatalogValidator(this.listCIIU)]);
      this.filterOptionsCodigosCiiu = this.formLegalRepresentative.get("codigoCIIU").valueChanges.pipe(startWith(''), map(value => this.filterByArray(value, this.listCIIU)));
    }
  }

  async loadCountries() {
    const listCountries = await this.getCatalog("Pais", null);
    this.listCountries = listCountries;
    this.firstCountry = this.listCountries.filter(country => country.name === "Colombia")[0];
    this.setValidators();
    this.filterCountry();
  }
  filterCountry() {
    this.filterPaisExpedicion = this.formLegalRepresentative.get("paisExpedicion").valueChanges
      .pipe(startWith(''), map(value => this.filterByArray(value, this.listCountries)));
    this.filterPaisNacimiento = this.formLegalRepresentative.get("paisNacimiento").valueChanges
      .pipe(startWith(''), map(value => this.filterByArray(value, this.listCountries)));
    this.filterPaisResidencia = this.formLegalRepresentative.get("paisResidencia").valueChanges
      .pipe(startWith(''), map(value => this.filterByArray(value, this.listCountries)));
  }
  /**
   * Metodo para filtrar los resultados del catalogo comparado
   * con lo que el usuario escribe
   * @param value Valor proporcionado por el usuario
   */
  private filterByArray(value: string, array: any[]): string[] {
    const filterValue = value ? value.toLowerCase() : "";
    return array.filter(option => !!option && option.name && option.name.toLowerCase().includes(filterValue));
  }
  async updateDeptoFilter(idParent, control: string, reset: boolean) {
    if (idParent) {
      const depto = control.replace("pais", "departamento");
      const ciudad = control.replace("pais", "ciudad");
      if (reset) {
        this.formLegalRepresentative.get(depto).setValue('');
        this.formLegalRepresentative.get(ciudad).setValue('');
      }
      const listDepartamentos = await this.getCatalog('Departamento', idParent.split('-')[0].trim());
      if (control === "paisNacimiento") {
        this.filterDepartamentoNacimiento = this.formLegalRepresentative.get(depto).valueChanges.pipe(startWith(''), map(value => this.filterByArray(value, listDepartamentos)));
      }
      if (control === "paisResidencia") {
        this.filterDepartamentoResidencia = this.formLegalRepresentative.get(depto).valueChanges.pipe(startWith(''), map(value => this.filterByArray(value, listDepartamentos)));
      }
      if (control === "paisExpedicion") {
        this.filterDepartamentoExpedicion = this.formLegalRepresentative.get(depto).valueChanges.pipe(startWith(''), map(value => this.filterByArray(value, listDepartamentos)));
      }
      this.formLegalRepresentative.get(depto).setValidators([Validators.maxLength(100), parentValueCatalogValidator(listDepartamentos)]);
    }
  }
  /** Metodo para la actulizacion segun el departamento */
  async updateCityFilter(idParent, control: string, reset: boolean) {
    if (idParent) {
      const ciudad = control.replace("departamento", "ciudad");
      if (reset) {
        this.formLegalRepresentative.get(ciudad).setValue('');
      }
      const listCities = await this.getCatalog('Ciudad', idParent.split('-')[0].trim());
      if (control === "departamentoNacimiento") {
        this.filterCiudadNacimiento = this.formLegalRepresentative.get(ciudad).valueChanges.pipe(startWith(''), map(value => this.filterByArray(value, listCities)));
      }
      if (control === "departamentoResidencia") {
        this.filterCiudadResidencia = this.formLegalRepresentative.get(ciudad).valueChanges.pipe(startWith(''), map(value => this.filterByArray(value, listCities)));
      }
      if (control === "departamentoExpedicion") {
        this.filterCiudadExpedicion = this.formLegalRepresentative.get(ciudad).valueChanges.pipe(startWith(''), map(value => this.filterByArray(value, listCities)));
      }
      this.formLegalRepresentative.get(ciudad).setValidators([Validators.maxLength(100), parentValueCatalogValidator(listCities)]);
    }
  }
  /** Metodo que actualiza el formulaciro */
  updateForm() {
    this.formLegalRepresentative.setValue(this.model);
    this.updateDeptoFilter(this.formLegalRepresentative.get('paisExpedicion').value || '', 'paisExpedicion', false);
    this.updateCityFilter(this.formLegalRepresentative.get('departamentoExpedicion').value || '', 'departamentoExpedicion', false);
    this.updateDeptoFilter(this.formLegalRepresentative.get('paisNacimiento').value || '', 'paisNacimiento', false);
    this.updateCityFilter(this.formLegalRepresentative.get('departamentoNacimiento').value || '', 'departamentoNacimiento', false);
    this.updateDeptoFilter(this.formLegalRepresentative.get('paisResidencia').value || '', 'paisResidencia', false);
    this.updateCityFilter(this.formLegalRepresentative.get('departamentoResidencia').value || '', 'departamentoResidencia', false);
  }

  /**
   * Metodo para buscar un representante legal en la base de datos de BTG
   */
  async searchCustomer() {
    if (!!this.formLegalRepresentative
      && !!this.formLegalRepresentative.get('numeroDocumento')
      && !!this.formLegalRepresentative.get('numeroDocumento').value
      && !!this.formLegalRepresentative.get('tipoDocumento')
      && !!this.formLegalRepresentative.get('tipoDocumento').value) {
      const numeroIdentificacion = this.formLegalRepresentative.get('numeroDocumento').value.replace(/\./g, '');
      const tipoIdentificacion = this.formLegalRepresentative.get('tipoDocumento').value.split("-")[0].trim();
      const querySearchCustomer = {
        "query": "query clienteExiste($tipoIdenti: String!, $numIdenti: String!){ clienteExiste(tipoIdentificacion: $tipoIdenti, numeroIdentificacion: $numIdenti){ existe, personaJuridica { datosContactoPJ { comercialRM, nombre, direccion, telefono, pais, departamento, ciudad, correo  } } } }",
        "variables": {
          "tipoIdenti": tipoIdentificacion || "",
          "numIdenti": numeroIdentificacion || ""
        },
        "operationName": "clienteExiste"
      };
      const getCustRs = await this._customerService.getCustomer(querySearchCustomer);
      if (!!getCustRs) {
        const isCliente = !!getCustRs.data && !!getCustRs.data.clienteExiste ? getCustRs.data.clienteExiste.existe || false : false;
        this.formLegalRepresentative.get('isCliente').setValue(isCliente);
      }
    }
  }

  /**
   * Metodo para mostrar el nombre en un catalogo especial para CIIU
   * @param value Valor proporcionado por el catalogo
   */
  displayNameCIIU(value) {
    let result = "";
    if (!!value && typeof (value) === "string") {
      const formatText = value.split('-');
      try {
        result = formatText[1].trim().concat(' - ').concat(formatText[2].trim());
      } catch (error) {
        result = formatText[1].trim();
      }
    }
    return result;
  }

  /**
   * Metodo para controlar la obligatoriedad de la actividad económica, que dependen del valor de la ocupacion
   * @param value valor que corresponde a la ocupacion
   */
  checkOcupacion(value) {
    if (value === 'OCUP_4 - Otra') {
      this.formLegalRepresentative.get('codigoCIIU').setValidators([Validators.maxLength(100), idValueCatalogValidator(this.listCIIU)]);
    } else {
      this.formLegalRepresentative.get('codigoCIIU').setValidators([Validators.required, Validators.maxLength(100), idValueCatalogValidator(this.listCIIU)]);
    }
    this.formLegalRepresentative.get('codigoCIIU').reset();
  }
  /** Metodo que actualiza el formulario cuando se carga el documento */
  updateDocument(data: any) {
    this.formLegalRepresentative.get("datosDocumento").setValue(data.datosDocumento);
    this.uploadType = true;
  }
}
