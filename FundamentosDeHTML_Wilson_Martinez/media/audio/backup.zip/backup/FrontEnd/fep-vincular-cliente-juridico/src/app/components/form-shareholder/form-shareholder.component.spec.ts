import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FormShareholderComponent } from './form-shareholder.component';

describe('FormShareholderComponent', () => {
  let component: FormShareholderComponent;
  let fixture: ComponentFixture<FormShareholderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FormShareholderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FormShareholderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
