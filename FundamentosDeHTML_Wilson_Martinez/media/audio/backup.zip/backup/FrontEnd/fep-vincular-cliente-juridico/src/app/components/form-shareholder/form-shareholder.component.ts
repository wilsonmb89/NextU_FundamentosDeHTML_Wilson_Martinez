import { Component, OnInit, Output, Input, EventEmitter, AfterViewInit, ElementRef } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { CatalogoRequest } from 'src/app/shared/utils/mapping/CatalogoRequest';
import { CatalogoService } from 'src/app/shared/services/catalogo.service';
import { startWith, map } from 'rxjs/operators';
import { capitalizeText } from 'src/app/shared/utils/functions/transform';
import { idValueCatalogValidator } from 'src/app/shared/utils/validations/CustomValidators';
import { CustomerService } from 'src/app/services/customer.service';
import { setScrolIntoView } from 'src/app/shared/utils/functions/utils';
import { getVerificationCode } from 'src/app/utils/functions/verificationCode';

@Component({
  selector: 'app-form-shareholder',
  templateUrl: './form-shareholder.component.html',
  styleUrls: ['./form-shareholder.component.scss']
})
export class FormShareholderComponent implements OnInit, AfterViewInit {
  formShareHolder: FormGroup;
  propertiesForm: string[];
  @Output() data: EventEmitter<any>;
  @Output() change: EventEmitter<any>;
  @Input() model: any;
  @Input() client: any;
  @Input() typeParticipant: any;

  listDocumentType: any[];
  listCountries: any[];
  firstCountry: any;
  typeField: number;
  filterPaisNacimiento: Observable<string[]>;
  uploadType: boolean;

  constructor(
    private _catalogoService: CatalogoService,
    private _customerService: CustomerService,
    private _el: ElementRef
  ) {
    this.data = new EventEmitter<any>();
    this.change = new EventEmitter<any>();
    this.typeField = 1;
  }

  ngOnInit() {
    this.uploadType = false;
    this.formShareHolder = new FormGroup(this.createForm());
    this.formShareHolder.valueChanges.subscribe(() => {
      this.model = this.formShareHolder.value;
      this.change.emit(this.formShareHolder);
    });
    this.updateForm();
    this.loadCountries();
    this.getDocumentType();
  }

  ngAfterViewInit() {
    const inputList = ([].slice.call((<HTMLElement> this._el.nativeElement).querySelectorAll('input:not(.mat-radio-input)'))).concat([].slice.call((<HTMLElement> this._el.nativeElement).getElementsByTagName('textarea')));
    setScrolIntoView(inputList);
  }

  createForm() {
    this.propertiesForm = Object.getOwnPropertyNames(this.model);
    const object = {};
    this.propertiesForm.forEach((item) => {
      if (item === "isCliente") {
        object[item] = new FormControl(this.model[item] || false , []);
      } else {
        object[item] = new FormControl(this.model[item], Validators.required);
      }
    });
    return object;
  }
  async submit() {
    await this.searchCustomer();
    this.data.emit(this.formShareHolder);
  }
  setValidators() {
    this.formShareHolder.get("nombre").setValidators([Validators.required]);
    this.formShareHolder.get("paisNacimiento").setValidators([Validators.required, Validators.maxLength(100), idValueCatalogValidator(this.listCountries)]);
    this.formShareHolder.get("participacion").setValidators([Validators.required, Validators.min(5), Validators.max(100)]);
  }
  async getDocumentType() {
    const documents = ["1", "2", "5", "6", "7"];
    const typeDocuments = await this.getCatalog("TipoDocumento", null);
    this.listDocumentType = typeDocuments.filter(doc => documents.indexOf(doc.id) > -1);
  }
  validateTypeDocument(item: any) {
    this.formShareHolder.get("numeroDocumento").setValue("");
    this.typeField = item.value.split("-")[0] === "1" ? 1 :
      item.value.split("-")[0] === "2" || item.value.split("-")[0] === "6" || item.value.split("-")[0] === "7" ? 2 : 3;
  }
  /**
   * Metodo para mostrar el nombre en un catalogo
   * @param value Valor proporcionado por el catalogo
   */
  displayName(value) {
    if (!!value) {
      return value.split('-')[1].trim();
    }
  }
  async getCatalog(catalogName: string, id: string) {
    const catalogoRq = new CatalogoRequest();
    catalogoRq.catalogName = catalogName;
    catalogoRq.idParent = id || '';
    const items = await this._catalogoService.getCatalog(catalogoRq);
    items.items.forEach(element => element.name = capitalizeText(element.name.toLowerCase()));
    return items.items;
  }
  async loadCountries() {
    const listCountries = await this.getCatalog("Pais", null);
    this.listCountries = listCountries;
    this.firstCountry = this.listCountries.filter(country => country.name === "Colombia")[0];
    this.setValidators();
    this.filterCountry();
  }
  filterCountry() {
    this.filterPaisNacimiento = this.formShareHolder.get("paisNacimiento").valueChanges
      .pipe(startWith(''), map(value => this.filterByArray(value, this.listCountries)));
  }
  /**
   * Metodo para filtrar los resultados del catalogo comparado
   * con lo que el usuario escribe
   * @param value Valor proporcionado por el usuario
   */
  private filterByArray(value: string, array: any[]): string[] {
    const filterValue = value ? value.toLowerCase() : "";
    return array.filter(option => option.name.toLowerCase().includes(filterValue));
  }
  updateForm() {
    this.formShareHolder.setValue(this.model);
  }

  /**
   * Metodo para buscar un representante legal en la base de datos de BTG
   */
  async searchCustomer() {
    if (!!this.formShareHolder
        && !!this.formShareHolder.get('numeroDocumento')
        && !!this.formShareHolder.get('numeroDocumento').value
        && !!this.formShareHolder.get('tipoDocumento')
        && !!this.formShareHolder.get('tipoDocumento').value) {
      const numeroIdentificacion = this.formShareHolder.get('numeroDocumento').value.replace(/\./g, '');
      const tipoIdentificacion = this.formShareHolder.get('tipoDocumento').value.split("-")[0].trim();
      const querySearchCustomer = {
        "query": "query clienteExiste($tipoIdenti: String!, $numIdenti: String!){ clienteExiste(tipoIdentificacion: $tipoIdenti, numeroIdentificacion: $numIdenti){ existe, personaJuridica { datosContactoPJ { comercialRM, nombre, direccion, telefono, pais, departamento, ciudad, correo  } } } }",
        "variables": {
            "tipoIdenti": tipoIdentificacion || "",
            "numIdenti": numeroIdentificacion || ""
        },
        "operationName": "clienteExiste"
      };
      const getCustRs = await this._customerService.getCustomer(querySearchCustomer);
      if (!!getCustRs) {
        const isCliente = !!getCustRs.data && !!getCustRs.data.clienteExiste ? getCustRs.data.clienteExiste.existe || false : false;
        this.formShareHolder.get('isCliente').setValue(isCliente);
      }
    }
  }
  /** Metodo que actualiza el formulario cuando se carga el documento */
  updateDocument(data: any) {
    this.formShareHolder.setValue(data);
    const nombre = this.formShareHolder.get("nombre");
    this.uploadType = true;
    nombre.setValue(nombre.value);
  }
  /**
   * Metodo para construir el NIT de acuerdo a los digitos que se incluyan
   * @param keyup evento del teclado
   */
  setNit(keyup) {
    let nitValue = this.formShareHolder.get('numeroDocumento').value;
    if (!!nitValue && keyup.key !== "Backspace") {
      nitValue = nitValue.replace(/\D/g, '');
      if (nitValue.length === 9) {
        const verificationCode = getVerificationCode(nitValue);
        const newValue = nitValue.replace(/\B(?=(\d{3})+(?!\d))/g, ".") + "-" + verificationCode;
        this.formShareHolder.get('numeroDocumento').setValue(newValue);
      } else if (nitValue.length === 10) {
        let newValue = "";
        for (let x = 0 ; x < nitValue.length ; x++) {
          if (x % 3 === 0 && x !== 0 && x < 9) {
            newValue = newValue.concat(".");
          } else if (x === 9) {
            newValue = newValue.concat("-");
          }
          newValue = newValue.concat(nitValue[x]);
        }
        this.formShareHolder.get('numeroDocumento').setValue(newValue);
      }
    }
  }
}
