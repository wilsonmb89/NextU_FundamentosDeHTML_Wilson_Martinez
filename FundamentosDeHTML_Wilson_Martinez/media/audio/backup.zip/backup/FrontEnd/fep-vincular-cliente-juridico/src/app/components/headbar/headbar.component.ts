import { Component, OnInit, Input } from '@angular/core';
import { getTokenValue } from 'src/app/utils/functions/tokenUtils';
import { Router } from '@angular/router';

@Component({
  selector: 'app-headbar',
  templateUrl: './headbar.component.html',
  styleUrls: ['./headbar.component.scss']
})
export class HeadbarComponent implements OnInit {

  userName: string;

  constructor(
    private _router: Router
  ) { }

  ngOnInit() {
    this.userName = getTokenValue('fullName');
  }

  /**
   * Metodo para cerrar la sesion del usuario y redirigirlo al login
   */
  closeSession() {
    localStorage.removeItem('token');
    document.cookie = "Authorization=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
    this.redirectUrl('/portal/');
  }

  /**
   * Metodo para navegar a una url externa
   */
  redirectUrl(url) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      this._router.navigate(['/externalRedirect', { externalUrl: domain }], {
        skipLocationChange: true,
      });
    }
  }

}
