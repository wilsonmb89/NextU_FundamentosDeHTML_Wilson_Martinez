import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InternationalOperationsComponent } from './international-operations.component';

describe('InternationalOperationsComponent', () => {
  let component: InternationalOperationsComponent;
  let fixture: ComponentFixture<InternationalOperationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InternationalOperationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InternationalOperationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
