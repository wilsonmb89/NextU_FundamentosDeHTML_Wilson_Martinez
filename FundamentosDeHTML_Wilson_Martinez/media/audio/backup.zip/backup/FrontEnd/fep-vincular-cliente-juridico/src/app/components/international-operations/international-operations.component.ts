import { Observable } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { Component, OnInit, Output, EventEmitter, ElementRef, AfterViewInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { CATALOGS_DATA_CUSTOMER } from 'src/app/utils/constants/utils.constant';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { capitalizeText } from 'src/app/shared/utils/functions/transform';
import { CatalogoService } from 'src/app/shared/services/catalogo.service';
import { CatalogoRequest } from 'src/app/shared/utils/mapping/CatalogoRequest';
import { idValueCatalogValidator } from 'src/app/shared/utils/validations/CustomValidators';
import { getDatosOperacionesInt, updateDatosOperacionInt } from 'src/app/utils/mapping/SolicitudMapping';
import { setScrolIntoView } from 'src/app/shared/utils/functions/utils';

@Component({
  selector: 'app-international-operations',
  templateUrl: './international-operations.component.html',
  styleUrls: ['./international-operations.component.scss']
})
export class InternationalOperationsComponent implements OnInit, AfterViewInit {

  countries: any[];
  paisFavorito: any;
  listOperations: any;
  redirectLogin: boolean;
  showErrorModal: boolean;
  intOperations: FormGroup;
  datosSolicitud: DatosSolicitud;
  filteredOptionsPais: Observable<any[]>;
  @Output() validEmit: EventEmitter<any> = new EventEmitter();
  @Output() solicitudEmit: EventEmitter<any> = new EventEmitter();
  CONST_NAME_PAGE = "OPERACIONES_INTERNACIONALES";
  nameComponent = "InternationalOperationsComponent";

  constructor(
    private _catalogoService: CatalogoService,
    private _el: ElementRef
  ) {
    this.listOperations = [
      {id: 1, name: "Exportación / Importación", checked: false},
      {id: 2, name: "Cuentas bancarias", checked: false},
      {id: 3, name: "Mercado no Regulado", checked: false},
      {id: 4, name: "Endeudamiento Externo", checked: false},
      {id: 5, name: "Cuentas de compensación", checked: false},
      {id: 6, name: "Turismo", checked: false},
      {id: 7, name: "Derivados", checked: false},
      {id: 8, name: "Inversiones Internacionales", checked: false},
      {id: 9, name: "Diplomáticos", checked: false}
    ];
  }

  ngOnInit() {
    this.validEmit.emit(this.validateSubmit());
    this.solicitudEmit.emit(this.processSolicitudData(this.datosSolicitud));
    this.loadCatalogs();
  }

  ngAfterViewInit() {
    const inputList = ([].slice.call((<HTMLElement> this._el.nativeElement).querySelectorAll('input:not(.mat-radio-input)'))).concat([].slice.call((<HTMLElement> this._el.nativeElement).getElementsByTagName('textarea')));
    setScrolIntoView(inputList);
  }

  /**
   * Metodo para filtrar los resultados del catalogo comparado
   * con lo que el usuario escribe
   * @param value Valor proporcionado por el usuario
   */
  private _filterCountry(value: string): string[] {
    const filterValue = !!value ? value.toLowerCase() : "";
    return this.countries.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  /**
   * Metodo para agregar los checkbox al formulario
   */
  private async _addCheckboxes() {
    const datosOperacionesInternacionales = this.datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales;
    if (datosOperacionesInternacionales) {
      this.listOperations = datosOperacionesInternacionales.operacion;
    }
    this.listOperations.forEach((item, index) => {
      const control = new FormControl(item.checked);
      (this.intOperations.controls.operaciones as FormArray).push(control);
    });
  }

  /**
   * Metodo para obtener la data previa en SOR
   * @param dataSolicitud Objeto entregado por el padre
   */
  async getSolicitudSor(dataSolicitud: DatosSolicitud) {
    this.datosSolicitud = dataSolicitud;
    this.initForm();
    await this.updateFormDataFromSOR(this.datosSolicitud);
    await this._addCheckboxes();
    this.validEmit.emit(this.validateSubmit());
    this.solicitudEmit.emit(this.processSolicitudData(this.datosSolicitud));
  }

  /**
   * Metodo para crear los campos del formulario
   */
  initForm() {
    this.intOperations = new FormGroup({
      operacionMonedaExt: new FormControl('', [Validators.required]),
      operaciones: new FormArray([]),
      tipoProducto: new FormControl('', [Validators.maxLength(60)]),
      nombreEntidad: new FormControl('', [Validators.maxLength(60)]),
      monto: new FormControl('', [Validators.maxLength(25), Validators.min(1)]),
      pais: new FormControl('', [Validators.maxLength(100)]),
      moneda: new FormControl('', [Validators.maxLength(60)])
    });
  }

  /**
   * Metodo para reanudar la actividad con la informacion
   * obtenida en SOR y sincronizada en el formulario
   * @param dataSolicitud Objeto entregado por el padre
   */
  async updateFormDataFromSOR(dataSolicitud: DatosSolicitud) {
    this.intOperations = getDatosOperacionesInt(this.intOperations, dataSolicitud);
  }

  /**
   * Metodo para valdidar los campos del formulario
   */
  validateSubmit(): boolean {
    let validSectionExt = true;
    const someCheck = this.intOperations.get("operaciones").value.filter(item => item);
    if (this.intOperations.get('operacionMonedaExt').value === "si") {
      validSectionExt = !!this.intOperations.get('tipoProducto').value
        && this.intOperations.get('tipoProducto').valid
        && !!this.intOperations.get('nombreEntidad').value
        && this.intOperations.get('nombreEntidad').valid
        && !!this.intOperations.get('monto').value
        && this.intOperations.get('monto').valid
        && !!this.intOperations.get('pais').value
        && this.intOperations.get('pais').valid
        && !!this.intOperations.get('moneda').value
        && this.intOperations.get('moneda').valid
        && someCheck.length > 0;
    }
    return (
      !!this.intOperations
      && !!this.intOperations.get('operacionMonedaExt').value
      && this.intOperations.get('operacionMonedaExt').valid
      && validSectionExt
    );
  }

  /**
   * Metodo para obtener los controls de resources
   */
  getFormResources() {
    return this.intOperations.controls.operaciones["controls"];
  }

  /**
   * Metodo para validar si hay un recurso diferente a los establecidos
   */
  addOtherResource() {
    const someCheck = this.intOperations.get("operaciones").value.filter(item => item);
    if (someCheck.length > 0) {
      this.processSolicitudData(this.datosSolicitud);
    } else {
      this.datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales.operacion = undefined;
    }
  }

  /**
   * Metodo para cargar los catalogos del formulario
   */
  loadCatalogs() {
    CATALOGS_DATA_CUSTOMER.forEach(async element => {
      if (element === "Pais") {
        const catalogoRq = new CatalogoRequest();
        catalogoRq.catalogName = element;
        const catalogoRs = await <any> this._catalogoService.getCatalog(catalogoRq);
        if (!!catalogoRs && !!catalogoRs.catalogName) {
          this.countries = catalogoRs.items;
          this.countries.forEach((element) => {
            element.name = (!!element.name) ? capitalizeText(element.name.toLowerCase()) : '';
            if (element.name === "Colombia") { this.paisFavorito = element; }
          });
          this.filteredOptionsPais = this.intOperations.get('pais').valueChanges.pipe(startWith(''), map(value => this._filterCountry(value)));
          if (!!this.countries) {
            this.intOperations.get("pais").setValidators([Validators.maxLength(100), idValueCatalogValidator(this.countries)]);
          }
        }
      }
    });
  }

  /**
   * Metodo para mostrar el nombre en un catalogo
   * @param value Valor proporcionado por el catalogo
   */
  displayName(value: any) {
    if (!!value && typeof (value) === "string") {
      const formatText = value.split('-');
      return formatText[1].trim();
    }
  }

  /**
   * Metodo que almacena la informacion de los formularios en
   * el canonico que se va almacenar en SOR
   * @param dataSolicitud Objeto entregado por el padre
   */
  async processSolicitudData(dataSolicitud: DatosSolicitud) {
    return this.datosSolicitud = updateDatosOperacionInt(dataSolicitud, this.intOperations, this.listOperations);
  }

  /**
   * Metodo para resetear el estado de un campo a su valor original
   */
  resetFields() {
    const formFields = ['operaciones', 'tipoProducto', 'nombreEntidad', 'monto', 'pais', 'moneda'];
    formFields.forEach(field => {
      this.intOperations.get(field).reset();
    });
  }

  /**
   * Metodo que emite la validacion y objeto del
   * componente hijo al componente padre
   * @param value Valor opcional para setear campos checkbox
   */
  dataEmit(value?: string) {
    if (!!value) {
      if (value === "no") { this.resetFields(); }
      this.intOperations.get('operacionMonedaExt').setValue(value);
    }
    this.validEmit.emit(this.validateSubmit());
    this.solicitudEmit.emit(this.processSolicitudData(this.datosSolicitud));
  }

}
