import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemLegalRepresentativeComponent } from './item-legal-representative.component';

describe('ItemLegalRepresentativeComponent', () => {
  let component: ItemLegalRepresentativeComponent;
  let fixture: ComponentFixture<ItemLegalRepresentativeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ItemLegalRepresentativeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemLegalRepresentativeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
