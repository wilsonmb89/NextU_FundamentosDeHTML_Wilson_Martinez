import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-item-legal-representative',
  templateUrl: './item-legal-representative.component.html',
  styleUrls: ['./item-legal-representative.component.scss']
})
export class ItemLegalRepresentativeComponent implements OnInit {
  @Input() item: any;
  @Output() action: EventEmitter<any>;
  data: any;
  complete: boolean;
  @Input() isRepresentative: boolean;
  @Output() principal: EventEmitter<any>;
  constructor() {
    this.action = new EventEmitter<any>();
    this.principal = new EventEmitter<any>();
    this.isRepresentative = false;
  }

  ngOnInit() {
    this.data = this.item.value;
    this.complete = this.item.valid;
  }
  clickAction(action: number) {
    this.action.emit({action, item: this.data});
  }
  clickPrincipal() {
    this.principal.emit(this.data);
  }
}
