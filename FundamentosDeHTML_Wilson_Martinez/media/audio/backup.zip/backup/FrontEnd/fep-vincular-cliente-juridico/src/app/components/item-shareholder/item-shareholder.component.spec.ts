import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ItemShareholderComponent } from './item-shareholder.component';

describe('ItemShareholderComponent', () => {
  let component: ItemShareholderComponent;
  let fixture: ComponentFixture<ItemShareholderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ItemShareholderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ItemShareholderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
