import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-item-shareholder',
  templateUrl: './item-shareholder.component.html',
  styleUrls: ['./item-shareholder.component.scss']
})
export class ItemShareholderComponent implements OnInit {
  @Input() item: any;
  @Output() action: EventEmitter<any>;
  data: any;
  complete: boolean;
  constructor() {
    this.action = new EventEmitter<any>();
  }

  ngOnInit() {
    this.data = this.item.value;
    this.complete = this.item.valid;
  }
  clickAction(action: number) {
    this.action.emit({ action, item: this.data });
  }
}
