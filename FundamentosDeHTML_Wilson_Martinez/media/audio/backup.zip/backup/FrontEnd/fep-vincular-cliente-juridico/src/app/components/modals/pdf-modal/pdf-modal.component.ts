import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { CONST_IMAGE_DEFAULT } from 'src/app/utils/constants/utils.constant';

@Component({
  selector: 'app-pdf-modal',
  templateUrl: './pdf-modal.component.html',
  styleUrls: ['./pdf-modal.component.scss']
})
export class PdfModalComponent implements OnInit {

  loading: boolean;
  @Input() bodyPdf: any;
  @Output() closeButtonEmit = new EventEmitter<boolean>();

  constructor(public sanitizer: DomSanitizer) { }

  ngOnInit() {
    this.loading = false;
    this.pdfURL();
  }

  /**
   * Metodo que emite el evento para cerrar la ventana con
   * un valor booleano false
   */
  emitCloseEvent() {
    this.bodyPdf = "";
    this.closeButtonEmit.emit(false);
  }

  pdfURL() {
    if (!!this.bodyPdf) {
      this.loading = false;
      return this.sanitizer.bypassSecurityTrustResourceUrl(this.bodyPdf);
    }
    this.loading = true;
    return this.sanitizer.bypassSecurityTrustResourceUrl(CONST_IMAGE_DEFAULT);
  }

}
