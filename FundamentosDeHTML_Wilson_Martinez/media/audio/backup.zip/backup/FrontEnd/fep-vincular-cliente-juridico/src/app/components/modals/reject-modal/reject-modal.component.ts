import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-reject-modal',
  templateUrl: './reject-modal.component.html',
  styleUrls: ['./reject-modal.component.scss']
})
export class RejectModalComponent implements OnInit {

  @Output() closeButtonEmit = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit() {
  }

  /**
   * Metodo que emite el evento para cerrar la ventana con
   * un valor booleano false
   */
  emitCloseEvent() {
    this.closeButtonEmit.emit(false);
  }

}
