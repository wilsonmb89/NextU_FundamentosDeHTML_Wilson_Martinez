import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfficialComplianceCheckTableComponent } from './official-compliance-check-table.component';

describe('OfficialComplianceCheckTableComponent', () => {
  let component: OfficialComplianceCheckTableComponent;
  let fixture: ComponentFixture<OfficialComplianceCheckTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfficialComplianceCheckTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfficialComplianceCheckTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
