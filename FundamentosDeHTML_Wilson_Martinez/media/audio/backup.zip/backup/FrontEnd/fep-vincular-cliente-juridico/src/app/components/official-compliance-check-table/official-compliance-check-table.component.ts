import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Participante } from 'src/app/utils/models/api-solicitud/Participante';

@Component({
  selector: 'app-official-compliance-check-table',
  templateUrl: './official-compliance-check-table.component.html',
  styleUrls: ['./official-compliance-check-table.component.scss']
})
export class OfficialComplianceCheckTableComponent implements OnInit {
  filterParameter: string;
  filterList: any[];

  @Input() list: any[];
  @Output() participanteEmmiter: EventEmitter<Participante>;
  constructor() {
    this.participanteEmmiter = new EventEmitter<Participante>();
  }

  ngOnInit() {
    this.filterList = this.list;
  }
  /** Metodo que realiza el filtro por nombre */
  onFilterList() {
    if (this.filterParameter) {
      this.filterList = this.list.filter(item => item.data.nombre.includes(this.filterParameter.toLocaleLowerCase()));
    } else {
      this.filterList = this.list;
    }
  }

  /**
   * Metodo para emitir evento de edicion del cliente
   */
  emmitEditClient(participante: Participante) {
    this.participanteEmmiter.emit(participante);
  }
}
