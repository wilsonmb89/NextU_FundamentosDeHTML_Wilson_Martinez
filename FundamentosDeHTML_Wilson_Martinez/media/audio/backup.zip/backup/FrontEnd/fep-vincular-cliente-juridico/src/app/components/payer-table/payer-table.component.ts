import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { MatTableDataSource, MatTable } from '@angular/material';
import { DatosOrdenantes } from 'src/app/utils/models/api-solicitud/DatosOrdenantes';

@Component({
  selector: 'app-payer-table',
  templateUrl: './payer-table.component.html',
  styleUrls: ['./payer-table.component.scss']
})
export class PayerTableComponent implements OnInit {

  dataSource: any;
  displayedColumns: string[] = ['check', 'name', 'edit', 'delete'];
  @Input() participants: any[];
  @Output() dataParticipant = new EventEmitter<any>();
  @Output() newParticipants = new EventEmitter<any>();

  constructor() {
  }

  ngOnInit() {
    this.dataSource = new MatTableDataSource(this.participants);
  }

  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  getParticipant(ordenante: DatosOrdenantes) {
    this.dataParticipant.emit(ordenante);
  }

  deleteParticipant(ordenante: DatosOrdenantes) {
    const position = this.participants.indexOf(ordenante);
    this.participants.splice(position, 1);
    this.newParticipants.emit(this.participants);
    this.dataSource = new MatTableDataSource(this.participants);
  }

}
