import { Component, OnInit, Output, EventEmitter, OnDestroy } from '@angular/core';
import { ComponentCommunicationService } from 'src/app/services/component-communication.service';
import { Subscription } from 'rxjs';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';

@Component({
  selector: 'app-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit, OnDestroy {

  @Output() saveExitEvent = new EventEmitter<boolean>();

  CONST_CONSULTAR_CLIENTE_JURIDICO = "CONSULTAR_CLIENTE_JURIDICO";
  CONST_CARGAR_INFORMACION_EMPRESA = "CARGAR_INFORMACION_EMPRESA";
  CONST_CARGAR_INFORMACION_REPRESENTANTE_LEGAL = "CARGAR_INFORMACION_REPRESENTANTE_LEGAL";
  CONST_CARGAR_INFORMACION_ORDENANTES = "CARGAR_INFORMACION_ORDENANTES";
  CONST_CARGAR_INFORMACION_ACCIONISTAS = "CARGAR_INFORMACION_ACCIONISTAS";
  CONST_CARGAR_INFORMACION_TERCEROS = "CARGAR_INFORMACION_TERCEROS";
  CONST_CARGAR_INFORMACION_DOCUMENTOS = "CARGAR_INFORMACION_DOCUMENTOS";
  CONST_CARGAR_OFICIAL_CUMPLIMIENTO = "CARGAR_OFICIAL_CUMPLIMIENTO";
  CONST_CARGAR_ANALISTA_AML = "CARGAR_ANALISTA_AML";
  CONST_GENERACION_FORMULARIOS = "GENERACION_FORMULARIOS";
  CONST_INFORMACION_ADICIONAL = "INFORMACION_ADICIONAL";
  CONST_CLASIFICACION_FATCA = "CLASIFICACION_FATCA";
  CONST_INFORMACION_TRIBUTARIA = "INFORMACION_TRIBUTARIA";
  CONST_OPERACIONES_INTERNACIONALES = "OPERACIONES_INTERNACIONALES";
  CONST_DATOS_FINANCIEROS = "DATOS_FINANCIEROS";
  CONST_DATOS_CUENTA_BANCARIA = "CUENTA_BANCARIA";
  CONST_FORMULARIO_ACTUALIZACION = "FORMULARIO_ACTUALIZACION";

  currentPage: string;
  datosSolicitud: DatosSolicitud;
  communicationSuscription: Subscription;

  constructor(
    private _compoComunicationService: ComponentCommunicationService
  ) {
    this.initSubscriptions();
  }

  ngOnInit() {
    this.datosSolicitud = new DatosSolicitud();
    this.currentPage = "";
  }

  ngOnDestroy() {
    if (!!this.communicationSuscription) {
      this.communicationSuscription.unsubscribe();
    }
  }

  /**
   * Metodo para disparar el evento de guardar al componente principal
   */
  emmitSaveExit() {
    this.saveExitEvent.emit(true);
  }

  /**
   * Metodo para inicializar la suscrpcion de escucha de los objeto de datos solicitud
   */
  initSubscriptions() {
    this.communicationSuscription = this._compoComunicationService.sideBarCommunication$.subscribe(
      dataPage => {
        this.currentPage = dataPage.currentPage || "";
        if (!!dataPage && !!dataPage.dataSolicitud) {
          this.datosSolicitud = dataPage.dataSolicitud;
        }
      }
    );
  }
}
