import { Component, OnInit, EventEmitter, Output, OnDestroy, AfterViewInit, ElementRef } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { CatalogoService } from 'src/app/shared/services/catalogo.service';
import { DatosInformacionTibutaria } from 'src/app/utils/models/api-solicitud/DatosInformacionTibutaria';
import { CatalogoRequest } from 'src/app/shared/utils/mapping/CatalogoRequest';
import { capitalizeText } from 'src/app/shared/utils/functions/transform';
import { setScrolIntoView } from 'src/app/shared/utils/functions/utils';

@Component({
  selector: 'app-tributary-information',
  templateUrl: './tributary-information.component.html',
  styleUrls: ['./tributary-information.component.scss']
})
export class TributaryInformationComponent implements OnInit, OnDestroy, AfterViewInit {
  formTributaryInformation: FormGroup;
  formChangesSuscriptor: Subscription;

  CONST_NAME_PAGE = "OPERACIONES_INTERNACIONALES";
  nameComponent = "TributaryInformationComponent";

  @Output() validEmit: EventEmitter<any> = new EventEmitter();
  @Output() solicitudEmit: EventEmitter<any> = new EventEmitter();

  datosSolicitud: DatosSolicitud;

  propertiesForm: string[];
  listTypeTributary: any[];

  constructor(
    private _catalogoService: CatalogoService,
    private _el: ElementRef
  ) {
    this.formTributaryInformation = new FormGroup(this.createForm());
    this.listTypeTributary = new Array();
    this.getTypesTributary();
  }

  ngOnInit() {
    this.validEmit.emit(this.formTributaryInformation.valid);
    this.solicitudEmit.emit(this.datosSolicitud);
  }
  ngOnDestroy() {
    if (!!this.formChangesSuscriptor) {
      this.formChangesSuscriptor.unsubscribe();
    }
  }

  ngAfterViewInit() {
    const inputList = ([].slice.call((<HTMLElement> this._el.nativeElement).querySelectorAll('input:not(.mat-radio-input)'))).concat([].slice.call((<HTMLElement> this._el.nativeElement).getElementsByTagName('textarea')));
    setScrolIntoView(inputList);
  }

  /** Metodo que realiza el cargue del catalogo
   * @param catalogName nombre del catalogo
   * @param id referencia de un catalogo padre
   */
  async getCatalog(catalogName: string, id: string) {
    const catalogoRq = new CatalogoRequest();
    catalogoRq.catalogName = catalogName;
    catalogoRq.idParent = id || '';
    const items = await this._catalogoService.getCatalog(catalogoRq);
    items.items.forEach(element => element.name = capitalizeText(element.name.toLowerCase()));
    return items.items;
  }
  /** Metodo que carga la lista de tipos tributarios */
  async getTypesTributary() {
    const listTypeTributary = await this.getCatalog("TipoTributaria", null);
    this.listTypeTributary = listTypeTributary;
  }
  /** Metodo que agrega o elimina validaciones de formulario */
  setValidators() {
    this.formTributaryInformation.get("tipoContribuyente").setValidators([]);
    this.formTributaryInformation.get("otroContribuyente").setValidators([]);
    this.formTributaryInformation.get("tipoRegimen").setValidators([]);
    this.formTributaryInformation.get("numeroResolucionRegimen").setValidators([]);
    this.formTributaryInformation.get("numeroResolucionRetenedor").setValidators([]);
  }
  /** Metodo que valida el campo en la seleccion de contribuyente */
  changeTaxpayerTax(item: any) {
    if (item.value === "si") {
      this.formTributaryInformation.get("tipoRegimen").setValidators([Validators.required]);
      this.formTributaryInformation.get("tipoContribuyente").setValidators([]);
    } else {
      this.formTributaryInformation.get("tipoRegimen").setValidators([]);
      this.formTributaryInformation.get("tipoContribuyente").setValidators([Validators.required]);
    }
    this.formTributaryInformation.get("tipoRegimen").reset();
    this.formTributaryInformation.get("tipoContribuyente").reset();
  }
/** Metodo que valida el campo en la seleccion de tipo de regimen */
  changeRegimeType(item: any) {
    if (item.value === "Régimen Especial") {
      this.formTributaryInformation.get("numeroResolucionRegimen").setValidators([Validators.required]);
    } else {
      this.formTributaryInformation.get("numeroResolucionRegimen").setValidators([]);
    }
    this.formTributaryInformation.get("numeroResolucionRegimen").reset();
  }
/** Metodo que valida los campos en la seleccion de auto-retencion */
  changeSelfRetention(item: any) {
    if (item.value === "si") {
      this.formTributaryInformation.get("numeroResolucionRetenedor").setValidators([Validators.required]);
    } else {
      this.formTributaryInformation.get("numeroResolucionRetenedor").setValidators([]);
    }
    this.formTributaryInformation.get("numeroResolucionRetenedor").reset();
  }
  /**Metodo que valida el campo en la seleccion de tipo tributario*/
  changeTypeTributary(item: any) {
    if (item.value === "TT_007 - Otro") {
      this.formTributaryInformation.get("otroContribuyente").setValidators([Validators.required]);
    } else {
      this.formTributaryInformation.get("otroContribuyente").setValidators([]);
    }
    this.formTributaryInformation.get("otroContribuyente").reset();
  }
  /**
   * Metodo para obtener la data previa en SOR
   * @param dataSolicitud Objeto entregado por el padre
   */
  async getSolicitudSor(dataSolicitud: DatosSolicitud) {
    this.datosSolicitud = dataSolicitud;
    this.formTributaryInformation = new FormGroup(this.createForm());
    this.setValidators();
    this.updateForm(this.datosSolicitud.clienteJuridico.datosAdicionales.datosInformacionTributaria);
    this.formChangesSuscriptor = this.formTributaryInformation.valueChanges.subscribe(() => {
      this.datosSolicitud.clienteJuridico.datosAdicionales.datosInformacionTributaria = this.formTributaryInformation.value;
      this.solicitudEmit.emit(this.datosSolicitud);
      this.validEmit.emit(this.formTributaryInformation.valid);
    });
  }

  /**
   * Metodo para crear las propiedades del formgroup a partir de
   * un modelo como Datos Financieros
   */
  createForm() {
    const model = new DatosInformacionTibutaria();
    this.propertiesForm = Object.getOwnPropertyNames(new DatosInformacionTibutaria());
    const object = {};
    this.propertiesForm.forEach((item) => {
      object[item] = new FormControl(model[item], Validators.required);
    });
    return object;
  }

  /**
   * Actualiza el formulario con la data obtenida en SOR
   * @param datos corresponden a los datos de clasificacion fatca de la solicitud
   */
  updateForm(datos: DatosInformacionTibutaria) {
    if (!(!!datos)) {
      datos = new DatosInformacionTibutaria();
    }
    this.formTributaryInformation.get('contribuyenteImpuesto').setValue(datos.contribuyenteImpuesto);
    this.formTributaryInformation.get('tipoContribuyente').setValue(datos.tipoContribuyente);
    this.formTributaryInformation.get('otroContribuyente').setValue(datos.otroContribuyente);
    this.formTributaryInformation.get('tipoRegimen').setValue(datos.tipoRegimen);
    this.formTributaryInformation.get('numeroResolucionRegimen').setValue(datos.numeroResolucionRegimen);
    this.formTributaryInformation.get('granContribuyente').setValue(datos.granContribuyente);
    this.formTributaryInformation.get('autoRetenedorRendimientos').setValue(datos.autoRetenedorRendimientos);
    this.formTributaryInformation.get('numeroResolucionRetenedor').setValue(datos.numeroResolucionRetenedor);
    this.formTributaryInformation.get('exentoGMF').setValue(datos.exentoGMF);
  }
}
