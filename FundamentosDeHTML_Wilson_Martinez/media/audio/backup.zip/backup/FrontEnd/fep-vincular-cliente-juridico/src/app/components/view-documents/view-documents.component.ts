import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { DocumentService } from 'src/app/shared/services/document.service';
import { getDoc } from 'src/app/utils/mapping/UploadDocMapping';

@Component({
  selector: 'app-view-documents',
  templateUrl: './view-documents.component.html',
  styleUrls: ['./view-documents.component.scss']
})
export class ViewDocumentsComponent implements OnInit {

  @Input() dataSource: any;
  @Output() closeButtonEmit = new EventEmitter<boolean>();
  @Output() bodyPdf: EventEmitter<any> = new EventEmitter();
  displayedColumns: string[] = ['name', 'type', 'file'];
  CONST_DOC_REQ_TYPE = "REQ";

  constructor(private _documentService: DocumentService) { }

  ngOnInit() { }

  /**
   * Metodo que emite el evento para cerrar la ventana con
   * un valor booleano false
   */
  emitCloseEvent() {
    this.dataSource = "";
    this.closeButtonEmit.emit(false);
  }

  /**
   * Metodo para cargar el objeto con el archivo PDF
   * @param name Nombre del archivo cargado
   */
  async viewPdf(name: string, optionalName?: string) {
    this.bodyPdf.emit("");
    this.bodyPdf.emit(await this.convertPdf(!!optionalName ? (optionalName + ".pdf") : name));
  }

  /**
   * Metodo para conversion a URL de tipo PDF
   * @param name Nombre del archivo cargado
   */
  async convertPdf(name: string): Promise<string> {
    const docRq = getDoc(name, this.CONST_DOC_REQ_TYPE, this.dataSource);
    const res = await this._documentService.getDocument(docRq);
    const pdf: any = new Blob([res], { type: 'application/pdf' });
    const fileURL = URL.createObjectURL(pdf);
    return fileURL;
  }

}
