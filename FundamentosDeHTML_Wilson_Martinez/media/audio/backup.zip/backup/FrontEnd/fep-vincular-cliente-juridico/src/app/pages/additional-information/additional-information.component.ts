import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Solicitud } from 'src/app/shared/utils/models/Solicitud/Solicitud';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { ComponentCommunicationService } from 'src/app/services/component-communication.service';
import { BpmService } from 'src/app/shared/services/bpm.service';
import { SolicitudService } from 'src/app/shared/services/solicitud.service';
import { ClaimTaskRequest } from 'src/app/shared/utils/models/api-bpm/ClaimTaskRq';
import { FinishTaskRequest } from 'src/app/shared/utils/models/api-bpm/FinishTaskRq';
import { GetTaskByIdRequest } from 'src/app/shared/utils/models/api-bpm/GetTaskByIdRequest';
import { ProcessInstanceRequest } from 'src/app/shared/utils/models/api-bpm/ProcessInstanceRequest';
import { DatosOrdenantes } from 'src/app/utils/models/api-solicitud/DatosOrdenantes';
import { DatosAdicionales } from 'src/app/utils/models/api-solicitud/DatosAdiccionales';
import { ClienteJuridico } from 'src/app/utils/models/api-solicitud/ClienteJuridico';

@Component({
  selector: 'app-additional-information',
  templateUrl: './additional-information.component.html',
  styleUrls: ['./additional-information.component.scss']
})
export class AdditionalInformationComponent implements OnInit, OnDestroy {

  taskId: string;
  instanceId: string;
  next: any;
  back: any;
  nombreEmpresa: string;
  validForm: boolean;
  additionalInfo: boolean;
  sectionVisibility: boolean;
  dataSolicitud: DatosSolicitud;
  ordenante: DatosOrdenantes;
  datosOrdenantes: DatosOrdenantes[];
  validSubscription: Subscription;
  safeSorSubscription: Subscription;
  communicationSuscription: Subscription;
  CONST_INFORMACION_ADICIONAL = "INFORMACION_ADICIONAL";

  constructor(
    private _router: Router,
    private _bpmService: BpmService,
    private _activatedRoute: ActivatedRoute,
    private _solicitudService: SolicitudService,
    private _compoComunicationService: ComponentCommunicationService
  ) {
    this.communicationSuscription = _compoComunicationService.saveButtonCommunication$.subscribe(
      saveDataButton => { if (!!saveDataButton && saveDataButton) { this.endProcess(); } }
    );
  }

  ngOnInit() {
    this.instanceId = this.nombreEmpresa = this.next = this.back = "";
    this.taskId = this._activatedRoute.parent.snapshot.paramMap.get("taskId") || '';
    this.sectionVisibility = this.validForm = this.additionalInfo = false;
    this.getSolicitudSor();
    this._router.events.subscribe((res) => { });
  }

  ngOnDestroy() {
    if (!!this.validSubscription) {
      this.validSubscription.unsubscribe();
    }
    if (!!this.safeSorSubscription) {
      this.safeSorSubscription.unsubscribe();
    }
    if (!!this.communicationSuscription) {
      this.communicationSuscription.unsubscribe();
    }
  }
  /** Metodo para validar la subpantalla en la que se encuentra */
  validateRoute() {
    const segments = this._activatedRoute.snapshot["_urlSegment"].segments;
    if (segments.length === 4) {
      const children = this._activatedRoute.routeConfig.children.map(route => route.path);
      const currentPath = segments[3].path;
      this.sectionVisibility = children.includes(currentPath);
    }
  }
  /**
   * Metodo para obtener la data previa en SOR
   */
  async getSolicitudSor() {
    this.showLoading(true);
    try {
      await this.getProcessData();
      if (!!this.instanceId) {
        const solicitudRq = new Solicitud;
        solicitudRq.idSolicitud = this.instanceId;
        const solicitudRs = await this._solicitudService.getSolicitud(solicitudRq);
        if (!!solicitudRs && !!solicitudRs.datosSolicitud) {
          this.dataSolicitud = JSON.parse(solicitudRs.datosSolicitud);
          this.nombreEmpresa = this.dataSolicitud.clienteJuridico.datosContacto.nombre;
          this.datosOrdenantes = this.dataSolicitud.clienteJuridico.datosOrdenantes;
          if (!(!!this.dataSolicitud.clienteJuridico.datosAdicionales)) {
            this.dataSolicitud.clienteJuridico.datosAdicionales = new DatosAdicionales();
          }
          this.updateSidebar(this.dataSolicitud, this.CONST_INFORMACION_ADICIONAL);
          this.validateRoute();
        }
      } else { this.showModalErrorAndExitLogin(); }
    } catch (error) { this.showErrorModal(false); }
    this.showLoading(false);
  }

  /**
   * Metodo para obtener los datos del proceso, en
   * este caso el id de la instancia
   */
  async getProcessData() {
    await this.getTaskInfo();
    if (!(!!this.instanceId)) { this.showModalErrorAndExitLogin(); }
  }

  /**
   * Metodo para obtener los datos de la tarea
   */
  async getTaskInfo() {
    const taskModelRq = new GetTaskByIdRequest();
    taskModelRq.taskId = this.taskId;
    const getTaskInfoRs = await this._bpmService.getTaskInfo(taskModelRq);
    if (!!getTaskInfoRs) {
      this.instanceId = getTaskInfoRs.processInstanceId;
    } else { this.instanceId = null; }
  }

  /**
   * Metodo para enviar objeto a la barra lateral con el fin de que se actualice
   * segun la informacion procesada
   * @param datosSolicitud Objeto que representa los datos de la solicitud
   * @param currentPage Nombre de la pagina actual segun el tipo de formulario
   */
  async updateSidebar(datosSolicitud: any, currentPage: string) {
    if (!!this.instanceId) {
      if (!!datosSolicitud) {
        const dataPage = {
          "currentPage": currentPage,
          "dataSolicitud": datosSolicitud
        };
        this._compoComunicationService.emmitSideBarEvent(dataPage);
      }
    }
  }

  /**
   * Metodo para guardar la solicitud en SOR
   * @param value Valor de decision para finalizar tarea
   */
  async saveDataSor(value: boolean) {
    this.showLoading(true);
    await this.getTaskInfo();
    if (!!this.instanceId) {
      const solicitudSorRq = new Solicitud();
      solicitudSorRq.idSolicitud = this.instanceId;
      solicitudSorRq.setDatosSolicitud(this.dataSolicitud);
      const saveResult = await this._solicitudService.saveSolicitud(solicitudSorRq);
      if (!!saveResult) {
        if (value) { await this.finishTask(); }
      } else { this.showErrorModal(false); }
    } else { this.showModalErrorAndExitLogin(); }
    this.showLoading(false);
  }

  /**
   * Metodo para finalizar la tarea actual
   */
  async finishTask() {
    const request = new FinishTaskRequest();
    request.taskId = this.taskId;
    const finishTaskRs = await this._bpmService.finishTask(request);
    if (!!finishTaskRs) {
      const processInstanceRq = new ProcessInstanceRequest();
      processInstanceRq.processInstanceId = this.instanceId;
      const getNextTaskRs = await this._bpmService.getNextTask(processInstanceRq);
      if (!!getNextTaskRs && getNextTaskRs.length > 0) {
        const body = new ClaimTaskRequest();
        body.idTask = getNextTaskRs[0].id;
        const claimTask = await this._bpmService.getClaimTask(body);
        if (!!claimTask) {
          this.showLoading(false);
          this.redirectExternalUrl(claimTask.path);
        } else { this.showErrorModal(false); }
      } else { this.redirectUrl('/portal/'); }
    } else { this.showErrorModal(false); }
  }

  /**
   * Metodo para navegar a una url externa
   * @param url Valor que representa la ruta a tomar
   */
  async redirectUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      this._router.navigate(['/externalRedirect', { externalUrl: domain }], {
        skipLocationChange: true,
      });
    }
  }

  /**
   * Metodo para navegar al login como url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectExternalUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      window.open(domain, '_self');
    }
  }

  /**
   * Metodo para validar los archivos adjuntos en el formulario
   */
  validateSubmit() {
    if (!!this.dataSolicitud && !!this.dataSolicitud.clienteJuridico) {
      const validObjects = !!this.dataSolicitud.clienteJuridico.datosAdicionales &&
        !!this.dataSolicitud.clienteJuridico.datosAdicionales.datosFinancieros &&
        !!this.dataSolicitud.clienteJuridico.datosAdicionales.datosCuentaBancaria &&
        !!this.dataSolicitud.clienteJuridico.datosAdicionales.datosClasificacionFatca &&
        !!this.dataSolicitud.clienteJuridico.datosAdicionales.datosInformacionTributaria &&
        !!this.dataSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales;
      if (!!this.dataSolicitud.clienteJuridico.datosOrdenantes &&
        this.dataSolicitud.clienteJuridico.datosOrdenantes.length > 0) {
        return validObjects && this.dataSolicitud.clienteJuridico.datosOrdenantes.every((ordenate: DatosOrdenantes) => {
          if (!!ordenate.datosAdicionales) {
            return ordenate.datosAdicionales.vinculoEmpresa != null;
          }
        });
      } else {
        return validObjects;
      }
    }
  }

  /**
   * Metodo que se encarga de guardar en SOR y finalizar la tarea
   */
  async submit() { await this.saveDataSor(true); }

  /**
   * Metodo para finalizar el proceso
   */
  async endProcess() {
    await this.saveDataSor(false);
    await this.redirectUrl('/portal/');
  }

  /**
   * Metodo para finalizar el proceso
   */
  sideBarParticipant(value: DatosOrdenantes) {
    const data = new DatosSolicitud();
    data.clienteJuridico = new ClienteJuridico();
    data.clienteJuridico.datosOrdenantes = new Array<DatosOrdenantes>();
    data.clienteJuridico.datosOrdenantes.push(value);
    this.updateSidebar(data, this.CONST_INFORMACION_ADICIONAL);
  }

  /**
   * Metodo que recibe los datos de un participante
   */
  dataParticipant(data: any) {
    this.additionalInfo = true;
    this.ordenante = data;
  }

  /**
   * Metodo que recibe el listado de participantes despues
   * de eliminar al participante seleccionado
   */
  async deleteParticipant(data: any) {
    this.dataSolicitud.clienteJuridico.datosOrdenantes = data;
    await this.saveDataSor(false);
  }

  /**
   * Metodo para cerrar a pantalla de info adicional del ordenante
   * @param value Valor booleano que es entrago por el componene de form-additional-info
   */
  closeScreen(value: boolean) {
    this.additionalInfo = value;
    this.updateSidebar(this.dataSolicitud, this.CONST_INFORMACION_ADICIONAL);
  }

  /**
   * Metodo para guardar la info adicional de ordenante
   * @param value Datos adicionales del ordenante
   */
  dataReceived(value: DatosOrdenantes) {
    this.datosOrdenantes.forEach(ordenante => {
      if (ordenante.numeroDocumento === value.numeroDocumento) {
        ordenante.datosAdicionales = value.datosAdicionales;
      }
    });
    this.dataSolicitud.clienteJuridico.datosOrdenantes = this.datosOrdenantes;
    this.saveDataSor(false);
  }

  /**
   * Metodo para mostrar el error con la opcion de redirigir
   * a la bandeja de tareas
   */
  showModalErrorAndExitLogin() {
    this.showErrorModal(true);
  }

  /**
   * Metodo para navegar entre componentes hijos y padre
   * @param page Nombre de la ruta que representa a un componente
   */
  navigateNextPage(page: string) {
    this.sectionVisibility = page === "." ? false : true;
    this._router.navigate([page], { relativeTo: this._activatedRoute });
  }

  /**
   * Metodo que se llama a partir de la instancia de un componente
   * @param event Representa el objeto del componente
   */
  onActivate(event: any) {
    if (!!event.validEmit && !!event.solicitudEmit) {
      event.getSolicitudSor(this.dataSolicitud);
      this.validSubscription = event.validEmit.subscribe((data: any) => {
        this.validForm = data;
      });
      this.safeSorSubscription = event.solicitudEmit.subscribe((data: any) => {
        this.updateSidebar(data.__zone_symbol__value || data, event.CONST_NAME_PAGE);
      });
    }
    this.next = this.nextPage(event.nameComponent);
    this.back = this.backPage(event.nameComponent);
  }

  /**
   * Metodo que se llama a partir de la destruccion de un componente
   * @param event Representa el objeto del componente
   */
  onDeactivate(event: any) {
    if (!!event.datosSolicitud) {
      this.dataSolicitud = event.datosSolicitud;
    }
    this.updateSidebar(this.dataSolicitud, this.CONST_INFORMACION_ADICIONAL);
    this.saveDataSor(false);
  }

  /**
   * Metodo para identificar cual es la siguiene ruta a tomar
   * @param componentName Representa nombre del componente
   */
  nextPage(componentName: string) {
    switch (componentName) {
      case "FinancialDataComponent":
        return "clasificacionFatca";
      case "FatcaClasificationComponent":
        return "operacionesInternacionales";
      case "InternationalOperationsComponent":
        return "informacionTributaria";
      case "TributaryInformationComponent":
        return "datosCuentaBancaria";
      case "BankAccountComponent":
        return ".";
    }
  }

  /**
   * Metodo para identificar cual es la ruta anterior a tomar
   * @param componentName Representa nombre del componente
   */
  backPage(componentName: string) {
    switch (componentName) {
      case "FinancialDataComponent":
        return ".";
      case "FatcaClasificationComponent":
        return "datosFinancieros";
      case "InternationalOperationsComponent":
        return "clasificacionFatca";
      case "TributaryInformationComponent":
        return "operacionesInternacionales";
      case "BankAccountComponent":
        return "informacionTributaria";
    }
  }

  /**
   * Metodo para controlar el componente de loading desde la pagina de buscar
   * componente
   * @param value si es verdadero muestra el loading no lo muestra en caso
   * contrariuo
   */
  showLoading(value: boolean) {
    this._compoComunicationService.emmitLoading(value);
  }

  /**
   * Metodo para mostrar el modal de error en la pantalla
   * @param redirectLogin valida se debe redirigir a la bandeja de tareas
   */
  showErrorModal(redirectLogin: boolean) {
    const errorData = {
      'showErrorModal': true,
      'redirectLogin': redirectLogin
    };
    this._compoComunicationService.emmitError(errorData);
  }

}
