import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdditionalInformationComponent } from './additional-information.component';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService as AuthGuard } from '../../shared/services/auth-guard.service';
import { ComponentsModule } from 'src/app/components/components.module';
import { MaterialModule } from 'src/app/material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { InternationalOperationsComponent } from 'src/app/components/international-operations/international-operations.component';
import { TributaryInformationComponent } from 'src/app/components/tributary-information/tributary-information.component';
import { FinancialDataComponent } from 'src/app/components/financial-data/financial-data.component';
import { FatcaClasificationComponent } from 'src/app/components/fatca-clasification/fatca-clasification.component';
import { BankAccountComponent } from 'src/app/components/bank-account/bank-account.component';

const routes: Routes = [
  { path: '', component: AdditionalInformationComponent, canActivate: [AuthGuard], children: [
    { path: 'operacionesInternacionales', component: InternationalOperationsComponent },
    { path: 'informacionTributaria', component: TributaryInformationComponent },
    { path: 'datosFinancieros', component: FinancialDataComponent},
    { path: 'clasificacionFatca', component: FatcaClasificationComponent},
    { path: 'datosCuentaBancaria', component: BankAccountComponent}
  ] }
];

@NgModule({
  declarations: [AdditionalInformationComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    SharedModule,
    ComponentsModule,
    RouterModule.forChild(routes)
  ]
})
export class AdditionalInformationModule { }
