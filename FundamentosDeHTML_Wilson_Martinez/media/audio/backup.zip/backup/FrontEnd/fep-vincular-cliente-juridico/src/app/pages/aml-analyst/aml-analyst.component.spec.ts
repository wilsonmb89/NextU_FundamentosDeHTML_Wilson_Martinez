import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AmlAnalystComponent } from './aml-analyst.component';

describe('AmlAnalystComponent', () => {
  let component: AmlAnalystComponent;
  let fixture: ComponentFixture<AmlAnalystComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AmlAnalystComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AmlAnalystComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
