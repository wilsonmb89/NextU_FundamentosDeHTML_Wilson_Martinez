import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CheckDocumentsComponent } from './check-documents.component';

describe('CheckDocumentsComponent', () => {
  let component: CheckDocumentsComponent;
  let fixture: ComponentFixture<CheckDocumentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CheckDocumentsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CheckDocumentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
