import { Component, OnInit, OnDestroy } from '@angular/core';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { ComponentCommunicationService } from 'src/app/services/component-communication.service';
import { BpmService } from 'src/app/shared/services/bpm.service';
import { Subscription } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { SolicitudService } from 'src/app/shared/services/solicitud.service';
import { GetTaskByIdRequest } from 'src/app/shared/utils/models/api-bpm/GetTaskByIdRequest';
import { Solicitud } from 'src/app/shared/utils/models/Solicitud/Solicitud';
import { FinishTaskRequest } from 'src/app/shared/utils/models/api-bpm/FinishTaskRq';
import { ProcessInstanceRequest } from 'src/app/shared/utils/models/api-bpm/ProcessInstanceRequest';
import { ClaimTaskRequest } from 'src/app/shared/utils/models/api-bpm/ClaimTaskRq';
import { DocumentService } from 'src/app/shared/services/document.service';

@Component({
  selector: 'app-check-documents',
  templateUrl: './check-documents.component.html',
  styleUrls: ['./check-documents.component.scss']
})
export class CheckDocumentsComponent implements OnInit, OnDestroy {
  idActividad: string;
  idInstancia: string;
  datosSolicitud: DatosSolicitud;
  communicationSuscription: Subscription;
  listDocuments: any;
  constructor(private _compoComunicationService: ComponentCommunicationService,
    private _bpmService: BpmService,
    private _activatedRoute: ActivatedRoute,
    private _solicitudService: SolicitudService,
    private _router: Router,
    private _documentService: DocumentService) {
    this.setSuscriptions();
  }

  ngOnInit() {
    this.idActividad = this._activatedRoute.parent.snapshot.paramMap.get("taskId") || '';
    this.getTaskInfo();
    this.getSolicitudSor();
  }
  ngOnDestroy() {
    if (!!this.communicationSuscription) {
      this.communicationSuscription.unsubscribe();
    }
  }
  /**
   * Metodo para obtener los datos de la tarea
   */
  async getTaskInfo() {
    const taskModelRq = new GetTaskByIdRequest();
    taskModelRq.taskId = this.idActividad;
    const getTaskInfoRs = await this._bpmService.getTaskInfo(taskModelRq);
    if (!!getTaskInfoRs) {
      this.idInstancia = getTaskInfoRs.processInstanceId;
    } else {
      this.idInstancia = null;
    }
  }
  /**
   * Metodo para obtener la data previa en SOR
   */
  async getSolicitudSor() {
    this.showLoading(true);
    try {
      await this.getProcessData();
      if (!!this.idInstancia) {
        const solicitudRq = new Solicitud();
        solicitudRq.idSolicitud = this.idInstancia;
        const solicitudRs = await this._solicitudService.getSolicitud(solicitudRq);
        if (!!solicitudRs && !!solicitudRs.datosSolicitud) {
          this.datosSolicitud = JSON.parse(solicitudRs.datosSolicitud);
          this.listDocuments = this.datosSolicitud.clienteJuridico.datosDocumento.documentosSolicitados;
          this.updateData();
          this.updateSidebar();
        }
      } else {
        this.showErrorModal(true);
      }
    } catch (error) {
      this.showErrorModal(false);
    }
    this.showLoading(false);
  }
  async showErrorModal(redirectLogin: boolean) {
    const errorData = {
      'showErrorModal': true,
      'redirectLogin': redirectLogin
    };
    await this._compoComunicationService.emmitError(errorData);
  }
  /**
   * Metodo para obtener los datos del proceso, en
   * este caso el id de la instancia
   */
  async getProcessData() {
    await this.getTaskInfo();
    if (!(!!this.idInstancia)) {
      this.showErrorModal(true);
    }
  }
  updateData() {
    return true;
  }
  /** Metodo para actulizar la informacion del sidebar */
  async updateSidebar() {
    if (!!this.idInstancia) {
      const dataPage = {
        "currentPage": "",
        "dataSolicitud": this.datosSolicitud
      };
      this._compoComunicationService.emmitSideBarEvent(dataPage);
    }
  }
  /**
   * Metodo para controlar el componente de loading desde la pagina de buscar
   * componente
   * @param value si es verdadero muestra el loading no lo muestra en caso
   * contrariuo
   */
  showLoading(value: boolean) {
    this._compoComunicationService.emmitLoading(value);
  }
  /**
   * Metodo para guardar la solicitud en sor
   * @param finishTask Valor de decision para finalizar tarea
   */
  async saveDataSor(finishTask: boolean) {
    this.showLoading(true);
    if (!!this.idInstancia) {
      const solicitud = new Solicitud();
      solicitud.idSolicitud = this.idInstancia;
      solicitud.setDatosSolicitud(this.datosSolicitud);
      const solicitudSorRs = await this._solicitudService.saveSolicitud(solicitud);
      if (!!solicitudSorRs) {
        if (finishTask) {
          await this.finishTask();
        }
      } else {
        this.showErrorModal(false);
      }
    } else {
      this.showErrorModal(true);
    }
    this.showLoading(false);
  }
  /**
   * Metodo para finalizar la tarea actual
   */
  async finishTask() {
    const finishTaskRq = new FinishTaskRequest();
    finishTaskRq.taskId = this.idActividad;
    const finishTaskRs = await this._bpmService.finishTask(finishTaskRq);
    if (!!finishTaskRs) {
      const processInstanceRq = new ProcessInstanceRequest();
      processInstanceRq.processInstanceId = this.idInstancia;
      const getNextTaskRs = await this._bpmService.getNextTask(processInstanceRq);
      if (!!getNextTaskRs && getNextTaskRs.length > 0) {
        const body = new ClaimTaskRequest();
        body.idTask = getNextTaskRs[0].id;
        const claimTask = await this._bpmService.getClaimTask(body);
        if (!!claimTask) {
          this.redirectExternalUrl(claimTask.path);
        } else {
          this.showErrorModal(false);
        }
      } else {
        this.redirectUrl('/portal/');
      }
    } else {
      this.showErrorModal(false);
    }
  }
  /**
   * Metodo para navegar a una url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      this._router.navigate(['/externalRedirect', { externalUrl: domain }], {
        skipLocationChange: true,
      });
    }
  }
  /**
   * Metodo para navegar al login como url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectExternalUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      window.open(domain, '_self');
    }
  }
  /**
   * Metodo para conectar al los datos del componente padre a la pantalla
   * de consultar empresa
   */
  setSuscriptions() {
    this.communicationSuscription = this._compoComunicationService.saveButtonCommunication$.subscribe(
      saveDataButton => {
        if (!!saveDataButton) {
          this.saveAndExit();
        }
      }
    );
  }
  async saveAndExit() {
    await this.saveDataSor(false);
    this.redirectUrl('/portal/');
  }
  /**
  * Metodo para validacion de informacion completa
  */
  validSumbit() {
    if (this.listDocuments) {
      const listValid = Object.getOwnPropertyNames(this.listDocuments);
      let listCheck = new Array();
      listValid.forEach(item => {
        this.listDocuments[item].forEach(document => {
          listCheck.push((document.check && document.requerido) || !document.requerido);
        });
      });
      listCheck = listCheck.filter((e, i, s) => s.indexOf(e) === i);
      return listCheck.length === 1 && listCheck[0] === true;
    }
  }
  /**
  * Metodo para guardar en sor finalizando la actividad de consulta de datos
  */
  async submit() {
    await this.saveDataSor(true);
  }
  /** Metodo que valida si el usuario existe */
  async validateUser(list: any) {
    if (this.datosSolicitud.clienteJuridico.clientFound) {
      const fileName = this.datosSolicitud.clienteJuridico.datosGenerales.tipoDocumento.split("-")[1].trim() + "/"
        + this.datosSolicitud.clienteJuridico.datosGenerales.numeroDocumento.replace(/\D/g, '') + "/REQ/";
      const body = { filesPath: fileName };
      const listDocuments = await this._documentService.getDocumentsByPath(body);
      const document = this.datosSolicitud.clienteJuridico.datosDocumento.documentosSolicitados;
      document.empresa.forEach(document => {
        const foundDocument = listDocuments.listDocNames.find(e => e.includes(document.tipo));
        if (foundDocument) {
          document.check = true;
        }
      });

      const listNames = Object.getOwnPropertyNames(this.listDocuments);
      listNames.forEach(element => {
        if (element === "ordenantes" && this.datosSolicitud.clienteJuridico.datosOrdenantes && this.datosSolicitud.clienteJuridico.datosOrdenantes.length > 0){
          this.listDocuments[element].forEach(document => document.check = document.requerido);
        }
        if (element === "representanteLegal" && this.datosSolicitud.clienteJuridico.datosRepresentanteLegal && this.datosSolicitud.clienteJuridico.datosRepresentanteLegal.length > 0){
          this.listDocuments[element].forEach(document => document.check = document.requerido);
        }
        if (element === "accionistas" &&  this.datosSolicitud.clienteJuridico.datosAccionistas && this.datosSolicitud.clienteJuridico.datosAccionistas.accionistas.length > 0) {
          this.listDocuments[element].forEach(document => document.check = document.requerido);
        }
      });
    }
  }
}
