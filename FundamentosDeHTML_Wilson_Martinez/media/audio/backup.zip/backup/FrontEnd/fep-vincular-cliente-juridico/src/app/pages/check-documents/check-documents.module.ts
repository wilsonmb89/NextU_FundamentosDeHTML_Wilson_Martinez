import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CheckDocumentsComponent } from './check-documents.component';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService as AuthGuard } from '../../shared/services/auth-guard.service';
import { ComponentsModule } from 'src/app/components/components.module';

const routes: Routes = [
  { path: '', component: CheckDocumentsComponent, canActivate: [AuthGuard] }
];

@NgModule({
  declarations: [CheckDocumentsComponent],
  imports: [
    ComponentsModule,
    CommonModule,
    RouterModule.forChild(routes)
  ]
})
export class CheckDocumentsModule { }
