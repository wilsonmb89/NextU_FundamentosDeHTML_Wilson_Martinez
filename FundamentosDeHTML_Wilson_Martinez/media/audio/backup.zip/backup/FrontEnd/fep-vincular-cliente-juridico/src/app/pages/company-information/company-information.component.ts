import { Component, OnInit, OnDestroy, ElementRef, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { SolicitudService } from 'src/app/shared/services/solicitud.service';
import { BpmService } from 'src/app/shared/services/bpm.service';
import { BureauService } from 'src/app/shared/services/bureau.service';
import { CatalogoService } from 'src/app/shared/services/catalogo.service';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { CATALOGS_DATA_CUSTOMER, CONST_GATEWAY_DEC_VAR_BPM } from 'src/app/utils/constants/utils.constant';
import { CatalogoRequest } from 'src/app/shared/utils/mapping/CatalogoRequest';
import { capitalizeText } from 'src/app/shared/utils/functions/transform';
import { Observable, Subscription } from 'rxjs';
import { startWith, map } from 'rxjs/operators';
import { idValueCatalogValidator, parentValueCatalogValidator } from 'src/app/shared/utils/validations/CustomValidators';
import { GetTaskByIdRequest } from 'src/app/shared/utils/models/api-bpm/GetTaskByIdRequest';
import { Solicitud } from 'src/app/shared/utils/models/Solicitud/Solicitud';
import { getDatosContacto, updateDatosContacto, updateDatosDocumento } from 'src/app/utils/mapping/SolicitudMapping';
import { FinishTaskRequest } from 'src/app/shared/utils/models/api-bpm/FinishTaskRq';
import { ProcessInstanceRequest } from 'src/app/shared/utils/models/api-bpm/ProcessInstanceRequest';
import { ClaimTaskRequest } from 'src/app/shared/utils/models/api-bpm/ClaimTaskRq';
import { AddressValidatorDirective } from 'src/app/shared/utils/directives/address-validator.directive';
import { ComponentCommunicationService } from 'src/app/services/component-communication.service';
import { DatosRiesgo } from 'src/app/utils/models/api-solicitud/DatosRiesgo';
import { mappingStradata } from 'src/app/utils/mapping/BureauMapping';
import { mappingConsultaListas, mappingEnrutamiento } from 'src/app/utils/mapping/EnrutamientoMapping';
import { setScrolIntoView } from 'src/app/shared/utils/functions/utils';

@Component({
  selector: 'app-company-information',
  templateUrl: './company-information.component.html',
  styleUrls: ['./company-information.component.scss']
})
export class CompanyInformationComponent implements OnInit, OnDestroy, AfterViewInit  {

  companyForm: FormGroup;
  isLoadingActive: boolean;
  showErrorModal: boolean;
  redirectLogin: boolean;
  showRejectModal: boolean;
  instanceId: string;
  taskId: string;
  decisionGateway: string;
  datosSolicitud: DatosSolicitud;
  countries: any[];
  departments: any[];
  cities: any[];
  paisFavorito: any;
  tiposEntidades: any[];
  clasesSociedades: any[];
  comerciales: any[];
  codigosCiiu: any[];
  filteredOptionsPais: Observable<any[]>;
  filteredOptionsDepto: Observable<any[]>;
  filteredOptionsCiudad: Observable<any[]>;
  filteredOptionsTiposEntidad: Observable<any[]>;
  filteredOptionsClasesSocidad: Observable<any[]>;
  filteredOptionsComerciales: Observable<any[]>;
  filteredOptionsCodigosCiiu: Observable<any[]>;
  communicationSuscription: Subscription;
  addressValidator = new AddressValidatorDirective();
  datosRiesgoCliente: DatosRiesgo;
  CONST_CARGAR_INFORMACION_EMPRESA = "CARGAR_INFORMACION_EMPRESA";
  CONST_PEP_SISTEMA_MSG = "PEP POR SISTEMA";
  CONST_PEP_FORMULARIO_MSG = "PEP POR FORMULARIO";
  isCustomerAlert = false;
  wantUpdate = true;
  wantGetInformation = false;

  constructor(
    private _router: Router,
    private _activatedRoute: ActivatedRoute,
    private _solicitudService: SolicitudService,
    private _bpmService: BpmService,
    private _bureauService: BureauService,
    private _catalogoService: CatalogoService,
    private _compoComunicationService: ComponentCommunicationService,
    private _el: ElementRef
  ) {
    this.communicationSuscription = _compoComunicationService.saveButtonCommunication$.subscribe(
      saveDataButton => {
        if (!!saveDataButton && saveDataButton) {
          this.endProcess();
        }
      }
    );
  }

  ngOnInit() {
    this.isLoadingActive = this.showErrorModal = this.redirectLogin = this.showRejectModal = false;
    this.instanceId = this.decisionGateway = "";
    this.taskId = this._activatedRoute.parent.snapshot.paramMap.get("taskId") || '';
    this.initForm();
    this.getSolicitudSor();
    this.loadCatalogs();
  }

  ngOnDestroy() {
    if (!!this.communicationSuscription) {
      this.communicationSuscription.unsubscribe();
    }
  }

  ngAfterViewInit() {
    const inputList = ([].slice.call((<HTMLElement> this._el.nativeElement).querySelectorAll('input:not(.mat-radio-input)'))).concat([].slice.call((<HTMLElement> this._el.nativeElement).getElementsByTagName('textarea')));
    setScrolIntoView(inputList);
  }

  /**
   * Metodo para inicializar el formulario y actualizarlo con la informacion
   * obtenida en sor
   */
  initForm() {
    this.companyForm = new FormGroup({
      comercialRM: new FormControl('', [Validators.required, Validators.maxLength(100)]),
      nombre: new FormControl('', [Validators.required, Validators.maxLength(100)]),
      numeroDocumento: new FormControl(''),
      direccion: new FormControl('', [Validators.required, Validators.maxLength(100), this.addressValidator.addressComparison()]),
      telefono: new FormControl('', [Validators.required, Validators.minLength(7), Validators.maxLength(7)]),
      pais: new FormControl('', [Validators.required, Validators.maxLength(100)]),
      departamento: new FormControl('', [Validators.required, Validators.maxLength(100)]),
      ciudad: new FormControl('', [Validators.required, Validators.maxLength(100)]),
      tipoEntidad: new FormControl('', [Validators.required, Validators.maxLength(100)]),
      claseSociedad: new FormControl('', [Validators.required, Validators.maxLength(100)]),
      codigoCIIU: new FormControl('', [Validators.required, Validators.maxLength(100)]),
      perteneceGrupoEmpresarial: new FormControl('', [Validators.required, Validators.maxLength(100)]),
      descPerteneceGrupoEmpresarial: new FormControl('', [Validators.maxLength(500)]),
      tieneCalificacionRiesgos: new FormControl('', [Validators.required, Validators.maxLength(100)]),
      descTieneCalificacionRiesgos: new FormControl('', [Validators.maxLength(500)]),
      administraRecPublicos: new FormControl('', [Validators.required, Validators.maxLength(100)]),
      tieneRecPublicoMedComunicacion: new FormControl('', [Validators.required, Validators.maxLength(100)]),
      clientePEP: new FormControl('', [Validators.required, Validators.maxLength(100)]),
      correo: new FormControl('', [Validators.required, Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/)]),
      checkCorreo: new FormControl(false),
      correoOpcional: new FormControl('', Validators.pattern(/^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/))
    });
  }

  /**
   * Metodo para validar los campos del formulario
   */
  validateSubmit() {
    return (
      !!this.companyForm.get('comercialRM').value
      && this.companyForm.get('comercialRM').valid
      && !!this.companyForm.get('nombre').value
      && this.companyForm.get('nombre').valid
      && !!this.companyForm.get('direccion').value
      && this.companyForm.get('direccion').valid
      && !!this.companyForm.get('telefono').value
      && this.companyForm.get('telefono').valid
      && !!this.companyForm.get('pais').value
      && this.companyForm.get('pais').valid
      && !!this.companyForm.get('departamento').value
      && this.companyForm.get('departamento').valid
      && !!this.companyForm.get('ciudad').value
      && this.companyForm.get('ciudad').valid
      && !!this.companyForm.get('correo').value
      && this.companyForm.get('correo').valid
      && !!this.companyForm.get('tipoEntidad').value
      && this.companyForm.get('tipoEntidad').valid
      && !!this.companyForm.get('claseSociedad').value
      && this.companyForm.get('claseSociedad').valid
      && this.validatePepJuridico()
    );
  }

  /**
   * Metodo para validar que los datos con respecto al pep
   * juridico sean diligenciados correctamente
   */
  validatePepJuridico() {
    return (
      this.companyForm.get('perteneceGrupoEmpresarial').valid
      && !!this.companyForm.get('perteneceGrupoEmpresarial').value
      && ((this.companyForm.get('perteneceGrupoEmpresarial').value === 'si' && !!this.companyForm.get('descPerteneceGrupoEmpresarial').value) || this.companyForm.get('perteneceGrupoEmpresarial').value === 'no')
      && this.companyForm.get('tieneCalificacionRiesgos').valid
      && !!this.companyForm.get('tieneCalificacionRiesgos').value
      && ((this.companyForm.get('tieneCalificacionRiesgos').value === 'si' && !!this.companyForm.get('descTieneCalificacionRiesgos').value) || this.companyForm.get('tieneCalificacionRiesgos').value === 'no')
      && this.companyForm.get('administraRecPublicos').valid
      && !!this.companyForm.get('administraRecPublicos').value
      && this.companyForm.get('tieneRecPublicoMedComunicacion').valid
      && !!this.companyForm.get('tieneRecPublicoMedComunicacion').value
      && this.companyForm.get('clientePEP').valid
      && !!this.companyForm.get('clientePEP').value
    );
  }

  /**
   * Metodo para obtener la data previa en SOR
   */
  async getSolicitudSor() {
    this.isLoadingActive = true;
    try {
      await this.getProcessData();
      if (!!this.instanceId) {
        const solicitudRq = new Solicitud();
        solicitudRq.idSolicitud = this.instanceId;
        const solicitudRs = await this._solicitudService.getSolicitud(solicitudRq);
        if (!!solicitudRs && !!solicitudRs.datosSolicitud) {
          this.datosSolicitud = JSON.parse(solicitudRs.datosSolicitud);
          await this.validUserDB();
          this.updateFormDataFromSOR();
          this.updateSidebar();
        }
      } else {
        this.showModalErrorAndExitLogin();
      }
    } catch (error) {
      this.showErrorModal = true;
    }
    this.isLoadingActive = false;
  }
  /**
   * Metodo que valida si el usuario existe
   */
  async validUserDB() {
    if (this.datosSolicitud.clienteJuridico.clientFound) {
      this.isCustomerAlert = true;
    }
  }
  /**
   * Metodo que recibe la decision del usuario para actulizar el cliente
   */
  async doYouWantUpdateUser(action: boolean) {
    if (action) {
      this.isCustomerAlert = false;
      if (!this.wantUpdate) {
        this.wantGetInformation = true;
      }
    } else {
      this.wantUpdate = false;
      await this.saveDataSor(true);
    }
  }
  /** Metodo que cierra el modal */
  closeModal() {
    this.isCustomerAlert = false;
    this.wantUpdate = false;
    this.companyForm.disable();
  }
  /** Metodo que actliza la informacion desde consultar */
  update() {
    this.wantUpdate = true;
    this.wantGetInformation = false;
  }
  /**
   * Metodo para reanudar la actividad con la informacion
   * obtenida en SOR y sincronizada en el formulario
   */
  updateFormDataFromSOR() {
    this.companyForm = getDatosContacto(this.companyForm, this.datosSolicitud);
    this.updateDeptoFilter(this.companyForm.get('pais').value || '', false);
    this.updateCityFilter(this.companyForm.get('departamento').value || '', false);
    this.updateClaseSociedadFilter(this.companyForm.get('tipoEntidad').value || '', false);
  }

  /**
   * Metodo que almacena la informacion de los formularios en
   * el canonico que se va almacenar en SOR
   */
  async processSolicitudData() {
    this.setRiskSCAP();
    this.setRiskSIAP();
    this.datosSolicitud = updateDatosContacto(this.datosSolicitud, this.companyForm, this.datosRiesgoCliente);
  }

  /**
   * Metodo que se encarga de guardar en SOR y finalizar la tarea
   */
  async submit() {
    await this.saveDataSor(true);
  }

  /**
   * Metodo para guardar la solicitud en sor
   * @param value Valor de decision para finalizar tarea
   */
  async saveDataSor(value: boolean) {
    this.isLoadingActive = true;
    await this.getTaskInfo();
    let bureauResult = true;
    if (value) { bureauResult = await this.getListas(); }
    if (bureauResult) {
      if (!!this.instanceId) {
        await this.processSolicitudData();
        const enrutamiento = await this.getRule();
        this.datosSolicitud = updateDatosDocumento(this.datosSolicitud, enrutamiento);
        const solicitudSorRq = new Solicitud();
        solicitudSorRq.idSolicitud = this.instanceId;
        solicitudSorRq.setDatosSolicitud(this.datosSolicitud);
        const saveResult = await this._solicitudService.saveSolicitud(solicitudSorRq);
        if (!!saveResult) {
          if (value) {
            await this.finishTask(enrutamiento);
          }
        } else {
          this.showErrorModal = true;
        }
      } else {
        this.showModalErrorAndExitLogin();
      }
    } else {
      this.showErrorModal = true;
    }
    this.isLoadingActive = false;
  }

  /**
   * Metodo para finalizar el proceso
   */
  async endProcess() {
    await this.saveDataSor(false);
    this.redirectUrl('/portal/');
  }

  /**
   * Metodo para finalizar la tarea actual
   * @param saveResult Valor booleano que decise si finaliza la tarea
   */
  async finishTask(enrutamiento: any) {
    this.decisionGateway = !this.datosSolicitud.clienteJuridico.clientFound ? "crearCliente" :
    this.wantUpdate ?  "actualizarCliente" : "rechazoClienteExistente";
    const resultConsultaListas = await this.getConsultaListas();
    const resultEnrrutamiento = await this.getEnrutamiento(enrutamiento);
    if (!!resultEnrrutamiento) {
      resultConsultaListas.decisionGateway.value = this.decisionGateway + "-" + resultConsultaListas.decisionGateway.value + "-" + resultEnrrutamiento.decisionGateway.value;
    }
    resultConsultaListas["subject"] = {
      "value" : this.datosSolicitud.clienteJuridico.datosGenerales.tipoDocumento.split('-')[1]
                + ' ' + this.datosSolicitud.clienteJuridico.datosGenerales.numeroDocumento
                + ' ' + this.datosSolicitud.clienteJuridico.datosContacto.nombre
    };
    if (!!resultConsultaListas) {
      const request = new FinishTaskRequest();
      request.taskId = this.taskId;
      request.variable = resultConsultaListas;
      const finishTaskRs = await this._bpmService.finishTask(request);
      if (!!finishTaskRs) {
        if (resultConsultaListas.decisionGateway.value.indexOf('enrutamientoRechazo') !== -1) {
          this.isLoadingActive = false;
          this.showRejectModal = true;
        } else {
          const processInstanceRq = new ProcessInstanceRequest();
          processInstanceRq.processInstanceId = this.instanceId;
          const getNextTaskRs = await this._bpmService.getNextTask(processInstanceRq);
          if (!!getNextTaskRs && getNextTaskRs.length > 0) {
            const body = new ClaimTaskRequest();
            body.idTask = getNextTaskRs[0].id;
            const claimTask = await this._bpmService.getClaimTask(body);
            if (!!claimTask) {
              this.isLoadingActive = false;
              this.redirectExternalUrl(claimTask.path);
            } else {
              this.showErrorModal = true;
            }
          } else {
            this.redirectUrl('/portal/');
          }
        }
      } else {
        this.showErrorModal = true;
      }
    } else {
      this.showErrorModal = true;
    }
  }

  /**
   * Metodo para navegar a una url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      this._router.navigate(['/externalRedirect', { externalUrl: domain }], {
        skipLocationChange: true,
      });
    }
  }

  /**
   * Metodo para navegar al login como url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectExternalUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      window.open(domain, '_self');
    }
  }

  /**
   * Metodo para filtrar los resultados del catalogo comparado
   * con lo que el usuario escribe
   * @param value Valor proporcionado por el usuario
   */
  private _filterCountry(value: string): string[] {
    const filterValue = !!value ? value.toLowerCase() : "";
    return this.countries.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  /**
   * Metodo para filtrar los resultados del catalogo comparado
   * con lo que el usuario escribe
   * @param value Valor proporcionado por el usuario
   */
  private _filterDepartment(value: any): string[] {
    const filterValue = value.toLowerCase();
    return this.departments.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  /**
   * Metodo para filtrar los resultados del catalogo comparado
   * con lo que el usuario escribe
   * @param value Valor proporcionado por el usuario
   */
  private _filterCity(value: any): string[] {
    const filterValue = value.toLowerCase();
    return this.cities.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  /**
   * Metodo para filtrar los resultados del catalogo de tipos de entidad, comparado
   * con lo que el usuario escribe
   * @param value Valor proporcionado por el usuario
   */
  private _filterTipoEntidad(value: string): string[] {
    const filterValue = !!value ? value.toLowerCase() : "";
    return this.tiposEntidades.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  /**
   * Metodo para filtrar los resultados del catalogo de clases de sociedad, comparado
   * con lo que el usuario escribe
   * @param value Valor proporcionado por el usuario
   */
  private _filterClaseSociedad(value: string): string[] {
    const filterValue = !!value ? value.toLowerCase() : "";
    return this.clasesSociedades.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  /**
   * Metodo para filtrar los resultados del catalogo de comerciales, comparado
   * con lo que el usuario escribe
   * @param value Valor proporcionado por el usuario
   */
  private _filterComerciales(value: string): string[] {
    const filterValue = !!value ? value.toLowerCase() : "";
    return this.comerciales.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  /**
   * Metodo para filtrar los resultados del catalogo de codigos CIIU, comparado
   * con lo que el usuario escribe
   * @param value Valor proporcionado por el usuario
   */
  private _filterCodigoCiiu(value: string): string[] {
    const filterValue = !!value ? value.toLowerCase() : "";
    return this.codigosCiiu.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  /**
   * Metodo para cargar los catalogos del formulario
   */
  loadCatalogs() {
    CATALOGS_DATA_CUSTOMER.forEach(async element => {
      if (element === "Pais" || element === "tipoEntidad" || element === "Comercial" || element === "CIIU") {
        const catalogoRq = new CatalogoRequest();
        catalogoRq.catalogName = element;
        const catalogoRs = await <any> this._catalogoService.getCatalog(catalogoRq);
        if (!!catalogoRs && !!catalogoRs.catalogName) {
          switch (element) {
            case "CIIU":
              this.codigosCiiu = catalogoRs.items;
              this.codigosCiiu.forEach((element) => {
                element.name = (!!element.name) ? capitalizeText(element.name.toLowerCase()) : '';
              });
              this.filteredOptionsCodigosCiiu = this.companyForm.get('codigoCIIU').valueChanges.pipe(startWith(''), map(value => this._filterCodigoCiiu(value)));
              if (!!this.codigosCiiu) {
                this.companyForm.get("codigoCIIU").setValidators([Validators.required, Validators.maxLength(100), idValueCatalogValidator(this.codigosCiiu)]);
              }

              break;
            case "Comercial":
              const filteredItems = [];
              catalogoRs.items.forEach(
                (item) => {
                  const findItem = filteredItems.find((obj) =>  obj.name === item.name);
                  if (!(!!findItem)) {
                    filteredItems.push(item);
                  }
                }
              );
              this.comerciales = filteredItems;
              this.comerciales.forEach((element) => {
                element.name = (!!element.name) ? capitalizeText(element.name.toLowerCase()) : '';
              });
              this.filteredOptionsComerciales = this.companyForm.get('comercialRM').valueChanges.pipe(startWith(''), map(value => this._filterComerciales(value)));
              if (!!this.countries) {
                this.companyForm.get("comercialRM").setValidators([Validators.maxLength(100), idValueCatalogValidator(this.comerciales)]);
              }

              break;
            case "Pais":
              this.countries = catalogoRs.items;
              this.countries.forEach((element) => {
                element.name = (!!element.name) ? capitalizeText(element.name.toLowerCase()) : '';
                if (element.name === "Colombia") { this.paisFavorito = element; }
              });
              this.filteredOptionsPais = this.companyForm.get('pais').valueChanges.pipe(startWith(''), map(value => this._filterCountry(value)));
              if (!!this.countries) {
                this.companyForm.get("pais").setValidators([Validators.maxLength(100), idValueCatalogValidator(this.countries)]);
              }

              break;
            case "tipoEntidad":
              this.tiposEntidades = catalogoRs.items;
              this.tiposEntidades.forEach((element) => {
                element.name = (!!element.name) ? capitalizeText(element.name.toLowerCase()) : '';
              });
              this.filteredOptionsTiposEntidad = this.companyForm.get('tipoEntidad').valueChanges.pipe(startWith(''), map(value => this._filterTipoEntidad(value)));
              if (!!this.tiposEntidades) {
                this.companyForm.get("tipoEntidad").setValidators([Validators.maxLength(100), idValueCatalogValidator(this.tiposEntidades)]);
              }

              break;
          }
        }
      }
    });
  }

  /**
   * Metodo para consultar un catalogo via REST en api-catalogo
   * @param catalogName nombre del catalogo a consultar
   * @param idParent consulta de la llave padre
   */
  async loadCatalog(catalogName: string, idParent: string) {
    const catalogoRq = new CatalogoRequest();
    catalogoRq.catalogName = catalogName;
    catalogoRq.idParent = idParent || '';
    const catalogoRs = await this._catalogoService.getCatalog(catalogoRq);
    if (!!catalogoRs) {
      catalogoRs.items.forEach(element => {
        element.name = (!!element.name) ? capitalizeText(element.name.toLowerCase()) : '';
      });
    }
    return catalogoRs;
  }

  /**
   * Metodo que actualiza los departamentos del documento de
   * expedicion de acuerdo al país
   * @param idParent hace referencia al id del pais para consultar
   * los departamentos relacionados
   */
  async updateDeptoFilter(idParent: string, resetFields: boolean) {
    if (!!idParent) {
      if (resetFields) {
        this.companyForm.get('departamento').setValue('');
        this.companyForm.get('ciudad').setValue('');
      }
      const catalogoRs = await this.loadCatalog('Departamento', (idParent.split('-')[0].trim() || ''));
      this.departments = catalogoRs.items;
      this.filteredOptionsDepto = this.companyForm.get('departamento').valueChanges.pipe(startWith(''), map(value => this._filterDepartment(value)));
      this.companyForm.get("departamento").setValidators([Validators.maxLength(100), parentValueCatalogValidator(this.departments)]);
    }
  }

  /**
   * Metodo que actualiza las clases de sociedad de la empresa
   * de acuerdo al tipo de entidad seleccionada
   * @param idParent hace referencia al id del tipo de entidad para consultar
   * los tipos de sociedad
   */
  async updateClaseSociedadFilter(idParent: string, resetFields: boolean) {
    if (!!idParent) {
      if (resetFields) {
        this.companyForm.get('claseSociedad').setValue('');
      }
      const catalogoRs = await this.loadCatalog('claseSociedad', (idParent.split('-')[0].trim() || ''));
      this.clasesSociedades = catalogoRs.items;
      this.filteredOptionsClasesSocidad = this.companyForm.get('claseSociedad').valueChanges.pipe(startWith(''), map(value => this._filterClaseSociedad(value)));
      this.companyForm.get("claseSociedad").setValidators([Validators.maxLength(100), parentValueCatalogValidator(this.clasesSociedades)]);
    }
  }

  /**
   * Metodo para actualizar las ciudades de acuerdo al pais ingresado
   * @param idParent hace referencia al id del departamento para consultar
   * las ciudades relacionadas
   */
  async updateCityFilter(idParent: string, resetFields: boolean) {
    if (!!idParent) {
      if (resetFields) {
        this.companyForm.get('ciudad').setValue('');
      }
      const catalogoRs = await this.loadCatalog('Ciudad', (idParent.split('-')[0].trim() || ''));
      this.cities = catalogoRs.items;
      this.filteredOptionsCiudad = this.companyForm.get('ciudad').valueChanges.pipe(startWith(''), map(value => this._filterCity(value)));
      this.companyForm.get("ciudad").setValidators([Validators.maxLength(100), parentValueCatalogValidator(this.cities)]);
    }
  }

  /**
   * Metodo para mostrar el nombre en un catalogo
   * @param value Valor proporcionado por el catalogo
   */
  displayName(value: any) {
    if (!!value && typeof (value) === "string") {
      const formatText = value.split('-');
      return formatText[1].trim();
    }
  }

  /**
   * Metodo para mostrar el nombre en un catalogo especial para CIIU
   * @param value Valor proporcionado por el catalogo
   */
  displayNameCIIU(value) {
    let result = "";
    if (!!value && typeof (value) === "string") {
      const formatText = value.split('-');
      try {
        result = formatText[1].trim().concat(' - ').concat(formatText[2].trim());
      } catch (error) {
        result = formatText[1].trim();
      }
    }
    return result;
  }

  /**
   * Metodo para obtener los datos del proceso, en
   * este caso el id de la instancia
   */
  async getProcessData() {
    await this.getTaskInfo();
    if (!(!!this.instanceId)) {
      this.showModalErrorAndExitLogin();
    }
  }

  /**
   * Metodo para obtener los datos de la tarea
   */
  async getTaskInfo() {
    const taskModelRq = new GetTaskByIdRequest();
    taskModelRq.taskId = this.taskId;
    const getTaskInfoRs = await this._bpmService.getTaskInfo(taskModelRq);
    if (!!getTaskInfoRs) {
      this.instanceId = getTaskInfoRs.processInstanceId;
    } else {
      this.instanceId = null;
    }
  }

  /**
   * Metodo para mostrar el error con la opcion de redirigir
   * a la bandeja de tareas
   */
  showModalErrorAndExitLogin() {
    this.showErrorModal = true;
    this.redirectLogin = true;
  }

  /**
   * Metodo para cerrar el modal del error
   * @param value Valor proporcionado por el componente de error Modal
   */
  closeErrorModal(value: boolean) {
    this.showErrorModal = value;
    if (this.redirectLogin) {
      this.redirectUrl('/portal/');
    }
  }

  /**
   * Metodo para enviar objeto a la barra lateral con el fin de que se actualice
   * segun la informacion procesada
   */
  async updateSidebar() {
    if (!!this.instanceId) {
      const datosSolicitud = updateDatosContacto(this.datosSolicitud, this.companyForm);
      if (!!datosSolicitud) {
        const dataPage = {
          "currentPage" : this.CONST_CARGAR_INFORMACION_EMPRESA,
          "dataSolicitud" : datosSolicitud
        };
        this._compoComunicationService.emmitSideBarEvent(dataPage);
      }
    }
  }

  /**
   * Metodo para obtener el bureau del cliente y mostrar los correspondientes
   * campos en la pantalla
   */
  async getListas() {
    this.datosRiesgoCliente = new DatosRiesgo();
    const stradataRq = mappingStradata(this.companyForm, this.datosSolicitud);
    const stradataRs = await this._bureauService.getStradata(stradataRq);
    if (!!stradataRs) {
      if (!!stradataRs.isPep) {
        this.datosRiesgoCliente.isPep = 'si';
        this.datosRiesgoCliente.porcentajePep = stradataRs.porcentajePep || 0;
        this.datosRiesgoCliente.pepReasons = this.CONST_PEP_SISTEMA_MSG;
      } else if (this.validatePep()) {
        this.datosRiesgoCliente.isPep = 'si';
        this.datosRiesgoCliente.porcentajePep = 100;
        this.datosRiesgoCliente.pepReasons = this.CONST_PEP_FORMULARIO_MSG;
      } else {
        this.datosRiesgoCliente.isPep = 'no';
        this.datosRiesgoCliente.porcentajePep = 0;
      }
      this.datosRiesgoCliente.isMedia = stradataRs.isMedia;
      this.datosRiesgoCliente.porcentajeMedia = stradataRs.porcentajeMedia || 0;
      this.datosRiesgoCliente.listasVinculantes = stradataRs.listasVinculantes;
      this.datosRiesgoCliente.porcentajeListaVinculante = stradataRs.porcentajeListaVinculante || 0;
      this.datosRiesgoCliente.listasNoVinculantes = stradataRs.listasNoVinculantes;
      this.datosRiesgoCliente.porcentajeListaNoVinculante = stradataRs.porcentajeListaNoVinculante || 0;
      this.datosRiesgoCliente.nombreProcuraduria = stradataRs.nombreProcuraduria;
      this.datosRiesgoCliente.continuarPorProcuraduria = stradataRs.continuarPorProcuraduria;
      this.datosRiesgoCliente.listasReportado = stradataRs.listasReportado;
      return true;
    } else {
      return false;
    }
  }

  /**
   * Metodo para consultar la regla de enrutamiento de acuerdo
   * al camino a seguir segun el riesgo del cliente
   */
  async getConsultaListas() {
    if (!!this.datosSolicitud && !!this.datosSolicitud.clienteJuridico && !!this.datosSolicitud.clienteJuridico.datosRiesgo) {
      const enrutamientoRq = mappingConsultaListas(this.datosSolicitud.clienteJuridico.datosRiesgo);
      const enrutamientoRs = await this._bpmService.callBPMRule(enrutamientoRq);
      if (!!enrutamientoRs && enrutamientoRs.length > 0) {
        const resultEnrutamiento = enrutamientoRs[0];
        const variableBPM = {
          "decisionGateway": {
            "value": resultEnrutamiento.respuestaEnrutamiento.value
          }
        };
        return variableBPM;
      }
    }
    return null;
  }

  /**
   * Metodo para cerrar el modal del error
   * @param value Valor proporcionado por el componente Modal
   */
  async closeRejectModal(value: boolean) {
    this.isLoadingActive = true;
    this.showRejectModal = value;
    this.delay(2000);
    this.redirectUrl('/portal/');
  }

  delay(ms: number) {
    return new Promise( resolve => setTimeout(resolve, ms) );
  }

  /**
   * Metodo para consultar la regla de enrutamiento de acuerdo
   * al camino a seguir segun el riesgo del cliente
   */
  async getEnrutamiento(enrutamiento: any) {
    if (!!enrutamiento) {
      const resultEnrutamiento = enrutamiento.respuestaPantalla.value;
      const variableBPM = {
        "decisionGateway": {
          "value": resultEnrutamiento
        }
      };
      return variableBPM;
    }
    return null;
  }

  /**
   * Metodo para consultar la regla de enrutamiento de acuerdo
   * al camino a seguir segun el riesgo del cliente
   */
  async getRule() {
    if (!!this.datosSolicitud && !!this.datosSolicitud.clienteJuridico && !!this.datosSolicitud.clienteJuridico.datosContacto) {
      const enrutamientoRq = mappingEnrutamiento(this.datosSolicitud.clienteJuridico.datosContacto);
      const enrutamientoRs = await this._bpmService.callBPMRule(enrutamientoRq);
      if (!!enrutamientoRs && enrutamientoRs.length > 0) {
        return enrutamientoRs[0];
      }
    }
    return null;
  }

  /**
   * Metodo para calcular el riesgo SIAP de acuerdo al riesgo del campo
   * de actividad economica
   */
  setRiskSIAP() {
    if (!(!!this.datosRiesgoCliente)) {
      this.datosRiesgoCliente = new DatosRiesgo();
    }
    const idCIIU = !!this.companyForm.get("codigoCIIU") && !!this.companyForm.get("codigoCIIU").value ? this.companyForm.get("codigoCIIU").value.split('-')[0] : '';
    if (!!this.codigosCiiu && !!idCIIU) {
      const ciiu = this.codigosCiiu.find((obj) => obj.id === idCIIU.trim());
      if (!!ciiu && !!ciiu.strDescripcion) {
        const riesgoCiiu = ciiu.strDescripcion.toLowerCase();
        this.datosRiesgoCliente.siapRisk = (riesgoCiiu.indexOf("alto") !== -1 ? "alto" : (riesgoCiiu.indexOf("sensible") !== -1 ? "sensible" : "bajo"));
      }
    } else {
      this.datosRiesgoCliente.siapRisk = "bajo";
    }
  }

  /**
   * Metodo que calcula el riesgo SCAP de acuerdo al riesgo del
   * pais de la empresa
   */
  setRiskSCAP() {
    if (!(!!this.datosRiesgoCliente)) {
      this.datosRiesgoCliente = new DatosRiesgo();
    }
    const riesgoPaisEmpresa = this.findRiesgoPais(!!this.companyForm.get('pais') && !!this.companyForm.get('pais').value ? this.companyForm.get('pais').value.split('-')[0] : '');
    if (!!riesgoPaisEmpresa) {
      this.datosRiesgoCliente.scapRisk = riesgoPaisEmpresa;
    } else {
      this.datosRiesgoCliente.scapRisk = 'bajo';
    }
  }

  /**
   * Metodo para obtener el pais de la lista de paises obtenida
   * por el catalogo
   * @param idPais id del pais para realizar la consulta
   */
  findRiesgoPais(idPais): string {
    if (!!idPais && !!this.countries) {
      const pais = this.countries.find((obj) => obj.id === idPais.trim());
      if (!!pais && !!pais.riesgo) {
        return pais.riesgo.toLowerCase();
      }
    }
    return '';
  }

  /**
   * Metodo para limpiar un campo del formulario
   * @param formControlName nombre del campo del FormGroup a limpiar
   */
  resetFormInput(formControlName) {
    if (!!this.companyForm.get(formControlName)) {
      this.companyForm.get(formControlName).reset();
    }
    this.updateSidebar();
  }

  /**
   * Metodo para asignar pep de acuerdo a las preguntas
   * donde exista un si, este será PEP y será evaluado por AML
   */
  validatePep() {
    return (
      (!!this.companyForm.get('perteneceGrupoEmpresarial').value
      && this.companyForm.get('perteneceGrupoEmpresarial').value === 'si')
      ||
      (!!this.companyForm.get('tieneCalificacionRiesgos').value
      && this.companyForm.get('tieneCalificacionRiesgos').value === 'si')
      ||
      (!!this.companyForm.get('administraRecPublicos').value
      && this.companyForm.get('administraRecPublicos').value === 'si')
      ||
      (!!this.companyForm.get('tieneRecPublicoMedComunicacion').value
      && this.companyForm.get('tieneRecPublicoMedComunicacion').value === 'si')
      ||
      (!!this.companyForm.get('clientePEP').value
      && this.companyForm.get('clientePEP').value === 'si')
    );
  }
}
