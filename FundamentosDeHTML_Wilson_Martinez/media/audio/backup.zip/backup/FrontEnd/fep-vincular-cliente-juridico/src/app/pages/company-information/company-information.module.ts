import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../../material/material.module';
import { CompanyInformationComponent } from './company-information.component';
import { SharedModule } from '../../shared/shared.module';
import { AuthGuardService as AuthGuard } from '../../shared/services/auth-guard.service';
import { ComponentsModule } from 'src/app/components/components.module';

const routes: Routes = [
  { path: '', component: CompanyInformationComponent, canActivate: [AuthGuard] }
];

@NgModule({
  declarations: [CompanyInformationComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    SharedModule,
    ComponentsModule,
    RouterModule.forChild(routes)
  ]
})
export class CompanyInformationModule { }
