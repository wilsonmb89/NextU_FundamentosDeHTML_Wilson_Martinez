import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentCustomerComponent } from './document-customer.component';

describe('DocumentCustomerComponent', () => {
  let component: DocumentCustomerComponent;
  let fixture: ComponentFixture<DocumentCustomerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentCustomerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentCustomerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
