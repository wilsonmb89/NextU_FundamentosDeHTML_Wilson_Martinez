import { Component, OnInit, OnDestroy } from '@angular/core';
import { CATALOGS_DOCUMENT_CUSTOMER } from 'src/app/utils/constants/utils.constant';
import { CatalogoRequest } from 'src/app/shared/utils/mapping/CatalogoRequest';
import { CatalogoService } from 'src/app/shared/services/catalogo.service';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { GetTaskByIdRequest } from 'src/app/shared/utils/models/api-bpm/GetTaskByIdRequest';
import { BpmService } from 'src/app/shared/services/bpm.service';
import { Solicitud } from 'src/app/shared/utils/models/Solicitud/Solicitud';
import { SolicitudService } from 'src/app/shared/services/solicitud.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FinishTaskRequest } from 'src/app/shared/utils/models/api-bpm/FinishTaskRq';
import { ProcessInstanceRequest } from 'src/app/shared/utils/models/api-bpm/ProcessInstanceRequest';
import { ClaimTaskRequest } from 'src/app/shared/utils/models/api-bpm/ClaimTaskRq';
import { DocumentService } from 'src/app/shared/services/document.service';
import { uploadDoc, getDoc, getScanDoc } from 'src/app/utils/mapping/UploadDocMapping';
import { ComponentCommunicationService } from 'src/app/services/component-communication.service';
import { Subscription } from 'rxjs';
import { getNombresCalidad, getAcronimoTipoParticipante } from 'src/app/utils/functions/transform';
import { DatosAccionistas } from 'src/app/utils/models/api-solicitud/DatosAccionistas';
import { PersonaJuridica } from 'src/app/utils/models/api-cliente/PersonaJuridica';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'app-document-customer',
  templateUrl: './document-customer.component.html',
  styleUrls: ['./document-customer.component.scss']
})
export class DocumentCustomerComponent implements OnInit, OnDestroy {

  taskId: string;
  instanceId: string;
  redirectLogin: boolean;
  modalIsShowed: boolean;
  showErrorModal: boolean;
  isLoadingActive: boolean;
  bodyPdf: any;
  propiedades: any;
  empresa = [];
  ordenantes = [];
  dataSource = [];
  accionistas = [];
  representanteLegal = [];
  displayedColumns: string[] = ['check', 'name', 'requerido', 'file', 'view'];
  dataSolicitud: DatosSolicitud;
  communicationSuscription: Subscription;
  CONST_DOC_REQ_TYPE = "REQ";
  CONST_TYPE_PDF = "data:application/pdf;base64,";
  CONST_CARGAR_INFORMACION_DOCUMENTOS = "CARGAR_INFORMACION_DOCUMENTOS";
  CONST_EMPRESA_PROPIEDAD = "Empresa";

  constructor(
    private _router: Router,
    private _activatedRoute: ActivatedRoute,
    private _catalogoService: CatalogoService,
    private _solicitudService: SolicitudService,
    private _documentService: DocumentService,
    private _bpmService: BpmService,
    private _compoComunicationService: ComponentCommunicationService,
    private _customerService: CustomerService,
    ) {
    this.communicationSuscription = _compoComunicationService.saveButtonCommunication$.subscribe(
      saveDataButton => {
        if (!!saveDataButton && saveDataButton) {
          this.endProcess();
        }
      }
    );
  }

  ngOnInit() {
    this.instanceId = this.bodyPdf = this.propiedades = "";
    this.taskId = this._activatedRoute.parent.snapshot.paramMap.get("taskId") || '';
    this.isLoadingActive = this.showErrorModal = this.redirectLogin = this.modalIsShowed = false;
    this.getSolicitudSor();
  }

  ngOnDestroy() {
    if (!!this.communicationSuscription) {
      this.communicationSuscription.unsubscribe();
    }
  }

  /**
   * Metodo para obtener la data previa en SOR
   */
  async getSolicitudSor() {
    this.isLoadingActive = true;
    try {
      await this.getProcessData();
      if (!!this.instanceId) {
        const solicitudRq = new Solicitud;
        solicitudRq.idSolicitud = this.instanceId;
        const solicitudRs = await this._solicitudService.getSolicitud(solicitudRq);
        if (!!solicitudRs && !!solicitudRs.datosSolicitud) {
          this.dataSolicitud = JSON.parse(solicitudRs.datosSolicitud);
          await this.validUser();
          await this.documentosRequeridos();
          this.updateSidebar();
        }
      } else {
        this.showModalErrorAndExitLogin();
      }
    } catch (error) {
      this.showErrorModal = true;
    }
    this.isLoadingActive = false;
  }

  /** Metodo que valida si el usuario existe*/
  async validUser() {
    if (this.dataSolicitud.clienteJuridico.clientFound) {
      const cliente = this.dataSolicitud.clienteJuridico.datosGenerales;
      const fileName = cliente.tipoDocumento.split("-")[1].trim() + "/"
        + cliente.numeroDocumento.replace(/\D/g, '') + "/REQ/";
      const body = { filesPath: fileName };
      const listDocuments = await this._documentService.getDocumentsByPath(body);
      const document = this.dataSolicitud.clienteJuridico.datosDocumento.documentosSolicitados;
      document.empresa.forEach(document => {
        const foundDocument = listDocuments.listDocNames.find(e => e.includes(document.tipo));
        if (foundDocument) {
          document.upload = false;
          document.viewFile = true;
        }
      });
    }
  }

  /**
   * Metodo para obtener los datos del proceso, en
   * este caso el id de la instancia
   */
  async getProcessData() {
    await this.getTaskInfo();
    if (!(!!this.instanceId)) {
      this.showModalErrorAndExitLogin();
    }
  }

  /**
   * Metodo para obtener los datos de la tarea
   */
  async getTaskInfo() {
    const taskModelRq = new GetTaskByIdRequest();
    taskModelRq.taskId = this.taskId;
    const getTaskInfoRs = await this._bpmService.getTaskInfo(taskModelRq);
    if (!!getTaskInfoRs) {
      this.instanceId = getTaskInfoRs.processInstanceId;
    } else { this.instanceId = null; }
  }

  /**
   * Metodo para mostrar el error con la opcion de redirigir
   * a la bandeja de tareas
   */
  showModalErrorAndExitLogin() {
    this.showErrorModal = true;
    this.redirectLogin = true;
  }

  /**
   * Metodo para cargar el catalogo de Documentos
   */
  async documentosRequeridos() {
    this.isLoadingActive = true;
    const catalogoRq = new CatalogoRequest();
    catalogoRq.catalogName = CATALOGS_DOCUMENT_CUSTOMER;
    const catalogoRs = await <any>this._catalogoService.getCatalog(catalogoRq);
    if (!!catalogoRs && !!catalogoRs.catalogName && catalogoRs.catalogName === "Documento") {
      this.propiedades = Object.keys(this.dataSolicitud.clienteJuridico.datosDocumento.documentosSolicitados);
      await this.propiedades.forEach(async propiedad => {
        switch (propiedad) {
          case "empresa":
            this.empresa = await this.docsByPropoerty(propiedad);
            break;
        }
      });
      this.propiedades = getNombresCalidad(this.propiedades);
      this.dataSource = this.dataSource.concat(this.empresa);
      await this.validProgressBar();
      this.isLoadingActive = false;
    }
  }

  async docsByPropoerty(propiedad) {
    const docsRequired = [];
    this.dataSolicitud.clienteJuridico.datosDocumento.documentosSolicitados[propiedad].forEach(doc => {
      doc.upload = !!doc.upload ? doc.upload : false;
      doc.viewFile = !!doc.viewFile ? doc.viewFile : false;
      if (doc.aprobado) {
        doc.upload = true;
        doc.viewFile = true;
      }
      if (doc.check && doc.requerido && !doc.aprobado) {
        docsRequired.push(doc);
      }
    });
    return docsRequired;
  }

  /**
   * Metodo para retornar una lista de participantes de acuerdo al tipo de participante
   * del objeto cliente juridico
   * @param participant es el tipo de participante
   */
  getParticipantList(participant) {
    switch (participant) {
      case "Ordenantes": return !!this.dataSolicitud.clienteJuridico.datosOrdenantes ? this.dataSolicitud.clienteJuridico.datosOrdenantes : [] || [];
      case "Accionistas": return !!this.dataSolicitud.clienteJuridico.datosAccionistas ? this.dataSolicitud.clienteJuridico.datosAccionistas.accionistas : [] || [];
      case "Representante Legal": return !!this.dataSolicitud.clienteJuridico.datosRepresentanteLegal ? this.dataSolicitud.clienteJuridico.datosRepresentanteLegal : [] || [];
    }
  }

  dataSources(value) {
    switch (value) {
      case "Empresa": return this.empresa;
    }
  }

  /**
   * Metodo para validar los archivos adjuntos en el formulario
   */
  validateSubmit() {
    if (!!this.dataSource) {
      return this.dataSource.every((doc) => {
        return (!doc.upload && doc.viewFile) || (doc.upload && doc.viewFile);
      });
    }
  }

  /**
   * Metodo para cerrar el modal del error
   * @param value Valor proporcionado por el componente de error Modal
   */
  closeErrorModal(value: boolean) {
    this.showErrorModal = value;
    if (this.redirectLogin) {
      this.redirectUrl('/portal/');
    }
  }

  /**
   * Metodo para navegar a una url externa
   * @param url Valor que representa la ruta a tomar
   */
  async redirectUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      this._router.navigate(['/externalRedirect', { externalUrl: domain }], {
        skipLocationChange: true,
      });
    }
  }

  /**
   * Metodo para cerrar el modal del PDF
   * @param value Valor proporcionado por el componente de PDF Modal
   */
  closePdfModal(value: boolean) {
    this.modalIsShowed = value;
  }

  /**
   * Metodo para guardar la solicitud en sor
   * @param value Valor de decision para finalizar tarea
   */
  async saveDataSor(value: boolean) {
    this.isLoadingActive = true;
    await this.getTaskInfo();
    if (!!this.instanceId) {
      await this.processSolicitudData();
      const solicitudSorRq = new Solicitud();
      solicitudSorRq.idSolicitud = this.instanceId;
      solicitudSorRq.setDatosSolicitud(this.dataSolicitud);
      const saveResult = await this._solicitudService.saveSolicitud(solicitudSorRq);
      if (!!saveResult) {
        if (value) {
          await this.finishTask();
        }
      } else {
        this.showErrorModal = true;
      }
    } else {
      this.showModalErrorAndExitLogin();
    }
    this.isLoadingActive = false;
  }

  /**
   * Metodo para finalizar la tarea actual
   * @param saveResult Valor booleano que decise si finaliza la tarea
   */
  async finishTask() {
    const request = new FinishTaskRequest();
    request.taskId = this.taskId;
    const finishTaskRs = await this._bpmService.finishTask(request);
    if (!!finishTaskRs) {
      const processInstanceRq = new ProcessInstanceRequest();
      processInstanceRq.processInstanceId = this.instanceId;
      const getNextTaskRs = await this._bpmService.getNextTask(processInstanceRq);
      if (!!getNextTaskRs && getNextTaskRs.length > 0) {
        const body = new ClaimTaskRequest();
        body.idTask = getNextTaskRs[0].id;
        const claimTask = await this._bpmService.getClaimTask(body);
        if (!!claimTask) {
          this.isLoadingActive = false;
          this.redirectExternalUrl(claimTask.path);
        } else {
          this.showErrorModal = true;
        }
      } else {
        this.redirectUrl('/portal/');
      }
    } else {
      this.showErrorModal = true;
    }
  }

  /**
   * Metodo para navegar al login como url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectExternalUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      window.open(domain, '_self');
    }
  }

  /**
   * Metodo que elimina los atributos innecesarios
   * de los documentos
   */
  async processSolicitudData() {
    const propiedades = Object.keys(this.dataSolicitud.clienteJuridico.datosDocumento.documentosSolicitados);
    propiedades.forEach(propiedad => {
      this.dataSolicitud.clienteJuridico.datosDocumento.documentosSolicitados[propiedad].forEach(element => {
        if (!!element.file) { delete element.file; }
      });
    });
  }

  /**
   * Metodo para enviar objeto a la barra lateral con el fin de que se actualice
   * segun la informacion procesada
   */
  async updateSidebar() {
    if (!!this.instanceId) {
      if (!!this.dataSolicitud) {
        const dataPage = {
          "currentPage" : this.CONST_CARGAR_INFORMACION_DOCUMENTOS,
          "dataSolicitud" : this.dataSolicitud
        };
        this._compoComunicationService.emmitSideBarEvent(dataPage);
      }
    }
  }

  /**
   * Metodo que se encarga de guardar en SOR y finalizar la tarea
   */
  async submit() {
    await this.saveDataSor(true);
  }

  /**
   * Metodo para finalizar el proceso
   */
  async endProcess() {
    await this.saveDataSor(false);
    await this.redirectUrl('/portal/');
  }

  /**
   * Metodo validar si hay algun proceso de carga de documento
   */
  async validProgressBar() {
    if (!!this.dataSource) {
      return this.dataSource.forEach(doc => {
        doc.upload = doc.upload && !doc.viewFile ? false : doc.upload;
      });
    }
  }

  /**
   * Metodo para Subida de Archivos PDF
   * @param file Archivo seleccionado a cargar
   * @param doc Documento del cliente
   */
  async onFileSelected(file: File, doc: any, newUpload: boolean) {
    if (file.type.match('application/pdf')) {
      doc.upload = true;
      doc.viewFile = false;
      doc.fileName = file.name;
      const optionalName = !!doc.tipo ? (doc.tipo + ".pdf") : "";
      const docRq = uploadDoc(file, this.CONST_DOC_REQ_TYPE, this.dataSolicitud.clienteJuridico.datosGenerales, optionalName);
      const response = await this._documentService.uploadDocument(docRq);
      doc.upload = false;
      doc.viewFile = true;
      if (!response && !newUpload) {
        this.showErrorModal = true;
      } else if (!response && newUpload) {
        doc.viewFile = false;
        this.showErrorModal = true;
      }
    } else {
      this.showErrorModal = true;
    }
  }

  /**
   * Metodo para cargar el objeto con el archivo PDF
   * @param name Nombre del archivo cargado
   */
  async viewPdf(name: string, optionalName?: string) {
    this.modalIsShowed = true;
    this.bodyPdf = "";
    this.bodyPdf = await this.convertPdf(!!optionalName ? (optionalName + ".pdf") : name);
  }

  /**
   * Metodo para conversion a URL de tipo PDF
   * @param name Nombre del archivo cargado
   */
  async convertPdf(name: string): Promise<string> {
    const docRq = getDoc(name, this.CONST_DOC_REQ_TYPE, this.dataSolicitud.clienteJuridico.datosGenerales);
    const res = await this._documentService.getDocument(docRq);
    const pdf: any = new Blob([res], { type: 'application/pdf' });
    const fileURL = URL.createObjectURL(pdf);
    return fileURL;
  }

  /**
   * Metodo para conversion a URL de tipo PDF
   * @param name Nombre del archivo cargado
   */
  async convertScanPdf(pathFile: string, participantType: string): Promise<string> {
    const docRq = getScanDoc(pathFile, participantType, this.dataSolicitud.clienteJuridico.datosGenerales);
    const res = await this._documentService.getDocument(docRq);
    const pdf: any = new Blob([res], { type: 'application/pdf' });
    const fileURL = URL.createObjectURL(pdf);
    return fileURL;
  }

  showLoading(emitValue) {
    this.isLoadingActive = emitValue;
  }

  async viewParticipantDocument(documentData) {
    this.modalIsShowed = true;
    this.bodyPdf = "";
    this.bodyPdf = await this.convertScanPdf(documentData["pathFile"] || '', getAcronimoTipoParticipante(documentData["participantType"] || ''));
  }

  /**
   * Metodo que actualiza una lista de participantes especifico de la solicitud
   * @param participantListData Lista de participantes a actualizar
   */
  updateParticipantList(participantListData) {
    switch (participantListData.participantType) {
      case "Ordenantes":
        this.dataSolicitud.clienteJuridico.datosOrdenantes = participantListData.list;
        break;
      case "Accionistas":
        if (!(!!this.dataSolicitud.clienteJuridico.datosAccionistas)) {
          this.dataSolicitud.clienteJuridico.datosAccionistas = new DatosAccionistas();
        }
        this.dataSolicitud.clienteJuridico.datosAccionistas.accionistas = participantListData.list;
        break;
      case "Representante Legal":
        this.dataSolicitud.clienteJuridico.datosRepresentanteLegal = participantListData.list;
        break;
    }
  }
}
