import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../../material/material.module';
import { SharedModule } from '../../shared/shared.module';
import { ComponentsModule } from 'src/app/components/components.module';
import { Routes, RouterModule } from '@angular/router';
import { DocumentCustomerComponent } from './document-customer.component';
import { AuthGuardService as AuthGuard } from '../../shared/services/auth-guard.service';
import { MatTabsModule } from '@angular/material';

const routes: Routes = [
  { path: '', component: DocumentCustomerComponent, canActivate: [AuthGuard] }
];

@NgModule({
  declarations: [DocumentCustomerComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    SharedModule,
    ComponentsModule,
    MatTabsModule,
    RouterModule.forChild(routes)
  ]
})
export class DocumentCustomerModule { }
