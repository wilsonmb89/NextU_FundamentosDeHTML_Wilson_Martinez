import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateDocsComponent } from './generate-docs.component';

describe('GenerateDocsComponent', () => {
  let component: GenerateDocsComponent;
  let fixture: ComponentFixture<GenerateDocsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenerateDocsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateDocsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
