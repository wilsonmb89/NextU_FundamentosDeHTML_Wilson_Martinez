import { Subscription } from 'rxjs';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { uploadDoc, getDoc } from 'src/app/utils/mapping/UploadDocMapping';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { ComponentCommunicationService } from 'src/app/services/component-communication.service';
import { BpmService } from 'src/app/shared/services/bpm.service';
import { DocumentService } from 'src/app/shared/services/document.service';
import { SolicitudService } from 'src/app/shared/services/solicitud.service';
import { Solicitud } from 'src/app/shared/utils/models/Solicitud/Solicitud';
import { ClaimTaskRequest } from 'src/app/shared/utils/models/api-bpm/ClaimTaskRq';
import { FinishTaskRequest } from 'src/app/shared/utils/models/api-bpm/FinishTaskRq';
import { GetTaskByIdRequest } from 'src/app/shared/utils/models/api-bpm/GetTaskByIdRequest';
import { ProcessInstanceRequest } from 'src/app/shared/utils/models/api-bpm/ProcessInstanceRequest';
import { getDocumentosGenerados } from 'src/app/utils/mapping/SolicitudMapping';
import { DataWrapper } from 'src/app/shared/utils/models/Formatos/DataWrapper';
import { CLASS_NAME } from 'src/app/shared/utils/constants/utils.constant';
import { CreateFilesService } from 'src/app/shared/services/create-files.service';
import { firmasOrdenantes, infoOrdenante } from 'src/app/utils/mapping/FormatosMapping';
import { base64ToBlob, createAndDownloadBlobFile } from 'src/app/shared/utils/functions/transform';
import { newPersonaJuridicaMapping } from 'src/app/utils/mapping/CreateClienteJuridicoMapping';
import { CustomerService } from 'src/app/services/customer.service';

@Component({
  selector: 'app-generate-docs',
  templateUrl: './generate-docs.component.html',
  styleUrls: ['./generate-docs.component.scss']
})
export class GenerateDocsComponent implements OnInit, OnDestroy {

  bodyPdf: any;
  taskId: string;
  instanceId: string;
  redirectLogin: boolean;
  modalIsShowed: boolean;
  showErrorModal: boolean;
  isLoadingActive: boolean;
  saveDataOK: boolean;
  dataSolicitud: DatosSolicitud;
  communicationSuscription: Subscription;
  dataSource: any[];
  displayedColumns: string[] = ['name', 'download', 'upload', 'view'];

  CONST_DOC_GEN_TYPE = "GEN_PJ";
  CONST_GENERACION_FORMULARIOS = "GENERACION_FORMULARIOS";

  constructor(
    private _router: Router,
    private _bpmService: BpmService,
    private _activatedRoute: ActivatedRoute,
    private _documentService: DocumentService,
    private _solicitudService: SolicitudService,
    private _createFilesService: CreateFilesService,
    private _customerService: CustomerService,
    private _compoComunicationService: ComponentCommunicationService
  ) {
    this.communicationSuscription = _compoComunicationService.saveButtonCommunication$.subscribe(
      saveDataButton => { if (!!saveDataButton && saveDataButton) { this.endProcess(); } }
    );
  }

  ngOnInit() {
    this.instanceId = this.bodyPdf = "";
    this.taskId = this._activatedRoute.parent.snapshot.paramMap.get("taskId") || '';
    this.saveDataOK = this.isLoadingActive = this.showErrorModal = this.redirectLogin = this.modalIsShowed = false;
    this.getSolicitudSor();
  }

  ngOnDestroy() {
    if (!!this.communicationSuscription) {
      this.communicationSuscription.unsubscribe();
    }
  }

  /**
   * Metodo para obtener la data previa en SOR
   */
  async getSolicitudSor() {
    this.isLoadingActive = true;
    try {
      await this.getProcessData();
      if (!!this.instanceId) {
        const solicitudRq = new Solicitud;
        solicitudRq.idSolicitud = this.instanceId;
        const solicitudRs = await this._solicitudService.getSolicitud(solicitudRq);
        if (!!solicitudRs && !!solicitudRs.datosSolicitud) {
          this.dataSolicitud = JSON.parse(solicitudRs.datosSolicitud);
          this.dataSource = getDocumentosGenerados(this.dataSolicitud);
          this.validProgressBar();
          this.updateSidebar();
        }
      } else { this.showModalErrorAndExitLogin(); }
    } catch (error) { this.showErrorModal = true; }
    this.isLoadingActive = false;
  }

  /**
   * Metodo para obtener los datos del proceso, en
   * este caso el id de la instancia
   */
  async getProcessData() {
    await this.getTaskInfo();
    if (!(!!this.instanceId)) { this.showModalErrorAndExitLogin(); }
  }

  /**
   * Metodo para obtener los datos de la tarea
   */
  async getTaskInfo() {
    const taskModelRq = new GetTaskByIdRequest();
    taskModelRq.taskId = this.taskId;
    const getTaskInfoRs = await this._bpmService.getTaskInfo(taskModelRq);
    if (!!getTaskInfoRs) {
      this.instanceId = getTaskInfoRs.processInstanceId;
    } else { this.instanceId = null; }
  }

  /**
   * Metodo validar si hay algun proceso de carga de documento
   */
  async validProgressBar() {
    if (!!this.dataSource) {
      return this.dataSource.forEach(doc => {
        doc.upload = doc.upload && !doc.viewFile ? false : doc.upload;
      });
    }
  }

  /**
   * Metodo para enviar objeto a la barra lateral con el fin de que se actualice
   * segun la informacion procesada
   */
  async updateSidebar() {
    if (!!this.instanceId) {
      if (!!this.dataSolicitud) {
        const dataPage = {
          "currentPage": this.CONST_GENERACION_FORMULARIOS,
          "dataSolicitud": this.dataSolicitud
        };
        this._compoComunicationService.emmitSideBarEvent(dataPage);
      }
    }
  }

  /**
   * Metodo para guardar la solicitud en SOR
   * @param value Valor de decision para finalizar tarea
   */
  async saveDataSor(value: boolean) {
    this.isLoadingActive = true;
    await this.getTaskInfo();
    if (!!this.instanceId) {
      const solicitudSorRq = new Solicitud();
      solicitudSorRq.idSolicitud = this.instanceId;
      solicitudSorRq.setDatosSolicitud(this.dataSolicitud);
      const saveResult = await this._solicitudService.saveSolicitud(solicitudSorRq);
      if (!!saveResult) {
        if (value) { await this.savePersonaJuridicaBD(); }
      } else { this.showErrorModal = true; }
    } else { this.showModalErrorAndExitLogin(); }
    this.isLoadingActive = false;
  }

  /**
   * Metodo que invoca el guardado de los datos de la solicitud en la
   * base de datos para mostrar su resultado en pantalla
   */
  async savePersonaJuridicaBD() {
    this.isLoadingActive = true;
    this.saveDataOK = false;
    let savePersonaJuridica = {};
    if (this.dataSolicitud.clienteJuridico.clientFound) {
      savePersonaJuridica = await this.graphQLUpdatePersonaJuridica();
    } else {
      savePersonaJuridica = await this.graphQLSavePersonaJuridica();
    }
    if (savePersonaJuridica) {
      this.saveDataOK = true;
    } else {
      this.showErrorModal = true;
    }
    this.isLoadingActive = false;
  }

  /**
   * Metodo para finalizar la tarea actual
   */
  async finishTask() {
    this.isLoadingActive = true;
    const request = new FinishTaskRequest();
    request.taskId = this.taskId;
    const finishTaskRs = await this._bpmService.finishTask(request);
    if (!!finishTaskRs) {
      const processInstanceRq = new ProcessInstanceRequest();
      processInstanceRq.processInstanceId = this.instanceId;
      const getNextTaskRs = await this._bpmService.getNextTask(processInstanceRq);
      if (!!getNextTaskRs && getNextTaskRs.length > 0) {
        const body = new ClaimTaskRequest();
        body.idTask = getNextTaskRs[0].id;
        const claimTask = await this._bpmService.getClaimTask(body);
        if (!!claimTask) {
          this.isLoadingActive = false;
          this.redirectExternalUrl(claimTask.path);
        } else { this.showErrorModal = true; }
      } else { this.redirectUrl('/portal/'); }
    } else { this.showErrorModal = true; }
    this.isLoadingActive = false;
  }

  /**
   * Metodo para navegar a una url externa
   * @param url Valor que representa la ruta a tomar
   */
  async redirectUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      this._router.navigate(['/externalRedirect', { externalUrl: domain }], {
        skipLocationChange: true,
      });
    }
  }

  /**
   * Metodo para navegar al login como url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectExternalUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      window.open(domain, '_self');
    }
  }

  /**
   * Metodo para cerrar el modal del error
   * @param value Valor proporcionado por el componente de error Modal
   */
  closeErrorModal(value: boolean) {
    this.showErrorModal = value;
    if (this.redirectLogin) { this.redirectUrl('/portal/'); }
  }

  /**
   * Metodo para Subida de Archivos PDF
   * @param file Archivo seleccionado a cargar
   * @param doc Documento del cliente
   */
  async onFileSelected(file: File, doc: any) {
    if (file.type.match('application/pdf')) {
      doc.upload = true;
      doc.viewFile = false;
      doc.fileName = file.name;
      const docRq = uploadDoc(file, this.CONST_DOC_GEN_TYPE, this.dataSolicitud.clienteJuridico.datosGenerales);
      const response = await this._documentService.uploadDocument(docRq);
      doc.upload = false;
      doc.viewFile = true;
      if (!response) {
        doc.viewFile = false;
        this.showErrorModal = true;
      }
    } else { this.showErrorModal = true; }
  }

  /**
   * Metodo para cargar el objeto con el archivo PDF
   * @param name Nombre del archivo cargado
   */
  async viewPdf(name: string) {
    this.modalIsShowed = true;
    this.bodyPdf = "";
    this.bodyPdf = await this.convertPdf(name);
  }

  /**
   * Metodo para conversion a URL de tipo PDF
   * @param name Nombre del archivo cargado
   */
  async convertPdf(name: string): Promise<string> {
    const docRq = getDoc(name, this.CONST_DOC_GEN_TYPE, this.dataSolicitud.clienteJuridico.datosGenerales);
    const res = await this._documentService.getDocument(docRq);
    const pdf: any = new Blob([res], { type: 'application/pdf' });
    const fileURL = URL.createObjectURL(pdf);
    return fileURL;
  }

  /**
   * Metodo para obtener base64 para descargar PDFs
   * @param name Nombre de archivo a descargar
   */
  async downloadPdf(name: string) {
    this.isLoadingActive = true;
    let dataWrapper: DataWrapper;
    if (name === "Vinculación / actualización") {
      dataWrapper = new DataWrapper(CLASS_NAME.VINCULACION_PJ, JSON.stringify(this.dataSolicitud.clienteJuridico));
    } else if (name === "Registro firmas") {
      const firmaordenante = firmasOrdenantes(this.dataSolicitud.clienteJuridico);
      dataWrapper = new DataWrapper(CLASS_NAME.FIRMAS_ORDENANTES, JSON.stringify(firmaordenante));
    } else if (name.includes("Información Ordenantes")) {
      const ordenante = infoOrdenante(this.dataSolicitud.clienteJuridico.datosOrdenantes, name.split(" - ")[1]);
      dataWrapper = new DataWrapper(CLASS_NAME.ORDENANTES, JSON.stringify(ordenante));
    }
    const pdf = await this._createFilesService.createPDF(dataWrapper);
    if (!!pdf && !!pdf.code) {
      const decoding = atob(pdf.code);
      const file = base64ToBlob(decoding, 'application/pdf');
      createAndDownloadBlobFile(file, name);
    } else {
      this.showErrorModal = true;
    }
    this.isLoadingActive = false;
  }

  /**
   * Metodo para cerrar el modal del PDF
   * @param value Valor proporcionado por el componente de PDF Modal
   */
  closePdfModal(value: boolean) { this.modalIsShowed = value; }

  /**
   * Metodo para validar los archivos adjuntos en el formulario
   */
  validateSubmit() {
    if (!!this.dataSource) {
      return this.dataSource.every((doc: any) => {
        return (!doc.upload && doc.viewFile);
      });
    }
  }

  /**
   * Metodo que se encarga de guardar en SOR y finalizar la tarea
   */
  async submit() { await this.saveDataSor(true); }

  /**
   * Metodo para finalizar el proceso
   */
  async endProcess() {
    await this.saveDataSor(false);
    await this.redirectUrl('/portal/');
  }

  /**
   * Metodo para mostrar el error con la opcion de redirigir
   * a la bandeja de tareas
   */
  showModalErrorAndExitLogin() {
    this.showErrorModal = true;
    this.redirectLogin = true;
  }

  /**
   * Metodo para almacenar un cliente juridico en la base de datos del sistema
   */
  async graphQLSavePersonaJuridica() {
    const personaJuridica = newPersonaJuridicaMapping(this.dataSolicitud.clienteJuridico);
    const querySaveCustomer =
      "query crearClienteJuridico($personaJuridica: PersonaJuridicaInput!) {"
        + "crearClienteJuridico(personaJuridica: $personaJuridica) {"
          + "idCliente"
        + "}"
      + "}";
    const bodyGraphQL = {
      "query" : querySaveCustomer,
      "variables" : {
        "personaJuridica" : personaJuridica
      },
      "operationName" : "crearClienteJuridico"
    };
    const saveBDRs = await this._customerService.saveCustomer(bodyGraphQL);
    if (!!saveBDRs) {
      return true;
    }
    return false;
  }
  /**
   * Metodo para actualizar un cliente juridico en la base de datos del sistema
   */
  async graphQLUpdatePersonaJuridica() {
    const personaJuridica = newPersonaJuridicaMapping(this.dataSolicitud.clienteJuridico);
    const querySaveCustomer =
      "query actualizarClienteJuridico($personaJuridica: PersonaJuridicaInput!) {"
        + "actualizarClienteJuridico(personaJuridica: $personaJuridica) {"
          + "idCliente"
        + "}"
      + "}";
    const bodyGraphQL = {
      "query" : querySaveCustomer,
      "variables" : {
        "personaJuridica" : personaJuridica
      },
      "operationName" : "actualizarClienteJuridico"
    };
    const saveBDRs = await this._customerService.saveCustomer(bodyGraphQL);
    if (!!saveBDRs) {
      return true;
    }
    return false;
  }
}
