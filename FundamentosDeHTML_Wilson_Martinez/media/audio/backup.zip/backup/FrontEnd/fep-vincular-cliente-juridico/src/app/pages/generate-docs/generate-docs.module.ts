import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../../material/material.module';
import { SharedModule } from '../../shared/shared.module';
import { ComponentsModule } from 'src/app/components/components.module';
import { Routes, RouterModule } from '@angular/router';
import { GenerateDocsComponent } from './generate-docs.component';
import { AuthGuardService as AuthGuard } from '../../shared/services/auth-guard.service';

const routes: Routes = [
  { path: '', component: GenerateDocsComponent, canActivate: [AuthGuard] }
];

@NgModule({
  declarations: [GenerateDocsComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    SharedModule,
    ComponentsModule,
    RouterModule.forChild(routes)
  ]
})
export class GenerateDocsModule { }
