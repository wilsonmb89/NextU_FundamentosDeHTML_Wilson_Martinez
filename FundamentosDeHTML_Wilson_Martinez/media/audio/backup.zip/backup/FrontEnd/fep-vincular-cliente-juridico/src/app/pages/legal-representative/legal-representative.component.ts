import { Component, OnInit, OnDestroy } from '@angular/core';
import { DatosRepresentanteLegal } from '../../utils/models/api-solicitud/DatosRepresentanteLegal';
import { ComponentCommunicationService } from 'src/app/services/component-communication.service';
import { GetTaskByIdRequest } from 'src/app/shared/utils/models/api-bpm/GetTaskByIdRequest';
import { BpmService } from 'src/app/shared/services/bpm.service';
import { ActivatedRoute, Router } from '@angular/router';
import { SolicitudService } from 'src/app/shared/services/solicitud.service';
import { Solicitud } from 'src/app/shared/utils/models/Solicitud/Solicitud';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { FinishTaskRequest } from 'src/app/shared/utils/models/api-bpm/FinishTaskRq';
import { ProcessInstanceRequest } from 'src/app/shared/utils/models/api-bpm/ProcessInstanceRequest';
import { ClaimTaskRequest } from 'src/app/shared/utils/models/api-bpm/ClaimTaskRq';
import { Subscription } from 'rxjs';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { TipoParticipante } from 'src/app/utils/constants/participants.enum';
import { BureauService } from 'src/app/shared/services/bureau.service';
import { mappingStradataFromParticipant, setDatosRiesgo, updateDatosRiesgoJuridico, setClienteJuridicoSCAP, setClienteJuridicoSIAP } from 'src/app/utils/mapping/BureauMapping';
import { CatalogoRequest } from 'src/app/shared/utils/mapping/CatalogoRequest';
import { capitalizeText } from 'src/app/shared/utils/functions/transform';
import { CatalogoService } from 'src/app/shared/services/catalogo.service';
import { mappingConsultaListas } from 'src/app/utils/mapping/EnrutamientoMapping';
import { CONST_GATEWAY_DEC_VAR_BPM } from 'src/app/utils/constants/utils.constant';

@Component({
  selector: 'app-legal-representative',
  templateUrl: './legal-representative.component.html',
  styleUrls: ['./legal-representative.component.scss'],
})
export class LegalRepresentativeComponent implements OnInit, OnDestroy {

  listLegalRepresentatives: any[];
  showForm: boolean;
  model: DatosRepresentanteLegal;
  idActividad: string;
  idInstancia: string;
  idSelected: number;
  datosSolicitud: DatosSolicitud;
  communicationSuscription: Subscription;
  editData: boolean;
  typeParticipant: number;
  listPais: any[];
  listCIUU: any[];
  decisionGateway: string;

  constructor(
    private _compoComunicationService: ComponentCommunicationService,
    private _bpmService: BpmService,
    private _activatedRoute: ActivatedRoute,
    private _solicitudService: SolicitudService,
    private _bureauService: BureauService,
    private _catalogoService: CatalogoService,
    private _router: Router
  ) {
    this.listLegalRepresentatives = new Array<any>();
    this.model = new DatosRepresentanteLegal();
    this.showForm = false;
    this.editData = false;
    this.idSelected = -1;
    this.setSuscriptions();
    this.typeParticipant = TipoParticipante.representanteLegal;
  }

  ngOnInit() {
    this.idActividad = this._activatedRoute.parent.snapshot.paramMap.get("taskId") || '';
    this.decisionGateway = '';
    this.loadListData();
    this.getTaskInfo();
    this.getSolicitudSor();
  }
  ngOnDestroy() {
    if (!!this.communicationSuscription) {
      this.communicationSuscription.unsubscribe();
    }
  }

  /**
   * Metodo que carga catalogos para la revision del riesgo
   */
  async loadListData() {
    this.listPais = await this.getCatalog("Pais", null);
    this.listCIUU = await this.getCatalog("CIIU", null);
  }

  /**
   * Metodo para obtener un catalogo de acuerdo al nombre
   * @param catalogName nombre del catalogo
   * @param id realiza un filtro del catalogo de acuerdo a una llave
   */
  async getCatalog(catalogName: string, id: string) {
    const catalogoRq = new CatalogoRequest();
    catalogoRq.catalogName = catalogName;
    catalogoRq.idParent = id || '';
    const items = await this._catalogoService.getCatalog(catalogoRq);
    items.items.forEach(element => element.name = capitalizeText(element.name.toLowerCase()));
    return items.items;
  }

  addLegalRepresentative() {
    this.idSelected = this.listLegalRepresentatives.length;
    this.model = new DatosRepresentanteLegal();
    this.showForm = true;
    this.editData = false;
  }
  getLegalRepresentative(data: any, showForm: boolean) {
    if (data.value) {
      if (!this.listLegalRepresentatives[this.idSelected]) {
        this.listLegalRepresentatives.push(data);
      } else {
        this.listLegalRepresentatives[this.idSelected] = data;
      }
      this.updateSidebar();
      this.showForm = showForm;
    }
  }
  onAction(action: any, id: number) {
    if (action.action === 1) {
      this.idSelected = id;
      this.model = action.item;
      this.showForm = true;
      this.editData = true;
    } else {
      this.listLegalRepresentatives.splice(id, 1);
      this.updateSidebar();
    }
  }
  /**
   * Metodo para obtener los datos de la tarea
   */
  async getTaskInfo() {
    const taskModelRq = new GetTaskByIdRequest();
    taskModelRq.taskId = this.idActividad;
    const getTaskInfoRs = await this._bpmService.getTaskInfo(taskModelRq);
    if (!!getTaskInfoRs) {
      this.idInstancia = getTaskInfoRs.processInstanceId;
    } else {
      this.idInstancia = null;
    }
  }
  /**
   * Metodo para controlar el componente de loading desde la pagina de buscar
   * componente
   * @param value si es verdadero muestra el loading no lo muestra en caso
   * contrariuo
   */
  showLoading(value: boolean) {
    this._compoComunicationService.emmitLoading(value);
  }
  validSumbit() {
    const list = this.listLegalRepresentatives.filter(item => item.valid);
    const areTherePrincipal = this.listLegalRepresentatives.filter(item => item.get("isPrincipal").value === "si").length;
    return list.length === this.listLegalRepresentatives.length && this.listLegalRepresentatives.length !== 0 && areTherePrincipal === 1;
  }
  /**
   * Metodo para obtener la data previa en SOR
   */
  async getSolicitudSor() {
    this.showLoading(true);
    try {
      await this.getProcessData();
      if (!!this.idInstancia) {
        const solicitudRq = new Solicitud();
        solicitudRq.idSolicitud = this.idInstancia;
        const solicitudRs = await this._solicitudService.getSolicitud(solicitudRq);
        if (!!solicitudRs && !!solicitudRs.datosSolicitud) {
          this.datosSolicitud = JSON.parse(solicitudRs.datosSolicitud);
          this.updateData();
          this.updateSidebar();
        }
      } else {
        this.showErrorModal(true);
      }
    } catch (error) {
      this.showErrorModal(false);
    }
    this.showLoading(false);
  }
  /**
   * Metodo para enviar objeto a la barra lateral con el fin de que se actualice
   * segun la informacion procesada
   */
  async updateSidebar() {
    this.datosSolicitud.clienteJuridico.datosRepresentanteLegal = this.listLegalRepresentatives.map(item => item.value);
    if (!!this.idInstancia) {
      const dataPage = {
        "currentPage": "CARGAR_INFORMACION_REPRESENTANTE_LEGAL",
        "dataSolicitud": this.datosSolicitud
      };
      this._compoComunicationService.emmitSideBarEvent(dataPage);
    }
  }
  updateData() {
    const list = this.datosSolicitud.clienteJuridico.datosRepresentanteLegal;
    if (list) {
      this.listLegalRepresentatives = list.map(element => {
        const propertiesForm = Object.getOwnPropertyNames(element);
        const object = {};
        propertiesForm.forEach((item) => {
          if (item === "codigoCIIU" && element["ocupacion"] === "OCUP_4 - Otra") {
            object[item] = new FormControl(element[item]);
          } else {
            object[item] = new FormControl(element[item], Validators.required);
          }
        });
        return new FormGroup(object);
      });
    }
  }
  /**
   * Metodo para obtener los datos del proceso, en
   * este caso el id de la instancia
   */
  async getProcessData() {
    await this.getTaskInfo();
    if (!(!!this.idInstancia)) {
      this.showErrorModal(true);
    }
  }
  async showErrorModal(redirectLogin: boolean) {
    const errorData = {
      'showErrorModal': true,
      'redirectLogin': redirectLogin
    };
    await this._compoComunicationService.emmitError(errorData);
  }
  /**
   * Metodo para guardar la solicitud en sor
   * @param finishTask Valor de decision para finalizar tarea
   */
  async saveDataSor(finishTask: boolean) {
    this.showLoading(true);
    if (!!this.idInstancia) {
      const solicitud = new Solicitud();
      solicitud.idSolicitud = this.idInstancia;
      solicitud.setDatosSolicitud(this.datosSolicitud);
      const solicitudSorRs = await this._solicitudService.saveSolicitud(solicitud);
      if (!!solicitudSorRs) {
        if (finishTask) {
          await this.finishTask();
        }
      } else {
        this.showErrorModal(false);
      }
    } else {
      this.showErrorModal(true);
    }
    this.showLoading(false);
  }
  /**
   * Metodo para finalizar la tarea actual
   */
  async finishTask() {
    await this.setDecisionGateway();
    const finishTaskRq = new FinishTaskRequest();
    finishTaskRq.taskId = this.idActividad;
    finishTaskRq.variable = {
      "decisionGateway": {
        "value": this.decisionGateway
      }
    };
    const finishTaskRs = await this._bpmService.finishTask(finishTaskRq);
    if (!!finishTaskRs) {
      const processInstanceRq = new ProcessInstanceRequest();
      processInstanceRq.processInstanceId = this.idInstancia;
      const getNextTaskRs = await this._bpmService.getNextTask(processInstanceRq);
      if (!!getNextTaskRs && getNextTaskRs.length > 0) {
        const body = new ClaimTaskRequest();
        body.idTask = getNextTaskRs[0].id;
        const claimTask = await this._bpmService.getClaimTask(body);
        if (!!claimTask) {
          this.redirectExternalUrl(claimTask.path);
        } else {
          this.showErrorModal(false);
        }
      } else {
        this.redirectUrl('/portal/');
      }
    } else {
      this.showErrorModal(false);
    }
  }
  /**
   * Metodo para navegar a una url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      this._router.navigate(['/externalRedirect', { externalUrl: domain }], {
        skipLocationChange: true,
      });
    }
  }

  /**
   * Metodo para navegar al login como url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectExternalUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      window.open(domain, '_self');
    }
  }
  /**
   * Metodo para conectar al los datos del componente padre a la pantalla
   * de consultar empresa
   */
  setSuscriptions() {
    this.communicationSuscription = this._compoComunicationService.saveButtonCommunication$.subscribe(
      saveDataButton => {
        if (!!saveDataButton) {
          this.saveAndExit();
        }
      }
    );
  }
  async saveAndExit() {
    await this.saveDataSor(false);
    this.redirectUrl('/portal/');
  }
  /**
  * Metodo para guardar en sor finalizando la actividad de consulta de datos
  */
  async submit() {
    const updateRisk = await this.checkBureauParticipants();
    if (updateRisk) {
      await this.saveDataSor(true);
    } else {
      this.showErrorModal(false);
    }
  }
  /** Metodo que obtiene el representante legal principal */
  getPrincipal(data: any, id: number) {
    const listAux = this.listLegalRepresentatives.map((item, index) => {
      item.get("isPrincipal").setValue(index === id ? "si" : "no");
      return item;
    });
    this.listLegalRepresentatives = [];
    setTimeout(() => {
      this.listLegalRepresentatives = listAux;
      this.updateSidebar();
    }, 1);
  }

  /**
   * Metodo para establecer el riesgo de los participantes legales
   */
  async checkBureauParticipants() {
    this.showLoading(true);
    try {
      const bureauRq = mappingStradataFromParticipant(this.datosSolicitud.clienteJuridico.datosRepresentanteLegal);
      const bureauRs = await this._bureauService.getStradataList(bureauRq);
      if (!!bureauRs) {
        this.datosSolicitud.clienteJuridico.datosRepresentanteLegal = this.setParticipantsRisk(bureauRs, this.datosSolicitud.clienteJuridico.datosRepresentanteLegal);
        this.updateJuridicoRisk();
        const riskSummary = bureauRs["summary"];
        riskSummary["scapRisk"] = this.datosSolicitud.clienteJuridico.datosRiesgo.scapRisk;
        riskSummary["siapRisk"] = this.datosSolicitud.clienteJuridico.datosRiesgo.siapRisk;
        this.datosSolicitud.clienteJuridico.datosRiesgo = updateDatosRiesgoJuridico(riskSummary, this.datosSolicitud.clienteJuridico.datosRiesgo);
        await this.checkRoutingRule(riskSummary);
      } else {
        this.showLoading(false);
        return false;
      }
    } catch (error) {
      this.showLoading(false);
      return false;
    }
    this.showLoading(false);
    return true;
  }

  /**
   * Metodo que almacena en el BO los riesgos de cada participante de la solicitud
   * @param bureauRs la respuesta obtenida de la consulta de riesgo de todos los participantes
   */
  setParticipantsRisk(bureauRs: any, participantList: Array<any>) {
    if (!!bureauRs && !!participantList && participantList.length > 0) {
      participantList.forEach(
        (par) => {
          const participantKey = par.numeroDocumento.replace(/\./g, '');
          if (!!bureauRs[participantKey]) {
            par.datosRiesgo = setDatosRiesgo(bureauRs[participantKey]);
            par.datosRiesgo.scapRisk = this.setParticipantSCAP(par);
            par.datosRiesgo.siapRisk = this.setRiskSIAP(par);
          }
        }
      );
    }
    return participantList;
  }

  /**
   * Metodo para establecer el riesgo SCAP de un participante
   * @param participante participante que debe contener el paises de nacimiento y el pais de residencia
   */
  setParticipantSCAP(participante: any) {
    if (!!participante) {
      const riesgoPaisNacimiento = !!participante.paisNacimiento ? this.getRiskPais(participante.paisNacimiento.split('-')[0].trim()) : "bajo";
      const riesgoPaisResidencia = !!participante.paisResidencia ? this.getRiskPais(participante.paisResidencia.split('-')[0].trim()) : "bajo";
      return ((riesgoPaisNacimiento === 'prohibido' || riesgoPaisResidencia === 'prohibido') ? 'prohibido' : ((riesgoPaisNacimiento === 'sensible' || riesgoPaisResidencia === 'sensible') ? 'sensible' : 'bajo'));
    }
    return 'bajo';
  }

  /**
   * Metodo que analiza el riesgo de un pais
   * @param codPais codigo del pais en la vista de base de datos
   */
  getRiskPais(codPais: string) {
    if (!!codPais) {
      const pais = this.listPais.find((obj) => obj.id === codPais);
      if (!!pais) {
        const riesgo = pais.riesgo.toLowerCase() || '';
        return (riesgo.indexOf('prohibido') !== -1 ? 'prohibido' : (riesgo.indexOf('sensible') !== -1 ? 'sensible' : 'bajo'));
      }
    }
    return 'bajo';
  }

  /**
   * Metodo que analiza el riesgo de una actividad comercial
   * @param codCUII codigo de la actividad comercial en la vista de base de datos
   */
  setRiskSIAP(participant: any) {
    const codCUII = !!participant.codigoCIIU && participant.codigoCIIU.indexOf("-") !== -1 ? participant.codigoCIIU.split('-')[0].trim() : '';
    if (!!codCUII) {
      const actividadEconomica = this.listCIUU.find((obj) => obj.id === codCUII);
      if (!!actividadEconomica) {
        const riesgo = actividadEconomica.strDescripcion.toLowerCase() || '';
        return (riesgo.indexOf('alto') !== -1 ? 'alto' : (riesgo.indexOf('sensible') !== -1 ? 'sensible' : 'bajo'));
      }
    }
    return 'bajo';
  }

  /**
   * Metodo para establecer el riesgo del cliente juridico
   */
  updateJuridicoRisk() {
    this.datosSolicitud = setClienteJuridicoSCAP(this.datosSolicitud);
    this.datosSolicitud = setClienteJuridicoSIAP(this.datosSolicitud);
  }

  /**
   * Metodo para consultar la regla de enrutamiento segun el resumen del riesgo de los
   * participantes de la solicitud
   * @param riskSummary contiene el resumen del riesgo de todos los participantes de la solicitud
   */
  async checkRoutingRule(riskSummary) {
    const datosRiesgo = setDatosRiesgo(riskSummary);
    const enrutamientoRq = mappingConsultaListas(datosRiesgo);
    const enrutamientoRs = await this._bpmService.callBPMRule(enrutamientoRq);
    if (!!enrutamientoRs && enrutamientoRs.length > 0) {
      const resultEnrutamiento = enrutamientoRs[0];
      this.decisionGateway = resultEnrutamiento.respuestaEnrutamiento.value;
    }
  }

  /**
   * Metodo para validar que no se repita el valor en el decisionGateway
   */
  async setDecisionGateway() {
    const getVarRq = { "instanceId" : this.idInstancia, "varName" : CONST_GATEWAY_DEC_VAR_BPM };
    const getVarRs = await this._bpmService.getProcessVariable(getVarRq);
    if (!!getVarRs && !!getVarRs.value && getVarRs.value.indexOf(this.decisionGateway) === -1) {
      this.decisionGateway = getVarRs.value + '-' + this.decisionGateway;
    } else {
      this.decisionGateway = getVarRs.value;
    }
  }
}
