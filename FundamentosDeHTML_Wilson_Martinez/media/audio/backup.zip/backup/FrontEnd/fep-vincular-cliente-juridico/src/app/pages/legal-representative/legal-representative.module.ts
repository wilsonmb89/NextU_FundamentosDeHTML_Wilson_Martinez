import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { LegalRepresentativeComponent } from './legal-representative.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { MatFormFieldModule, MatInputModule, MatIconModule, MatDatepickerModule, MatAutocompleteModule, MatSelectModule, MatTabsModule } from '@angular/material';
import { ComponentsModule } from 'src/app/components/components.module';


const routes: Routes = [
  { path: '', component: LegalRepresentativeComponent },
];

@NgModule({
  declarations: [
    LegalRepresentativeComponent,
  ],
  imports: [
    ComponentsModule,
    CommonModule,
    RouterModule.forChild(routes),
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    MatFormFieldModule,
    MatInputModule,
    MatIconModule,
    MatDatepickerModule,
    MatAutocompleteModule,
    MatSelectModule,
    MatTabsModule
  ]
})
export class LegalRepresentativeModule { }
