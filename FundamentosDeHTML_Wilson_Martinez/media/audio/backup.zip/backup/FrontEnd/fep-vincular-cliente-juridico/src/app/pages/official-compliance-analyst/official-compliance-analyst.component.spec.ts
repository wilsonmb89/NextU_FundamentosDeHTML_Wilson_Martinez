import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfficialComplianceAnalystComponent } from './official-compliance-analyst.component';

describe('OfficialComplianceAnalystComponent', () => {
  let component: OfficialComplianceAnalystComponent;
  let fixture: ComponentFixture<OfficialComplianceAnalystComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfficialComplianceAnalystComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfficialComplianceAnalystComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
