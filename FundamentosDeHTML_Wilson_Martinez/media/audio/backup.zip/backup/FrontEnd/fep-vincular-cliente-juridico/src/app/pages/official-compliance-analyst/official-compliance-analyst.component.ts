import { Component, OnInit, OnDestroy } from '@angular/core';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { Subscription } from 'rxjs';
import { ComponentCommunicationService } from 'src/app/services/component-communication.service';
import { BpmService } from 'src/app/shared/services/bpm.service';
import { ActivatedRoute, Router } from '@angular/router';
import { SolicitudService } from 'src/app/shared/services/solicitud.service';
import { GetTaskByIdRequest } from 'src/app/shared/utils/models/api-bpm/GetTaskByIdRequest';
import { Solicitud } from 'src/app/shared/utils/models/Solicitud/Solicitud';
import { FinishTaskRequest } from 'src/app/shared/utils/models/api-bpm/FinishTaskRq';
import { ProcessInstanceRequest } from 'src/app/shared/utils/models/api-bpm/ProcessInstanceRequest';
import { ClaimTaskRequest } from 'src/app/shared/utils/models/api-bpm/ClaimTaskRq';
import { capitalizeText } from 'src/app/shared/utils/functions/transform';
import { Participante } from 'src/app/utils/models/api-solicitud/Participante';
import { CONST_GATEWAY_DEC_VAR_BPM } from 'src/app/utils/constants/utils.constant';
import { DatosAML } from 'src/app/utils/models/api-solicitud/DatosAML';

@Component({
  selector: 'app-official-compliance-analyst',
  templateUrl: './official-compliance-analyst.component.html',
  styleUrls: ['./official-compliance-analyst.component.scss']
})
export class OfficialComplianceAnalystComponent implements OnInit, OnDestroy {
  idActividad: string;
  idInstancia: string;
  datosSolicitud: DatosSolicitud;
  communicationSuscription: Subscription;
  showViewDocsModal: boolean;
  modalPdfShowed: boolean;
  viewDocs: any;
  bodyPdf: any;
  listTabCheck: any[];
  countParticipants: number;
  countCheckODC: number;
  nivelRiesgo: any;
  datosAml: any;
  datosCumplimiento: any;
  editParticipant: boolean;
  participanteEdit: Participante;
  CONST_AML_TYPE: string;
  decisionGateway: string;

  constructor(private _compoComunicationService: ComponentCommunicationService,
    private _bpmService: BpmService,
    private _activatedRoute: ActivatedRoute,
    private _solicitudService: SolicitudService,
    private _router: Router) {
    this.setSuscriptions();
    this.listTabCheck = new Array<any>();
    this.countParticipants = 0;
    this.countCheckODC = 0;
    this.nivelRiesgo = new Object();
    this.datosAml = {
      decision: "",
      motivo: ""
    };
    this.datosCumplimiento = {
      decision: "",
      motivo: ""
    };
    this.editParticipant = false;
    this.participanteEdit = new Participante();
    this.CONST_AML_TYPE = "CUMPLIMIENTO";
    this.decisionGateway = "";
  }

  ngOnInit() {
    this.showViewDocsModal = this.modalPdfShowed = false;
    this.idActividad = this._activatedRoute.parent.snapshot.paramMap.get("taskId") || '';
    this.getTaskInfo();
    this.getSolicitudSor();
  }
  ngOnDestroy() {
    if (!!this.communicationSuscription) {
      this.communicationSuscription.unsubscribe();
    }
  }
  /**
       * Metodo para obtener los datos de la tarea
       */
  async getTaskInfo() {
    const taskModelRq = new GetTaskByIdRequest();
    taskModelRq.taskId = this.idActividad;
    const getTaskInfoRs = await this._bpmService.getTaskInfo(taskModelRq);
    if (!!getTaskInfoRs) {
      this.idInstancia = getTaskInfoRs.processInstanceId;
    } else {
      this.idInstancia = null;
    }
  }
  /**
   * Metodo para obtener la data previa en SOR
   */
  async getSolicitudSor() {
    this.showLoading(true);
    try {
      await this.getProcessData();
      if (!!this.idInstancia) {
        const solicitudRq = new Solicitud();
        solicitudRq.idSolicitud = this.idInstancia;
        const solicitudRs = await this._solicitudService.getSolicitud(solicitudRq);
        if (!!solicitudRs && !!solicitudRs.datosSolicitud) {
          this.datosSolicitud = JSON.parse(solicitudRs.datosSolicitud);
          this.updateSidebar();
          this.updateData();
          this.setNivelRiesgo();
          this.getListTabs(this.datosSolicitud.clienteJuridico.datosDocumento.documentosSolicitados);
        }
      } else {
        this.showErrorModal(true);
      }
    } catch (error) {
      this.showErrorModal(false);
    }
    this.showLoading(false);
  }
  async showErrorModal(redirectLogin: boolean) {
    const errorData = {
      'showErrorModal': true,
      'redirectLogin': redirectLogin
    };
    await this._compoComunicationService.emmitError(errorData);
  }
  /**
   * Metodo para obtener los datos del proceso, en
   * este caso el id de la instancia
   */
  async getProcessData() {
    await this.getTaskInfo();
    if (!(!!this.idInstancia)) {
      this.showErrorModal(true);
    }
  }
  /** Metodo para actulizar la informacion del sidebar */
  async updateSidebar() {
    if (!!this.idInstancia) {
      const dataPage = {
        "currentPage": "CARGAR_OFICIAL_CUMPLIMIENTO",
        "dataSolicitud": this.datosSolicitud
      };
      this._compoComunicationService.emmitSideBarEvent(dataPage);
    }
  }
  /**
   * Metodo para controlar el componente de loading desde la pagina de buscar
   * componente
   * @param value si es verdadero muestra el loading no lo muestra en caso
   * contrariuo
   */
  showLoading(value: boolean) {
    this._compoComunicationService.emmitLoading(value);
  }
  /**
   * Metodo para guardar la solicitud en sor
   * @param finishTask Valor de decision para finalizar tarea
   */
  async saveDataSor(finishTask: boolean) {
    this.showLoading(true);
    if (!!this.idInstancia) {
      const solicitud = new Solicitud();
      solicitud.idSolicitud = this.idInstancia;
      this.datosSolicitud.clienteJuridico.datosCumplimiento = this.datosCumplimiento;
      solicitud.setDatosSolicitud(this.datosSolicitud);
      const solicitudSorRs = await this._solicitudService.saveSolicitud(solicitud);
      if (!!solicitudSorRs) {
        if (finishTask) {
          await this.finishTask();
        }
      } else {
        this.showErrorModal(false);
      }
    } else {
      this.showErrorModal(true);
    }
    this.showLoading(false);
  }
  /**
   * Metodo para finalizar la tarea actual
   */
  async finishTask() {
    const getVarRq = { "instanceId" : this.idInstancia, "varName" : CONST_GATEWAY_DEC_VAR_BPM };
    const getVarRs = await this._bpmService.getProcessVariable(getVarRq);
    if (!!getVarRs && !!getVarRs.value) {
      this.decisionGateway = getVarRs.value;
    }
    const decision = (this.datosCumplimiento.decision === 'positivo' ? "aprobadoCumplimiento" : "rechazadoCumplimiento");
    const finishTaskRq = new FinishTaskRequest();
    finishTaskRq.taskId = this.idActividad;
    finishTaskRq.variable = {
      "decisionGateway": {
        "value": !!this.decisionGateway ? this.decisionGateway.concat('-').concat(decision) : decision
      }
    };
    const finishTaskRs = await this._bpmService.finishTask(finishTaskRq);
    if (!!finishTaskRs) {
      const processInstanceRq = new ProcessInstanceRequest();
      processInstanceRq.processInstanceId = this.idInstancia;
      const getNextTaskRs = await this._bpmService.getNextTask(processInstanceRq);
      if (!!getNextTaskRs && getNextTaskRs.length > 0) {
        const body = new ClaimTaskRequest();
        body.idTask = getNextTaskRs[0].id;
        const claimTask = await this._bpmService.getClaimTask(body);
        if (!!claimTask) {
          this.redirectExternalUrl(claimTask.path);
        } else {
          this.showErrorModal(false);
        }
      } else {
        this.redirectUrl('/portal/');
      }
    } else {
      this.showErrorModal(false);
    }
  }
  /**
   * Metodo para navegar a una url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      this._router.navigate(['/externalRedirect', { externalUrl: domain }], {
        skipLocationChange: true,
      });
    }
  }
  /**
   * Metodo para navegar al login como url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectExternalUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      window.open(domain, '_self');
    }
  }
  /**
   * Metodo para conectar al los datos del componente padre a la pantalla
   * de consultar empresa
   */
  setSuscriptions() {
    this.communicationSuscription = this._compoComunicationService.saveButtonCommunication$.subscribe(
      saveDataButton => {
        if (!!saveDataButton) {
          this.saveAndExit();
        }
      }
    );
  }
  async saveAndExit() {
    await this.saveDataSor(false);
    this.redirectUrl('/portal/');
  }

  /**
   * Metodo para abrir el modal de vista de Documentos
   */
  openDocs(listDocs: any) {
    this.showViewDocsModal = true;
    this.viewDocs = Object.assign(listDocs, this.datosSolicitud.clienteJuridico.datosGenerales);
  }

  /**
   * Metodo para abrir el modal de vista de PDF
   * @param value Array de bits para lectura del PDF
   */
  openPDF(value: string) {
    this.bodyPdf = "";
    this.bodyPdf = value;
    this.modalPdfShowed = true;
  }

  /**
   * Metodo para cerrar el modal de vista de Documentos
   * @param value Booleano para cerrar el modal
   */
  closeViewDocsModal(value: boolean) {
    this.showViewDocsModal = value;
  }

  /**
   * Metodo para cerrar el modal del PDF
   * @param value Booleano para cerrar el modal
   */
  closePdfModal(value: boolean) {
    this.modalPdfShowed = value;
  }
  /** Metodo que trae los datos y nombres de los tabs (participantes)
   * @param data lista de documentos de la regla de negocio
  */
  getListTabs(data: any) {
    const listNameTabs = Object.getOwnPropertyNames(data).filter(item => item !== "empresa");
    const listNames = Object.getOwnPropertyNames(this.datosSolicitud.clienteJuridico);
    const cliente = this.datosSolicitud.clienteJuridico;
    const listParticipants = listNameTabs.map(tab => {
      const list = listNames.filter(name => name.toLocaleLowerCase().includes(tab.toLocaleLowerCase()))[0];
      const filterList = tab === "accionistas" ? cliente[list].accionistas : cliente[list];
      this.countParticipants += filterList.length;
      return { id: tab, name: this.getNameForTab(tab), list: filterList };
    });
    listParticipants.push({ id: "terceros", name: "Terceros", list: cliente.datosTerceros });
    this.countParticipants += cliente.datosTerceros.length;
    this.listTabCheck = [
      { name: "Revisión ODC", list: []},
      { name: "Administradores", list: []}
    ];
    listParticipants.forEach(participant => {
      participant.list.forEach(item => {
        if (item.datosRiesgo.isPep === "si") {
          item.datosCumplimiento = new DatosAML();
          this.listTabCheck[0].list.push({name: participant.name, data: item});
        } else {
          item.datosCumplimiento = new DatosAML();
          item.datosCumplimiento.revisionOk = true;
          this.listTabCheck[1].list.push({name: participant.name, data: item});
        }
      });
    });
    this.countCheckODC = this.listTabCheck[0].list
      .filter(element => element.data.datosCumplimiento.revisionOk).length;
  }
  /** Metodo que trae los nombres de los tabs
   * @param name nombre de la lista
  */
  getNameForTab(name: string) {
    return capitalizeText(name.replace(/[A-Z]/g, " $&").trim());
  }
  /**
   * Metodo para establecer en una variable del componente el riesgo del cliente
   * con el fin de un uso mas facil durante el comportamiento de la pantalla
   */
  setNivelRiesgo() {
    this.nivelRiesgo = {};
    if (!!this.datosSolicitud
      && !!this.datosSolicitud.clienteJuridico
      && !!this.datosSolicitud.clienteJuridico.datosRiesgo) {
      this.nivelRiesgo.isPep = (!!this.datosSolicitud.clienteJuridico.datosRiesgo.isPep && this.datosSolicitud.clienteJuridico.datosRiesgo.isPep === 'si');
      this.nivelRiesgo.isMediosPublicos = this.datosSolicitud.clienteJuridico.datosRiesgo.isMedia || false;
      this.nivelRiesgo.isSiap = !!this.datosSolicitud.clienteJuridico.datosRiesgo.siapRisk && this.datosSolicitud.clienteJuridico.datosRiesgo.siapRisk !== 'bajo';
      this.nivelRiesgo.isScap = !!this.datosSolicitud.clienteJuridico.datosRiesgo.scapRisk && this.datosSolicitud.clienteJuridico.datosRiesgo.scapRisk !== 'bajo';
    }
  }
  /**
   * Metodo para mapear el cambio del riesgo del cliente
   */
  changeRisk(number: number) {
    switch (number) {
      case 1:
        this.datosSolicitud.clienteJuridico.datosRiesgo.isPep = this.nivelRiesgo.isPep ? 'si' : 'no';
        break;
      case 2:
        this.datosSolicitud.clienteJuridico.datosRiesgo.siapRisk = this.nivelRiesgo.isSiap ? 'alto' : 'bajo';
        break;
      case 3:
        this.datosSolicitud.clienteJuridico.datosRiesgo.scapRisk = this.nivelRiesgo.isScap ? 'sensible' : 'bajo';
        break;
      default:
        this.datosSolicitud.clienteJuridico.datosRiesgo.isMedia = this.nivelRiesgo.isMediosPublicos;
        break;
    }
  }
  /** Metodo que actualiza la informacion proveniente del SOR */
  updateData() {
    if (this.datosSolicitud.clienteJuridico.datosAml) {
      this.datosAml = this.datosSolicitud.clienteJuridico.datosAml;
    }
    if (this.datosSolicitud.clienteJuridico.datosCumplimiento) {
      this.datosCumplimiento = this.datosSolicitud.clienteJuridico.datosCumplimiento;
    }
  }
  /**
   * Metodo para mapear un participante al componente que realiza la edicion
   * @param participante participante a editar a traves del componente
   */
  startEditParticipant(participante: Participante) {
    if (!!participante) {
      this.participanteEdit = participante;
      this.editParticipant = true;
    }
  }

  /**
   * Metodo para cerrar el componente de la edicion del participante
   * en la pantalla
   * @param closeEditParticipant booleano que indica el cierre del componente de la edicion
   * del participante
   */
  goBack(closeEditParticipant: boolean) {
    this.editParticipant = closeEditParticipant;
    this.participanteEdit = new Participante();
  }

  /**
   * Metodo que se encarga de procesar los participantes actualizados
   * @param participante participante actualizado
   */
  saveDataParticipant(participante: Participante) {
    this.editParticipant = false;
    const list = this.listTabCheck[0].list.filter(item => !item.data.datosCumplimiento);
    this.countCheckODC = list.length;
  }
  /** Metodo para la validacion del boton de finalizar */
  validatedSubmit() {
    const validateRisk = (this.nivelRiesgo.isPep || this.nivelRiesgo.isMediosPublicos ||
        this.nivelRiesgo.isSiap || this.nivelRiesgo.isScap);
    return this.datosCumplimiento.decision && this.datosCumplimiento.motivo && this.datosCumplimiento.motivo.length > 50 && validateRisk;
  }
  /** Metodo para el envio de la informacion */
  async submit() {
    await this.saveDataSor(true);
  }
}
