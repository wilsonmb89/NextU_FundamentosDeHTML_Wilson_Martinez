import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderOfficerComponent } from './order-officer.component';

describe('OrderOfficerComponent', () => {
  let component: OrderOfficerComponent;
  let fixture: ComponentFixture<OrderOfficerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderOfficerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderOfficerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
