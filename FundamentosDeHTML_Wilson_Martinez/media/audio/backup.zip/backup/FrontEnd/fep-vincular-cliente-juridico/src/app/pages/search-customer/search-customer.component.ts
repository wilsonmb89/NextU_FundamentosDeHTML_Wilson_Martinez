import { Component, OnInit, OnDestroy } from '@angular/core';
import { ComponentCommunicationService } from 'src/app/services/component-communication.service';
import { Subscription } from 'rxjs';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { SolicitudService } from 'src/app/shared/services/solicitud.service';
import { BpmService } from 'src/app/shared/services/bpm.service';
import { ActivatedRoute, Router } from '@angular/router';
import { GetTaskByIdRequest } from 'src/app/shared/utils/models/api-bpm/GetTaskByIdRequest';
import { Solicitud } from 'src/app/shared/utils/models/Solicitud/Solicitud';
import { FinishTaskRequest } from 'src/app/shared/utils/models/api-bpm/FinishTaskRq';
import { ProcessInstanceRequest } from 'src/app/shared/utils/models/api-bpm/ProcessInstanceRequest';
import { ClaimTaskRequest } from 'src/app/shared/utils/models/api-bpm/ClaimTaskRq';
import { createSolicitudMapping } from 'src/app/utils/mapping/SolicitudMapping';
import { CatalogoService } from 'src/app/shared/services/catalogo.service';
import { CatalogoRequest } from 'src/app/shared/utils/mapping/CatalogoRequest';
import { CATALOGS_SEARCH_CUSTOMER } from 'src/app/utils/constants/utils.constant';
import { getVerificationCode } from 'src/app/utils/functions/verificationCode';
import { CustomerService } from 'src/app/services/customer.service';
import { PersonaJuridica } from 'src/app/utils/models/api-cliente/PersonaJuridica';
import { DatosContacto } from 'src/app/utils/models/api-solicitud/DatosContacto';
import { ClienteJuridico } from 'src/app/utils/models/api-solicitud/ClienteJuridico';
import { DatosAdicionales } from 'src/app/utils/models/api-solicitud/DatosAdiccionales';
import { setSORData } from 'src/app/utils/mapping/SorMapping';

@Component({
  selector: 'app-search-customer',
  templateUrl: './search-customer.component.html',
  styleUrls: ['./search-customer.component.scss']
})
export class SearchCustomerComponent implements OnInit, OnDestroy {

  CONST_CONSULTAR_CLIENTE_JURIDICO = "CONSULTAR_CLIENTE_JURIDICO";

  datosSolicitud: DatosSolicitud;
  communicationSuscription: Subscription;
  searchCompanyForm: FormGroup;
  idActividad: string;
  idInstancia: string;
  redirectLogin: boolean;
  showNITField: boolean;
  tiposDocumento: any;
  isCustomerFound: boolean;
  isCustomerAlert: boolean;
  wantUpdate: boolean;
  dataClient: any;

  constructor(
    private _customerService: CustomerService,
    private _catalogoService: CatalogoService,
    private _activatedRoute: ActivatedRoute,
    private _router: Router,
    private _solicitudService: SolicitudService,
    private _bpmService: BpmService,
    private _compoComunicationService: ComponentCommunicationService
  ) {
    this.setSuscriptions();
  }

  ngOnInit() {
    this.isCustomerAlert = this.isCustomerFound = this.showNITField = this.redirectLogin = false;
    this.idActividad = this._activatedRoute.parent.snapshot.paramMap.get("taskId") || '';
    this.getCatalogs();
    this.initForm();
    this.getSolicitudSor();
  }

  ngOnDestroy() {
    if (!!this.communicationSuscription) {
      this.communicationSuscription.unsubscribe();
    }
  }
  /** Metodo que forma la estructura para obtener los datos de contacto, datos pep y el id para
     * la actualizacion de datos
     */
  getLegalPersonPart1() {
    const datosContacto = new PersonaJuridica().getObjectPart1();
    const datosContactoCopy = JSON.stringify(datosContacto);
    return datosContactoCopy.replace(/"/g, "").replace(/:null/g, "").replace(/:/g, "");
  }
  /** Metodo que forma la estructura para obtener los datos de contacto, datos pep y el id para
     * la actualizacion de datos
     */
  getLegalPersonPart2() {
    const datosContacto = new PersonaJuridica().getObjectPart2();
    const datosContactoCopy = JSON.stringify(datosContacto);
    return datosContactoCopy.replace(/"/g, "").replace(/:null/g, "").replace(/:/g, "");
  }
  /** Metodo que forma la estructura para obtener los datos de contacto, datos pep y el id para
   * la actualizacion de datos
   */
  getLegalPersonPart3() {
    const datosContacto = new PersonaJuridica().getObjectPart3();
    const datosContactoCopy = JSON.stringify(datosContacto);
    return datosContactoCopy.replace(/"/g, "").replace(/:null/g, "").replace(/:/g, "");
  }
  /**
   * Metodo para obtener la data previa en SOR
   */
  async getSolicitudSor() {
    this.showLoading(true);
    try {
      await this.getProcessData();
      if (!!this.idInstancia) {
        const solicitudRq = new Solicitud();
        solicitudRq.idSolicitud = this.idInstancia;
        const solicitudRs = await this._solicitudService.getSolicitud(solicitudRq);
        if (!!solicitudRs && !!solicitudRs.datosSolicitud) {
          this.datosSolicitud = JSON.parse(solicitudRs.datosSolicitud);
          this.setPageData();
          this.updateSidebar();
        }
      } else {
        this.showErrorModal(true);
      }
    } catch (error) {
      this.showErrorModal(false);
    }
    this.showLoading(false);
  }

  /**
   * Metodo para obtener los datos del proceso, en
   * este caso el id de la instancia
   */
  async getProcessData() {
    await this.getTaskInfo();
    if (!(!!this.idInstancia)) {
      this.showErrorModal(true);
    }
  }

  /**
   * Metodo para obtener los datos de la tarea
   */
  async getTaskInfo() {
    const taskModelRq = new GetTaskByIdRequest();
    taskModelRq.taskId = this.idActividad;
    const getTaskInfoRs = await this._bpmService.getTaskInfo(taskModelRq);
    if (!!getTaskInfoRs) {
      this.idInstancia = getTaskInfoRs.processInstanceId;
    } else {
      this.idInstancia = null;
    }
  }

  /**
   * Metodo para iniciar la pagina con la informacion obtenida en sor
   */
  setPageData() {
    if (!!this.datosSolicitud
      && !!this.datosSolicitud.clienteJuridico
      && !!this.datosSolicitud.clienteJuridico.datosGenerales) {
      const datosGenerales = this.datosSolicitud.clienteJuridico.datosGenerales;
      this.searchCompanyForm.get("tipoDocumento").setValue(datosGenerales.tipoDocumento || "");
      this.searchCompanyForm.get("numDocumento").setValue(datosGenerales.numeroDocumento || "");
    }
  }

  /**
   * Metodo para inicializar el formulario
   */
  initForm() {
    this.searchCompanyForm = new FormGroup({
      tipoDocumento: new FormControl('', [Validators.required]),
      numDocumento: new FormControl('', [Validators.required])
    });
  }

  /**
   * Metodo para controlar el componente de loading desde la pagina de buscar
   * componente
   * @param value si es verdadero muestra el loading no lo muestra en caso
   * contrariuo
   */
  async showLoading(value: boolean) {
    await this._compoComunicationService.emmitLoading(value);
  }

  /**
   * Metodo para mostrar el modal de error en la pantalla
   * @param redirectLogin valida se debe redirigir a la bandeja de tareas
   */
  async showErrorModal(redirectLogin: boolean) {
    const errorData = {
      'showErrorModal': true,
      'redirectLogin': redirectLogin
    };
    await this._compoComunicationService.emmitError(errorData);
  }

  /**
   * Metodo para conectar al los datos del componente padre a la pantalla
   * de consultar empresa
   */
  setSuscriptions() {
    this.communicationSuscription = this._compoComunicationService.saveButtonCommunication$.subscribe(
      saveDataButton => {
        if (!!saveDataButton) {
          this.saveAndExit();
        }
      }
    );
  }

  /**
   * Metodo para guardar la solicitud en sor
   * @param finishTask Valor de decision para finalizar tarea
   */
  async saveDataSor(finishTask: boolean) {
    this.showLoading(true);
    await this.getTaskInfo();
    if (!!this.idInstancia) {
      const solicitudSorRq = createSolicitudMapping(this.idInstancia, this.searchCompanyForm, this.isCustomerFound, this.dataClient);
      const solicitudSorRs = await this._solicitudService.saveSolicitud(solicitudSorRq);
      if (!!solicitudSorRs) {
        if (finishTask) {
          await this.finishTask();
        }
      } else {
        this.showErrorModal(false);
      }
    } else {
      this.showErrorModal(true);
    }
    this.showLoading(false);
  }

  async saveAndExit() {
    await this.saveDataSor(false);
    this.redirectUrl('/portal/');
  }

  /**
   * Metodo para finalizar la tarea actual
   */
  async finishTask() {
    this.showLoading(true);
    const finishTaskRq = new FinishTaskRequest();
    finishTaskRq.taskId = this.idActividad;
    finishTaskRq.variable = {
      "subject": {
        "value": ((this.searchCompanyForm.get('tipoDocumento').value).split('-')[1]
          + ' ' + this.searchCompanyForm.get('numDocumento').value)
      }
    };
    const finishTaskRs = await this._bpmService.finishTask(finishTaskRq);
    if (!!finishTaskRs) {
      const processInstanceRq = new ProcessInstanceRequest();
      processInstanceRq.processInstanceId = this.idInstancia;
      const getNextTaskRs = await this._bpmService.getNextTask(processInstanceRq);
      if (!!getNextTaskRs && getNextTaskRs.length > 0) {
        const body = new ClaimTaskRequest();
        body.idTask = getNextTaskRs[0].id;
        const claimTask = await this._bpmService.getClaimTask(body);
        if (!!claimTask) {
          this.redirectExternalUrl(claimTask.path);
        } else {
          this.showErrorModal(false);
        }
      } else {
        this.redirectUrl('/portal/');
      }
    } else {
      this.showErrorModal(false);
    }
    this.showLoading(false);
  }

  /**
   * Metodo para navegar a una url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      this._router.navigate(['/externalRedirect', { externalUrl: domain }], {
        skipLocationChange: true,
      });
    }
  }

  /**
   * Metodo para navegar al login como url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectExternalUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      window.open(domain, '_self');
    }
  }

  /**
   * Metodo para obtener los catalogos de la pantalla
   * de consulta de cliente
   */
  async getCatalogs() {
    const catalogoRq = new CatalogoRequest();
    catalogoRq.catalogName = CATALOGS_SEARCH_CUSTOMER;
    const catalogoRs = await <any>this._catalogoService.getCatalog(catalogoRq);
    if (!!catalogoRs && !!catalogoRs.catalogName && catalogoRs.catalogName === "TipoDocumento") {
      this.tiposDocumento = catalogoRs.items.filter(
        (obj) => {
          return obj.strDescripcion === "Sociedad Extranjera" || obj.strDescripcion === "NIT";
        }
      );
    } else {
      this.showErrorModal(false);
    }
  }

  /**
   * Metodo para establecer el campo a mostrar, si es el cedula de extranjeria
   * o NIT, tambien limpia los campos cuando su valor cambia
   */
  validateNIT() {
    this.searchCompanyForm.get('numDocumento').setValue('');
    this.showNITField = this.searchCompanyForm.get('tipoDocumento').value === '5-NIT';
    this.updateSidebar();
  }

  /**
   * Metodo para construir el NIT de acuerdo a los digitos que se incluyan
   * @param keyup evento del teclado
   */
  setNit(keyup) {
    let nitValue = this.searchCompanyForm.get('numDocumento').value;
    if (!!nitValue && keyup.key !== "Backspace") {
      nitValue = nitValue.replace(/\D/g, '');
      if (nitValue.length === 9) {
        const verificationCode = getVerificationCode(nitValue);
        const newValue = nitValue.replace(/\B(?=(\d{3})+(?!\d))/g, ".") + "-" + verificationCode;
        this.searchCompanyForm.get('numDocumento').setValue(newValue);
      } else if (nitValue.length === 10) {
        let newValue = "";
        for (let x = 0; x < nitValue.length; x++) {
          if (x % 3 === 0 && x !== 0 && x < 9) {
            newValue = newValue.concat(".");
          } else if (x === 9) {
            newValue = newValue.concat("-");
          }
          newValue = newValue.concat(nitValue[x]);
        }
        this.searchCompanyForm.get('numDocumento').setValue(newValue);
      }
    }
  }

  /**
   * Metodo para procesar la informacion mediante el boton enter
   */
  enterToSearchCompany() {
    if (this.validateForm()) {
      this.submit();
    }
  }

  /**
   * Metodo que valida la informacion de la pantalla para poder continuar
   */
  validateForm() {
    const numDocumento = this.searchCompanyForm.get('numDocumento').value;
    return (
      this.searchCompanyForm.get('tipoDocumento').valid
      && ((this.showNITField && !!numDocumento && numDocumento.length === 13) || (!this.showNITField && !!numDocumento))
    );
  }

  /**
   * Metodo para guardar en sor finalizando la actividad de consulta de datos
   */
  async submit() {
    await this.searchCustomer();
    await this.saveDataSor(true);
  }

  /**
   * Metodo para buscar un cliente juridico
   */
  async searchCustomer() {
    const numeroIdentificacion = this.searchCompanyForm.get('numDocumento').value.replace(/\./g, '');
    const tipoIdentificacion = this.searchCompanyForm.get('tipoDocumento').value.split("-")[0].trim();
    const object = this.getLegalPersonPart1();
    const querySearchCustomer = {
      "query": "query clienteExiste($tipoIdenti: String!, $numIdenti: String!){ clienteExiste(tipoIdentificacion: $tipoIdenti, numeroIdentificacion: $numIdenti){ existe , idCliente, personaJuridica " + object + " } }",
      "variables": {
        "tipoIdenti": tipoIdentificacion || "",
        "numIdenti": numeroIdentificacion || ""
      },
      "operationName": "clienteExiste"
    };
    const object2 = this.getLegalPersonPart2();
    const querySearchCustomer2 = {
      "query": "query clienteExiste($tipoIdenti: String!, $numIdenti: String!){ clienteExiste(tipoIdentificacion: $tipoIdenti, numeroIdentificacion: $numIdenti){ existe , idCliente, personaJuridica " + object2 + " } }",
      "variables": {
        "tipoIdenti": tipoIdentificacion || "",
        "numIdenti": numeroIdentificacion || ""
      },
      "operationName": "clienteExiste"
    };
    const object3 = this.getLegalPersonPart3();
    const querySearchCustomer3 = {
      "query": "query clienteExiste($tipoIdenti: String!, $numIdenti: String!){ clienteExiste(tipoIdentificacion: $tipoIdenti, numeroIdentificacion: $numIdenti){ existe , idCliente, personaJuridica " + object3 + " } }",
      "variables": {
        "tipoIdenti": tipoIdentificacion || "",
        "numIdenti": numeroIdentificacion || ""
      },
      "operationName": "clienteExiste"
    };
    const getCustRs = await this._customerService.getCustomer(querySearchCustomer);
    const getCustRs2 = await this._customerService.getCustomer(querySearchCustomer2);
    const getCustRs3 = await this._customerService.getCustomer(querySearchCustomer3);
    if (!!getCustRs) {
      this.isCustomerFound = !!getCustRs.data && !!getCustRs.data.clienteExiste ? getCustRs.data.clienteExiste.existe || false : false;
      if (getCustRs.data.clienteExiste.existe) {
        this.dataClient = this.updateData(getCustRs.data.clienteExiste, getCustRs2.data.clienteExiste, getCustRs3.data.clienteExiste);
      } else {
        this.dataClient = undefined;
      }
    } else {
      this.showErrorModal(false);
    }
  }
  /** Metodo que actualiza el objeto
   * @param objectPart1 parte 1 del objeto
   * @param objectPart2 parte 2 del objeto
   * @param objectPart3 parte 3 del objeto
  */
  updateData(objectPart1: any, objectPart2: any, objectPart3: any) {
    const data = Object.assign(objectPart1.personaJuridica, objectPart2.personaJuridica, objectPart3.personaJuridica);
    const object = objectPart1;
    objectPart1.personaJuridica = data;
    this.datosSolicitud = setSORData(object, this.searchCompanyForm.value);
    return this.datosSolicitud;
  }

  /**
   * Metodo para enviar objeto a la barra lateral con el fin de que se actualice
   * segun la informacion procesada
   */
  async updateSidebar() {
    if (!(!!this.idInstancia)) {
      await this.getTaskInfo();
    }
    if (!!this.idInstancia) {
      const solicitudSorRq = createSolicitudMapping(this.idInstancia, this.searchCompanyForm, this.isCustomerFound);
      let datosSolicitud = new DatosSolicitud();
      datosSolicitud = JSON.parse(solicitudSorRq.datosSolicitud);
      if (!!datosSolicitud) {
        const dataPage = {
          "currentPage": this.CONST_CONSULTAR_CLIENTE_JURIDICO,
          "dataSolicitud": datosSolicitud
        };
        this._compoComunicationService.emmitSideBarEvent(dataPage);
      }
    }
  }

  /**
   * Metodo para cerrar la alerta de cliente en consulta
   */
  closeCustomerAlert() {
    this.isCustomerAlert = false;
  }
}
