// Navigation services
import { AuthGuardService as AuthGuard } from '../../shared/services/auth-guard.service';

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SearchCustomerComponent } from './search-customer.component';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from 'src/app/material/material.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { CustomerService } from 'src/app/services/customer.service';

const routes: Routes = [
  { path: '', component: SearchCustomerComponent, canActivate: [AuthGuard] }
];

@NgModule({
  declarations: [
    SearchCustomerComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    SharedModule,
    RouterModule.forChild(routes)
  ],
  providers: [
    CustomerService
  ]
})
export class SearchCustomerModule { }
