import { Component, OnInit, OnDestroy, ElementRef, AfterViewInit } from '@angular/core';
import { ClaimTaskRequest } from 'src/app/shared/utils/models/api-bpm/ClaimTaskRq';
import { ProcessInstanceRequest } from 'src/app/shared/utils/models/api-bpm/ProcessInstanceRequest';
import { FinishTaskRequest } from 'src/app/shared/utils/models/api-bpm/FinishTaskRq';
import { Solicitud } from 'src/app/shared/utils/models/Solicitud/Solicitud';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { GetTaskByIdRequest } from 'src/app/shared/utils/models/api-bpm/GetTaskByIdRequest';
import { Accionista } from 'src/app/utils/models/api-solicitud/Accionista';
import { Router, ActivatedRoute } from '@angular/router';
import { SolicitudService } from 'src/app/shared/services/solicitud.service';
import { BpmService } from 'src/app/shared/services/bpm.service';
import { ComponentCommunicationService } from 'src/app/services/component-communication.service';
import { Subscription } from 'rxjs';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { DatosAccionistas } from 'src/app/utils/models/api-solicitud/DatosAccionistas';
import { TipoParticipante } from 'src/app/utils/constants/participants.enum';
import { setScrolIntoView } from 'src/app/shared/utils/functions/utils';
import { mappingStradataFromParticipant, updateDatosRiesgoJuridico, setDatosRiesgo, setClienteJuridicoSCAP, setClienteJuridicoSIAP } from 'src/app/utils/mapping/BureauMapping';
import { BureauService } from 'src/app/shared/services/bureau.service';
import { CatalogoRequest } from 'src/app/shared/utils/mapping/CatalogoRequest';
import { CatalogoService } from 'src/app/shared/services/catalogo.service';
import { capitalizeText } from 'src/app/shared/utils/functions/transform';
import { CONST_GATEWAY_DEC_VAR_BPM } from 'src/app/utils/constants/utils.constant';
import { mappingConsultaListas } from 'src/app/utils/mapping/EnrutamientoMapping';

@Component({
  selector: 'app-shareholder',
  templateUrl: './shareholder.component.html',
  styleUrls: ['./shareholder.component.scss']
})
export class ShareholderComponent implements OnInit, OnDestroy, AfterViewInit {
  idActividad: string;
  idInstancia: string;
  datosSolicitud: DatosSolicitud;
  datosAccionistas: DatosAccionistas;
  model: Accionista;
  communicationSuscription: Subscription;
  formThirdParty: FormGroup;
  firstSection: boolean;
  listShareholder: any[];
  showForm: boolean;
  editData: boolean;
  idSelected: number;
  typeParticipant: number;
  listPais: any[];
  listCIUU: any[];
  decisionGateway: string;

  constructor(private _compoComunicationService: ComponentCommunicationService,
    private _bpmService: BpmService,
    private _activatedRoute: ActivatedRoute,
    private _solicitudService: SolicitudService,
    private _bureauService: BureauService,
    private _catalogoService: CatalogoService,
    private _router: Router,
    private _el: ElementRef
  ) {
    this.formThirdParty = new FormGroup({
      emisorInscrito: new FormControl(null, Validators.required)
    });
    this.firstSection = true;
    this.listShareholder = new Array<any>();
    this.datosAccionistas = new DatosAccionistas();
    this.model = new Accionista();
    this.showForm = false;
    this.editData = false;
    this.idSelected = -1;
    this.setSuscriptions();
    this.typeParticipant = TipoParticipante.accionista;
  }

  ngOnInit() {
    this.idActividad = this._activatedRoute.parent.snapshot.paramMap.get("taskId") || '';
    this.decisionGateway = '';
    this.loadListData();
    this.getTaskInfo();
    this.getSolicitudSor();
  }
  ngOnDestroy() {
    if (!!this.communicationSuscription) {
      this.communicationSuscription.unsubscribe();
    }
  }

  /**
   * Metodo que carga catalogos para la revision del riesgo
   */
  async loadListData() {
    this.listPais = await this.getCatalog("Pais", null);
    this.listCIUU = await this.getCatalog("CIIU", null);
  }

  /**
   * Metodo para obtener un catalogo de acuerdo al nombre
   * @param catalogName nombre del catalogo
   * @param id realiza un filtro del catalogo de acuerdo a una llave
   */
  async getCatalog(catalogName: string, id: string) {
    const catalogoRq = new CatalogoRequest();
    catalogoRq.catalogName = catalogName;
    catalogoRq.idParent = id || '';
    const items = await this._catalogoService.getCatalog(catalogoRq);
    items.items.forEach(element => element.name = capitalizeText(element.name.toLowerCase()));
    return items.items;
  }

  ngAfterViewInit() {
    const inputList = ([].slice.call((<HTMLElement> this._el.nativeElement).querySelectorAll('input:not(.mat-radio-input)'))).concat([].slice.call((<HTMLElement> this._el.nativeElement).getElementsByTagName('textarea')));
    setScrolIntoView(inputList);
  }

  /**
   * Metodo para obtener los datos de la tarea
   */
  async getTaskInfo() {
    const taskModelRq = new GetTaskByIdRequest();
    taskModelRq.taskId = this.idActividad;
    const getTaskInfoRs = await this._bpmService.getTaskInfo(taskModelRq);
    if (!!getTaskInfoRs) {
      this.idInstancia = getTaskInfoRs.processInstanceId;
    } else {
      this.idInstancia = null;
    }
  }
  /**
   * Metodo para obtener la data previa en SOR
   */
  async getSolicitudSor() {
    this.showLoading(true);
    try {
      await this.getProcessData();
      if (!!this.idInstancia) {
        const solicitudRq = new Solicitud();
        solicitudRq.idSolicitud = this.idInstancia;
        const solicitudRs = await this._solicitudService.getSolicitud(solicitudRq);
        if (!!solicitudRs && !!solicitudRs.datosSolicitud) {
          this.datosSolicitud = JSON.parse(solicitudRs.datosSolicitud);
          this.updateData();
          this.updateSidebar();
        }
      } else {
        this.showErrorModal(true);
      }
    } catch (error) {
      this.showErrorModal(false);
    }
    this.showLoading(false);
  }
  async showErrorModal(redirectLogin: boolean) {
    const errorData = {
      'showErrorModal': true,
      'redirectLogin': redirectLogin
    };
    await this._compoComunicationService.emmitError(errorData);
  }
  /**
   * Metodo para obtener los datos del proceso, en
   * este caso el id de la instancia
   */
  async getProcessData() {
    await this.getTaskInfo();
    if (!(!!this.idInstancia)) {
      this.showErrorModal(true);
    }
  }
  updateData() {
    const data = this.datosSolicitud.clienteJuridico.datosAccionistas;
    if (data) {
      this.formThirdParty.get("emisorInscrito").setValue(data.emisorInscrito);
      this.firstSection = data.emisorInscrito === "no" ? false : true;
      const list = data.accionistas;
      if (list) {
        this.listShareholder = list.map(element => {
          const propertiesForm = Object.getOwnPropertyNames(element);
          const object = {};
          propertiesForm.forEach((item) => {
            object[item] = new FormControl(element[item], Validators.required);
          });
          return new FormGroup(object);
        });
      }
    }
  }
  /** Metodo para actulizar la informacion del sidebar */
  async updateSidebar() {
    const respForm = this.formThirdParty.get("emisorInscrito").value;
    this.datosSolicitud.clienteJuridico.datosAccionistas = this.datosAccionistas;
    this.datosSolicitud.clienteJuridico.datosAccionistas.emisorInscrito = respForm || '';
    this.datosSolicitud.clienteJuridico.datosAccionistas.accionistas =
      this.listShareholder.map(item => item.value) || null;
    if (!!this.idInstancia) {
      const dataPage = {
        "currentPage": "CARGAR_INFORMACION_ACCIONISTAS",
        "dataSolicitud": this.datosSolicitud
      };
      this._compoComunicationService.emmitSideBarEvent(dataPage);
    }
  }
  /**
   * Metodo para controlar el componente de loading desde la pagina de buscar
   * componente
   * @param value si es verdadero muestra el loading no lo muestra en caso
   * contrariuo
   */
  showLoading(value: boolean) {
    this._compoComunicationService.emmitLoading(value);
  }
  /**
   * Metodo para guardar la solicitud en sor
   * @param finishTask Valor de decision para finalizar tarea
   */
  async saveDataSor(finishTask: boolean) {
    this.showLoading(true);
    if (!!this.idInstancia) {
      const solicitud = new Solicitud();
      solicitud.idSolicitud = this.idInstancia;
      solicitud.setDatosSolicitud(this.datosSolicitud);
      const solicitudSorRs = await this._solicitudService.saveSolicitud(solicitud);
      if (!!solicitudSorRs) {
        if (finishTask) {
          await this.finishTask();
        }
      } else {
        this.showErrorModal(false);
      }
    } else {
      this.showErrorModal(true);
    }
    this.showLoading(false);
  }
  /**
   * Metodo para finalizar la tarea actual
   */
  async finishTask() {
    await this.setDecisionGateway();
    const finishTaskRq = new FinishTaskRequest();
    finishTaskRq.taskId = this.idActividad;
    finishTaskRq.variable = {
      "decisionGateway": {
        "value": this.decisionGateway
      }
    };
    const finishTaskRs = await this._bpmService.finishTask(finishTaskRq);
    if (!!finishTaskRs) {
      const processInstanceRq = new ProcessInstanceRequest();
      processInstanceRq.processInstanceId = this.idInstancia;
      const getNextTaskRs = await this._bpmService.getNextTask(processInstanceRq);
      if (!!getNextTaskRs && getNextTaskRs.length > 0) {
        const body = new ClaimTaskRequest();
        body.idTask = getNextTaskRs[0].id;
        const claimTask = await this._bpmService.getClaimTask(body);
        if (!!claimTask) {
          this.redirectExternalUrl(claimTask.path);
        } else {
          this.showErrorModal(false);
        }
      } else {
        this.redirectUrl('/portal/');
      }
    } else {
      this.showErrorModal(false);
    }
  }
  /**
   * Metodo para navegar a una url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      this._router.navigate(['/externalRedirect', { externalUrl: domain }], {
        skipLocationChange: true,
      });
    }
  }
  /**
   * Metodo para navegar al login como url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectExternalUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      window.open(domain, '_self');
    }
  }
  /**
   * Metodo para conectar al los datos del componente padre a la pantalla
   * de consultar empresa
   */
  setSuscriptions() {
    this.communicationSuscription = this._compoComunicationService.saveButtonCommunication$.subscribe(
      saveDataButton => {
        if (!!saveDataButton) {
          this.saveAndExit();
        }
      }
    );
  }
  async saveAndExit() {
    await this.saveDataSor(false);
    this.redirectUrl('/portal/');
  }

  addShareholder() {
    this.idSelected = this.listShareholder.length;
    this.model = new Accionista();
    this.showForm = true;
    this.editData = false;
  }
  getShareholder(data: any, showForm) {
    if (data.value) {
      if (!this.listShareholder[this.idSelected]) {
        this.listShareholder.push(data);
      } else {
        this.listShareholder[this.idSelected] = data;
      }
      this.updateSidebar();
      this.showForm = showForm;
    }
  }
  onAction(action: any, id: number) {
    if (action.action === 1) {
      this.idSelected = id;
      this.model = action.item;
      this.showForm = true;
      this.editData = true;
    } else {
      this.listShareholder.splice(id, 1);
      this.updateSidebar();
    }
  }
  validSubmit() {
    const respForm = this.formThirdParty.get("emisorInscrito").value;
    const list = this.listShareholder.filter(item => item.valid);
    const valid = list.length === this.listShareholder.length && this.listShareholder.length !== 0;
    return respForm === "si" || respForm === "no" && valid;
  }
  showTable(value: any) {
    this.firstSection = value === "no" ? false : true;
    this.updateSidebar();
  }
  back() {
    this.formThirdParty.get("emisorInscrito").setValue(null);
    this.firstSection = true;
    this.updateSidebar();
  }
  async submit() {
    const updateRisk = await this.checkBureauParticipants();
    if (updateRisk) {
      const respForm = this.formThirdParty.get("emisorInscrito").value;
      if (respForm === "si") {
        this.datosSolicitud.clienteJuridico.datosAccionistas.accionistas = [];
        await this.saveDataSor(true);
      } else {
        await this.saveDataSor(true);
      }
    } else {
      this.showErrorModal(false);
    }
  }

  /**
   * Metodo para establecer el riesgo de los participantes legales
   */
  async checkBureauParticipants() {
    this.showLoading(true);
    try {
      const bureauRq = mappingStradataFromParticipant(this.datosSolicitud.clienteJuridico.datosAccionistas.accionistas);
      const bureauRs = await this._bureauService.getStradataList(bureauRq);
      if (!!bureauRs) {
        this.datosSolicitud.clienteJuridico.datosAccionistas.accionistas = this.setParticipantsRisk(bureauRs, this.datosSolicitud.clienteJuridico.datosAccionistas.accionistas);
        this.updateJuridicoRisk();
        const riskSummary = bureauRs["summary"];
        riskSummary["scapRisk"] = this.datosSolicitud.clienteJuridico.datosRiesgo.scapRisk;
        riskSummary["siapRisk"] = this.datosSolicitud.clienteJuridico.datosRiesgo.siapRisk;
        this.datosSolicitud.clienteJuridico.datosRiesgo = updateDatosRiesgoJuridico(riskSummary, this.datosSolicitud.clienteJuridico.datosRiesgo);
        await this.checkRoutingRule(riskSummary);
      } else {
        this.showLoading(false);
        return false;
      }
    } catch (error) {
      this.showLoading(false);
      return false;
    }
    this.showLoading(false);
    return true;
  }

  /**
   * Metodo que almacena en el BO los riesgos de cada participante de la solicitud
   * @param bureauRs la respuesta obtenida de la consulta de riesgo de todos los participantes
   */
  setParticipantsRisk(bureauRs: any, participantList: Array<any>) {
    if (!!bureauRs && !!participantList && participantList.length > 0) {
      participantList.forEach(
        (par) => {
          const participantKey = par.numeroDocumento.replace(/\./g, '');
          if (!!bureauRs[participantKey]) {
            par.datosRiesgo = setDatosRiesgo(bureauRs[participantKey]);
            par.datosRiesgo.scapRisk = this.setParticipantSCAP(par);
            par.datosRiesgo.siapRisk = this.setRiskSIAP(par);
          }
        }
      );
    }
    return participantList;
  }

  /**
   * Metodo para establecer el riesgo SCAP de un participante
   * @param participante participante que debe contener el paises de nacimiento y el pais de residencia
   */
  setParticipantSCAP(participante: any) {
    if (!!participante) {
      const riesgoPaisNacimiento = !!participante.paisNacimiento ? this.getRiskPais(participante.paisNacimiento.split('-')[0].trim()) : "bajo";
      const riesgoPaisResidencia = !!participante.paisResidencia ? this.getRiskPais(participante.paisResidencia.split('-')[0].trim()) : "bajo";
      return ((riesgoPaisNacimiento === 'prohibido' || riesgoPaisResidencia === 'prohibido') ? 'prohibido' : ((riesgoPaisNacimiento === 'sensible' || riesgoPaisResidencia === 'sensible') ? 'sensible' : 'bajo'));
    }
    return 'bajo';
  }

  /**
   * Metodo que analiza el riesgo de un pais
   * @param codPais codigo del pais en la vista de base de datos
   */
  getRiskPais(codPais: string) {
    if (!!codPais) {
      const pais = this.listPais.find((obj) => obj.id === codPais);
      if (!!pais) {
        const riesgo = pais.riesgo.toLowerCase() || '';
        return (riesgo.indexOf('prohibido') !== -1 ? 'prohibido' : (riesgo.indexOf('sensible') !== -1 ? 'sensible' : 'bajo'));
      }
    }
    return 'bajo';
  }

  /**
   * Metodo que analiza el riesgo de una actividad comercial
   * @param codCUII codigo de la actividad comercial en la vista de base de datos
   */
  setRiskSIAP(participant: any) {
    const codCUII = !!participant.codigoCIIU && participant.codigoCIIU.indexOf("-") !== -1 ? participant.codigoCIIU.split('-')[0].trim() : '';
    if (!!codCUII) {
      const actividadEconomica = this.listCIUU.find((obj) => obj.id === codCUII);
      if (!!actividadEconomica) {
        const riesgo = actividadEconomica.strDescripcion.toLowerCase() || '';
        return (riesgo.indexOf('alto') !== -1 ? 'alto' : (riesgo.indexOf('sensible') !== -1 ? 'sensible' : 'bajo'));
      }
    }
    return 'bajo';
  }

  /**
   * Metodo para establecer el riesgo del cliente juridico
   */
  updateJuridicoRisk() {
    this.datosSolicitud = setClienteJuridicoSCAP(this.datosSolicitud);
    this.datosSolicitud = setClienteJuridicoSIAP(this.datosSolicitud);
  }

  /**
   * Metodo para consultar la regla de enrutamiento segun el resumen del riesgo de los
   * participantes de la solicitud
   * @param riskSummary contiene el resumen del riesgo de todos los participantes de la solicitud
   */
  async checkRoutingRule(riskSummary) {
    const datosRiesgo = setDatosRiesgo(riskSummary);
    const enrutamientoRq = mappingConsultaListas(datosRiesgo);
    const enrutamientoRs = await this._bpmService.callBPMRule(enrutamientoRq);
    if (!!enrutamientoRs && enrutamientoRs.length > 0) {
      const resultEnrutamiento = enrutamientoRs[0];
      this.decisionGateway = resultEnrutamiento.respuestaEnrutamiento.value;
    }
  }

  /**
   * Metodo para validar que no se repita el valor en el decisionGateway
   */
  async setDecisionGateway() {
    const getVarRq = { "instanceId" : this.idInstancia, "varName" : CONST_GATEWAY_DEC_VAR_BPM };
    const getVarRs = await this._bpmService.getProcessVariable(getVarRq);
    if (!!getVarRs && !!getVarRs.value && getVarRs.value.indexOf(this.decisionGateway) === -1) {
      this.decisionGateway = getVarRs.value + '-' + this.decisionGateway;
    } else {
      this.decisionGateway = getVarRs.value;
    }
  }
}
