import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ShareholderComponent } from './shareholder.component';
import { Routes, RouterModule } from '@angular/router';
import { ComponentsModule } from 'src/app/components/components.module';
import { MatRadioModule, MatFormFieldModule, MatTabsModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

const routes: Routes = [
  { path: '', component: ShareholderComponent },
];

@NgModule({
  declarations: [ShareholderComponent],
  imports: [
    ComponentsModule,
    CommonModule,
    RouterModule.forChild(routes),
    MatRadioModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatTabsModule
  ]
})
export class ShareholderModule { }
