import { Component, OnInit, OnDestroy } from '@angular/core';
import { ComponentCommunicationService } from 'src/app/services/component-communication.service';
import { BpmService } from 'src/app/shared/services/bpm.service';
import { ActivatedRoute, Router } from '@angular/router';
import { SolicitudService } from 'src/app/shared/services/solicitud.service';
import { GetTaskByIdRequest } from 'src/app/shared/utils/models/api-bpm/GetTaskByIdRequest';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { Solicitud } from 'src/app/shared/utils/models/Solicitud/Solicitud';
import { FinishTaskRequest } from 'src/app/shared/utils/models/api-bpm/FinishTaskRq';
import { ProcessInstanceRequest } from 'src/app/shared/utils/models/api-bpm/ProcessInstanceRequest';
import { ClaimTaskRequest } from 'src/app/shared/utils/models/api-bpm/ClaimTaskRq';
import { Subscription } from 'rxjs';
import { DatosTerceros } from 'src/app/utils/models/api-solicitud/DatosTerceros';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { mappingStradataFromParticipant, updateDatosRiesgoJuridico, setDatosRiesgo, setClienteJuridicoSCAP, setClienteJuridicoSIAP } from 'src/app/utils/mapping/BureauMapping';
import { BureauService } from 'src/app/shared/services/bureau.service';
import { mappingConsultaListas } from 'src/app/utils/mapping/EnrutamientoMapping';
import { CONST_GATEWAY_DEC_VAR_BPM } from 'src/app/utils/constants/utils.constant';
import { CatalogoService } from 'src/app/shared/services/catalogo.service';
import { CatalogoRequest } from 'src/app/shared/utils/mapping/CatalogoRequest';
import { capitalizeText } from 'src/app/shared/utils/functions/transform';
import { TipoParticipante } from 'src/app/utils/constants/participants.enum';

@Component({
  selector: 'app-third-party',
  templateUrl: './third-party.component.html',
  styleUrls: ['./third-party.component.scss']
})
export class ThirdPartyComponent implements OnInit, OnDestroy {
  idActividad: string;
  idInstancia: string;
  datosSolicitud: DatosSolicitud;
  model: DatosTerceros;
  communicationSuscription: Subscription;
  formThirdParty: FormGroup;
  listThirdPartys: any[];
  showForm: boolean;
  editData: boolean;
  idSelected: number;
  decisionGateway: string;
  showRejectModal: boolean;
  listPais: any[];
  listCIUU: any[];
  typeParticipant: number;

  constructor(private _compoComunicationService: ComponentCommunicationService,
    private _bpmService: BpmService,
    private _activatedRoute: ActivatedRoute,
    private _solicitudService: SolicitudService,
    private _bureauService: BureauService,
    private _catalogoService: CatalogoService,
    private _router: Router) {
    this.formThirdParty = new FormGroup({
      emisorInscrito: new FormControl(null, Validators.required)
    });
    this.listThirdPartys = new Array<any>();
    this.model = new DatosTerceros();
    this.showForm = false;
    this.editData = false;
    this.idSelected = -1;
    this.setSuscriptions();
    this.typeParticipant = TipoParticipante.tercero;
  }

  ngOnInit() {
    this.idActividad = this._activatedRoute.parent.snapshot.paramMap.get("taskId") || '';
    this.decisionGateway = '';
    this.loadListData();
    this.getTaskInfo();
    this.getSolicitudSor();
  }

  ngOnDestroy() {
    if (!!this.communicationSuscription) {
      this.communicationSuscription.unsubscribe();
    }
  }

  async loadListData() {
    this.listPais = await this.getCatalog("Pais", null);
    this.listCIUU = await this.getCatalog("CIIU", null);
  }

  async getCatalog(catalogName: string, id: string) {
    const catalogoRq = new CatalogoRequest();
    catalogoRq.catalogName = catalogName;
    catalogoRq.idParent = id || '';
    const items = await this._catalogoService.getCatalog(catalogoRq);
    items.items.forEach(element => element.name = capitalizeText(element.name.toLowerCase()));
    return items.items;
  }

  /**
   * Metodo para obtener los datos de la tarea
   */
  async getTaskInfo() {
    const taskModelRq = new GetTaskByIdRequest();
    taskModelRq.taskId = this.idActividad;
    const getTaskInfoRs = await this._bpmService.getTaskInfo(taskModelRq);
    if (!!getTaskInfoRs) {
      this.idInstancia = getTaskInfoRs.processInstanceId;
    } else {
      this.idInstancia = null;
    }
  }

  /**
   * Metodo para obtener la data previa en SOR
   */
  async getSolicitudSor() {
    this.showLoading(true);
    try {
      await this.getProcessData();
      if (!!this.idInstancia) {
        const solicitudRq = new Solicitud();
        solicitudRq.idSolicitud = this.idInstancia;
        const solicitudRs = await this._solicitudService.getSolicitud(solicitudRq);
        if (!!solicitudRs && !!solicitudRs.datosSolicitud) {
          this.datosSolicitud = JSON.parse(solicitudRs.datosSolicitud);
          this.updateData();
          this.updateSidebar();
        }
      } else {
        this.showErrorModal(true);
      }
    } catch (error) {
      this.showErrorModal(false);
    }
    this.showLoading(false);
  }

  async showErrorModal(redirectLogin: boolean) {
    const errorData = {
      'showErrorModal': true,
      'redirectLogin': redirectLogin
    };
    await this._compoComunicationService.emmitError(errorData);
  }

  /**
   * Metodo para obtener los datos del proceso, en
   * este caso el id de la instancia
   */
  async getProcessData() {
    await this.getTaskInfo();
    if (!(!!this.idInstancia)) {
      this.showErrorModal(true);
    }
  }

  updateData() {
    const list = this.datosSolicitud.clienteJuridico.datosTerceros;
    if (list) {
      this.listThirdPartys = list.map(element => {
        const propertiesForm = Object.getOwnPropertyNames(element);
        const object = {};
        propertiesForm.forEach((item) => {
          object[item] = new FormControl(element[item], Validators.required);
        });
        return new FormGroup(object);
      });
    }
  }

  /** Metodo para actulizar la informacion del sidebar */
  async updateSidebar() {
    this.datosSolicitud.clienteJuridico.datosTerceros =
      this.listThirdPartys.map(item => item.value) || null;
    if (!!this.idInstancia) {
      const dataPage = {
        "currentPage": "CARGAR_INFORMACION_TERCEROS",
        "dataSolicitud": this.datosSolicitud
      };
      this._compoComunicationService.emmitSideBarEvent(dataPage);
    }
  }

  /**
   * Metodo para controlar el componente de loading desde la pagina de buscar
   * componente
   * @param value si es verdadero muestra el loading no lo muestra en caso
   * contrariuo
   */
  showLoading(value: boolean) {
    this._compoComunicationService.emmitLoading(value);
  }

  /**
   * Metodo para guardar la solicitud en sor
   * @param finishTask Valor de decision para finalizar tarea
   */
  async saveDataSor(finishTask: boolean) {
    this.showLoading(true);
    if (!!this.idInstancia) {
      const solicitud = new Solicitud();
      solicitud.idSolicitud = this.idInstancia;
      solicitud.setDatosSolicitud(this.datosSolicitud);
      const solicitudSorRs = await this._solicitudService.saveSolicitud(solicitud);
      if (!!solicitudSorRs) {
        if (finishTask) {
          await this.finishTask();
        }
      } else {
        this.showErrorModal(false);
      }
    } else {
      this.showErrorModal(true);
    }
    this.showLoading(false);
  }

  /**
   * Metodo para finalizar la tarea actual
   */
  async finishTask() {
    await this.setDecisionGateway();
    const getVarRq = { "instanceId" : this.idInstancia, "varName" : CONST_GATEWAY_DEC_VAR_BPM };
    const getVarRs = await this._bpmService.getProcessVariable(getVarRq);
    if (!!getVarRs && !!getVarRs.value) {
      this.decisionGateway = getVarRs.value + '-' + this.decisionGateway;
    }
    const finishTaskRq = new FinishTaskRequest();
    finishTaskRq.taskId = this.idActividad;
    finishTaskRq.variable = {
      "decisionGateway": {
        "value": this.decisionGateway
      }
    };
    const finishTaskRs = await this._bpmService.finishTask(finishTaskRq);
    if (!!finishTaskRs) {
      if (this.decisionGateway.indexOf('enrutamientoRechazo') !== -1) {
        this.showLoading(false);
        this.showRejectModal = true;
      } else {
        const processInstanceRq = new ProcessInstanceRequest();
        processInstanceRq.processInstanceId = this.idInstancia;
        const getNextTaskRs = await this._bpmService.getNextTask(processInstanceRq);
        if (!!getNextTaskRs && getNextTaskRs.length > 0) {
          const body = new ClaimTaskRequest();
          body.idTask = getNextTaskRs[0].id;
          const claimTask = await this._bpmService.getClaimTask(body);
          if (!!claimTask) {
            this.redirectExternalUrl(claimTask.path);
          } else {
            this.showErrorModal(false);
          }
        } else {
          this.redirectUrl('/portal/');
        }
      }
    } else {
      this.showErrorModal(false);
    }
  }

/**
   * Metodo para cerrar el modal del error
   * @param value Valor proporcionado por el componente Modal
   */
  async closeRejectModal(value: boolean) {
    this.showRejectModal = value;
    this.delay(2000);
    this.redirectUrl('/portal/');
  }

  delay(ms: number) {
    return new Promise( resolve => setTimeout(resolve, ms) );
  }

  /**
   * Metodo para navegar a una url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      this._router.navigate(['/externalRedirect', { externalUrl: domain }], {
        skipLocationChange: true,
      });
    }
  }
  /**
   * Metodo para navegar al login como url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectExternalUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      window.open(domain, '_self');
    }
  }
  /**
   * Metodo para conectar al los datos del componente padre a la pantalla
   * de consultar empresa
   */
  setSuscriptions() {
    this.communicationSuscription = this._compoComunicationService.saveButtonCommunication$.subscribe(
      saveDataButton => {
        if (!!saveDataButton) {
          this.saveAndExit();
        }
      }
    );
  }

  async saveAndExit() {
    await this.saveDataSor(false);
    this.redirectUrl('/portal/');
  }

  addThirdParty() {
    this.idSelected = this.listThirdPartys.length;
    this.model = new DatosTerceros();
    this.showForm = true;
    this.editData = false;
  }

  getThirdParty(data: any, showForm: boolean) {
    if (data.value) {
      if (!this.listThirdPartys[this.idSelected]) {
        this.listThirdPartys.push(data);
      } else {
        this.listThirdPartys[this.idSelected] = data;
      }
      this.updateSidebar();
      this.showForm = showForm;
    }
  }

  onAction(action: any, id: number) {
    if (action.action === 1) {
      this.idSelected = id;
      this.model = action.item;
      this.showForm = true;
      this.editData = true;
    } else {
      this.listThirdPartys.splice(id, 1);
      this.updateSidebar();
    }
  }

  validSubmit() {
    const list = this.listThirdPartys.filter(item => item.valid);
    const valid = list.length === this.listThirdPartys.length && this.listThirdPartys.length !== 0;
    return valid;
  }

  async submit() {
    const resultBureau = await this.checkBureauParticipants();
    if (resultBureau) {
      this.saveDataSor(true);
    } else {
      this.showErrorModal(false);
    }
  }

  /**
   * Metodo para establecer el riesgo de los participantes legales
   */
  async checkBureauParticipants() {
    this.showLoading(true);
    try {
      const bureauRq = mappingStradataFromParticipant(this.datosSolicitud.clienteJuridico.datosTerceros);
      const bureauRs = await this._bureauService.getStradataList(bureauRq);
      if (!!bureauRs) {
        this.datosSolicitud.clienteJuridico.datosTerceros = this.setParticipantsRisk(bureauRs, this.datosSolicitud.clienteJuridico.datosTerceros);
        this.updateJuridicoRisk();
        const riskSummary = bureauRs["summary"];
        riskSummary["scapRisk"] = this.datosSolicitud.clienteJuridico.datosRiesgo.scapRisk;
        riskSummary["siapRisk"] = this.datosSolicitud.clienteJuridico.datosRiesgo.siapRisk;
        this.datosSolicitud.clienteJuridico.datosRiesgo = updateDatosRiesgoJuridico(riskSummary, this.datosSolicitud.clienteJuridico.datosRiesgo);
        await this.checkRoutingRule(riskSummary);
      } else {
        this.showLoading(false);
        return false;
      }
    } catch (error) {
      this.showLoading(false);
      return false;
    }
    this.showLoading(false);
    return true;
  }

  /**
   * Metodo que almacena en el BO los riesgos de cada participante de la solicitud
   * @param bureauRs la respuesta obtenida de la consulta de riesgo de todos los participantes
   */
  setParticipantsRisk(bureauRs: any, participantList: Array<any>) {
    if (!!bureauRs && !!participantList && participantList.length > 0) {
      participantList.forEach(
        (par) => {
          const participantKey = par.numeroDocumento.replace(/\./g, '');
          if (!!bureauRs[participantKey]) {
            par.datosRiesgo = setDatosRiesgo(bureauRs[participantKey]);
            par.datosRiesgo.scapRisk = this.setParticipantSCAP(par);
            par.datosRiesgo.siapRisk = this.setRiskSIAP(par);
          }
        }
      );
    }
    return participantList;
  }

  /**
   * Metodo para establecer el riesgo SCAP de un participante
   * @param participante participante que debe contener el paises de nacimiento y el pais de residencia
   */
  setParticipantSCAP(participante: any) {
    if (!!participante) {
      const riesgoPaisNacimiento = !!participante.paisNacimiento ? this.getRiskPais(participante.paisNacimiento.split('-')[0].trim()) : "bajo";
      const riesgoPaisResidencia = !!participante.paisResidencia ? this.getRiskPais(participante.paisResidencia.split('-')[0].trim()) : "bajo";
      return ((riesgoPaisNacimiento === 'prohibido' || riesgoPaisResidencia === 'prohibido') ? 'prohibido' : ((riesgoPaisNacimiento === 'sensible' || riesgoPaisResidencia === 'sensible') ? 'sensible' : 'bajo'));
    }
    return 'bajo';
  }

  /**
   * Metodo que analiza el riesgo de un pais
   * @param codPais codigo del pais en la vista de base de datos
   */
  getRiskPais(codPais: string) {
    if (!!codPais) {
      const pais = this.listPais.find((obj) => obj.id === codPais);
      if (!!pais) {
        const riesgo = pais.riesgo.toLowerCase() || '';
        return (riesgo.indexOf('prohibido') !== -1 ? 'prohibido' : (riesgo.indexOf('sensible') !== -1 ? 'sensible' : 'bajo'));
      }
    }
    return 'bajo';
  }

  /**
   * Metodo que analiza el riesgo de una actividad comercial
   * @param codCUII codigo de la actividad comercial en la vista de base de datos
   */
  setRiskSIAP(participant: any) {
    const codCUII = !!participant.codigoCIIU && participant.codigoCIIU.indexOf("-") !== -1 ? participant.codigoCIIU.split('-')[0].trim() : '';
    if (!!codCUII) {
      const actividadEconomica = this.listCIUU.find((obj) => obj.id === codCUII);
      if (!!actividadEconomica) {
        const riesgo = actividadEconomica.strDescripcion.toLowerCase() || '';
        return (riesgo.indexOf('alto') !== -1 ? 'alto' : (riesgo.indexOf('sensible') !== -1 ? 'sensible' : 'bajo'));
      }
    }
    return 'bajo';
  }

  /**
   * Metodo para establecer el riesgo del cliente juridico
   */
  updateJuridicoRisk() {
    this.datosSolicitud = setClienteJuridicoSCAP(this.datosSolicitud);
    this.datosSolicitud = setClienteJuridicoSIAP(this.datosSolicitud);
  }

  /**
   * Metodo para consultar la regla de enrutamiento segun el resumen del riesgo de los
   * participantes de la solicitud
   * @param riskSummary contiene el resumen del riesgo de todos los participantes de la solicitud
   */
  async checkRoutingRule(riskSummary) {
    const datosRiesgo = setDatosRiesgo(riskSummary);
    const enrutamientoRq = mappingConsultaListas(datosRiesgo);
    const enrutamientoRs = await this._bpmService.callBPMRule(enrutamientoRq);
    if (!!enrutamientoRs && enrutamientoRs.length > 0) {
      const resultEnrutamiento = enrutamientoRs[0];
      this.decisionGateway = resultEnrutamiento.respuestaEnrutamiento.value;
    }
  }

  /**
   * Metodo para validar que no se repita el valor en el decisionGateway
   */
  async setDecisionGateway() {
    const getVarRq = { "instanceId" : this.idInstancia, "varName" : CONST_GATEWAY_DEC_VAR_BPM };
    const getVarRs = await this._bpmService.getProcessVariable(getVarRq);
    if (!!getVarRs && !!getVarRs.value && getVarRs.value.indexOf(this.decisionGateway) === -1) {
      this.decisionGateway = getVarRs.value + '-' + this.decisionGateway;
    } else {
      this.decisionGateway = getVarRs.value;
    }
  }
}
