import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ThirdPartyComponent } from './third-party.component';
import { Routes, RouterModule } from '@angular/router';
import { ComponentsModule } from 'src/app/components/components.module';
import { MatRadioModule, MatFormFieldModule, MatTabsModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

const routes: Routes = [
  { path: '', component: ThirdPartyComponent },
];

@NgModule({
  declarations: [ThirdPartyComponent],
  imports: [
    ComponentsModule,
    CommonModule,
    RouterModule.forChild(routes),
    MatRadioModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatTabsModule
  ]
})
export class ThirdPartyModule { }
