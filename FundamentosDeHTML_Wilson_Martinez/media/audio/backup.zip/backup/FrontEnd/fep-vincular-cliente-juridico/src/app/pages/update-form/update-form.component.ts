import { Subscription } from 'rxjs';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit, OnDestroy, AfterViewInit, ElementRef } from '@angular/core';
import { Solicitud } from 'src/app/shared/utils/models/Solicitud/Solicitud';
import { mappingEnrutamiento } from 'src/app/utils/mapping/EnrutamientoMapping';
import { DatosSolicitud } from 'src/app/utils/models/api-solicitud/DatosSolicitud';
import { ComponentCommunicationService } from 'src/app/services/component-communication.service';
import { BpmService } from 'src/app/shared/services/bpm.service';
import { SolicitudService } from 'src/app/shared/services/solicitud.service';
import { setScrolIntoView } from 'src/app/shared/utils/functions/utils';
import { ClaimTaskRequest } from 'src/app/shared/utils/models/api-bpm/ClaimTaskRq';
import { FinishTaskRequest } from 'src/app/shared/utils/models/api-bpm/FinishTaskRq';
import { GetTaskByIdRequest } from 'src/app/shared/utils/models/api-bpm/GetTaskByIdRequest';
import { ProcessInstanceRequest } from 'src/app/shared/utils/models/api-bpm/ProcessInstanceRequest';
import { DatosActualizacionPantallas } from 'src/app/utils/models/api-solicitud/datosActualizacionPantallas';

@Component({
  selector: 'app-update-form',
  templateUrl: './update-form.component.html',
  styleUrls: ['./update-form.component.scss']
})
export class UpdateFormComponent implements OnInit, OnDestroy, AfterViewInit {

  taskId: string;
  instanceId: string;
  updateList: string[];
  listScreens: any[];
  propertiesForm: string[];
  formUpdateData: FormGroup;
  dataSolicitud: DatosSolicitud;
  formChangesSuscriptor: Subscription;
  communicationSuscription: Subscription;
  CONST_FORMULARIO_ACTUALIZACION = "FORMULARIO_ACTUALIZACION";

  constructor(
    private _el: ElementRef,
    private _router: Router,
    private _bpmService: BpmService,
    private _activatedRoute: ActivatedRoute,
    private _solicitudService: SolicitudService,
    private _compoComunicationService: ComponentCommunicationService
  ) {
    this.communicationSuscription = _compoComunicationService.saveButtonCommunication$.subscribe(
      saveDataButton => { if (!!saveDataButton && saveDataButton) { this.endProcess(); } }
    );
    this.listScreens = [
      { id: 4, title: "Terceros", name: "terceros" },
      { id: 5, title: "Infomación Complementaria", name: "infoAdicional" }
    ];
  }

  async ngOnInit() {
    this.updateList = [];
    this.instanceId = "";
    this.taskId = this._activatedRoute.parent.snapshot.paramMap.get("taskId") || '';
    await this.getTaskInfo();
    await this.getSolicitudSor();
  }

  ngOnDestroy() {
    if (!!this.formChangesSuscriptor) {
      this.formChangesSuscriptor.unsubscribe();
    }
  }

  ngAfterViewInit() {
    const inputList = ([].slice.call((<HTMLElement>this._el.nativeElement).getElementsByTagName('input'))).concat([].slice.call((<HTMLElement>this._el.nativeElement).getElementsByTagName('textarea')));
    setScrolIntoView(inputList);
  }

  /**
   * Metodo para obtener la data previa en SOR
   */
  async getSolicitudSor() {
    this.showLoading(true);
    try {
      await this.getProcessData();
      if (!!this.instanceId) {
        const solicitudRq = new Solicitud;
        solicitudRq.idSolicitud = this.instanceId;
        const solicitudRs = await this._solicitudService.getSolicitud(solicitudRq);
        if (!!solicitudRs && !!solicitudRs.datosSolicitud) {
          this.dataSolicitud = JSON.parse(solicitudRs.datosSolicitud);
          await this.getRuleParticipants();
          this.formUpdateData = new FormGroup(this.createForm());
          this.updateForm(this.dataSolicitud.clienteJuridico.datosActualizacionPantallas);
          this.setValidators();
          this.formChangesSuscriptor = this.formUpdateData.valueChanges.subscribe(() => {
            this.dataSolicitud.clienteJuridico.datosActualizacionPantallas = this.formUpdateData.value;
          });
          this.listScreens.forEach(screen => {
            if (this.formUpdateData.get(screen.name).value === "no") {
              this.storeScreens(screen.name);
            }
          });
          this.updateSidebar();
        }
      } else { this.showErrorModal(true); }
    } catch (error) { this.showErrorModal(false); }
    this.showLoading(false);
  }

  /**
   * Metodo para crear las propiedades del formgroup
   * a partir de un modelo datos
   */
  createForm() {
    const pantallasDataModel = new DatosActualizacionPantallas();
    this.propertiesForm = Object.getOwnPropertyNames(pantallasDataModel);
    const object = {};
    this.propertiesForm.forEach((item) => {
      object[item] = new FormControl(pantallasDataModel[item]);
    });
    return object;
  }

  /**
   * Actualiza el formulario con la data obtenida en SOR
   * @param datosActualizacionPantallas corresponden a los datos financieros de la solicitud
   */
  updateForm(datosActualizacionPantallas: DatosActualizacionPantallas) {
    if (!(!!datosActualizacionPantallas)) {
      datosActualizacionPantallas = new DatosActualizacionPantallas();
    }
    this.formUpdateData.setValue(datosActualizacionPantallas);
  }

  /**
   * Metodo para establecer las validaciones correctas del formulario
   */
  setValidators() {
    this.listScreens.forEach(screen => {
      this.formUpdateData.get(screen.name).setValidators(Validators.required);
      this.formUpdateData.get(screen.name).updateValueAndValidity();
    });
  }

  /**
   * Metodo para obtener los datos del proceso, en
   * este caso el id de la instancia
   */
  async getProcessData() {
    await this.getTaskInfo();
    if (!(!!this.instanceId)) { this.showErrorModal(true); }
  }

  /**
   * Metodo para obtener los datos de la tarea
   */
  async getTaskInfo() {
    const taskModelRq = new GetTaskByIdRequest();
    taskModelRq.taskId = this.taskId;
    const getTaskInfoRs = await this._bpmService.getTaskInfo(taskModelRq);
    if (!!getTaskInfoRs) {
      this.instanceId = getTaskInfoRs.processInstanceId;
    } else { this.instanceId = null; }
  }

  /**
   * Metodo para enviar objeto a la barra lateral con el fin de que se actualice
   * segun la informacion procesada
   */
  async updateSidebar() {
    if (!!this.instanceId) {
      if (!!this.dataSolicitud) {
        const dataPage = {
          "currentPage": this.CONST_FORMULARIO_ACTUALIZACION,
          "dataSolicitud": this.dataSolicitud
        };
        this._compoComunicationService.emmitSideBarEvent(dataPage);
      }
    }
  }

  /**
   * Metodo para guardar la solicitud en SOR
   * @param value Valor de decision para finalizar tarea
   */
  async saveDataSor(value: boolean) {
    this.showLoading(true);
    await this.getTaskInfo();
    if (!!this.instanceId) {
      const solicitudSorRq = new Solicitud();
      solicitudSorRq.idSolicitud = this.instanceId;
      solicitudSorRq.setDatosSolicitud(this.dataSolicitud);
      const saveResult = await this._solicitudService.saveSolicitud(solicitudSorRq);
      if (!!saveResult) {
        if (value) { await this.finishTask(); }
      } else { this.showErrorModal(false); }
    } else { this.showErrorModal(true); }
    this.showLoading(false);
  }

  /**
   * Metodo para finalizar la tarea actual
   */
  async finishTask() {
    const variableBPM = { "skipUpdate": { "value": this.updateList.join("-") } };
    const request = new FinishTaskRequest();
    request.taskId = this.taskId;
    request.variable = variableBPM;
    const finishTaskRs = await this._bpmService.finishTask(request);
    if (!!finishTaskRs) {
      const processInstanceRq = new ProcessInstanceRequest();
      processInstanceRq.processInstanceId = this.instanceId;
      const getNextTaskRs = await this._bpmService.getNextTask(processInstanceRq);
      if (!!getNextTaskRs && getNextTaskRs.length > 0) {
        const body = new ClaimTaskRequest();
        body.idTask = getNextTaskRs[0].id;
        const claimTask = await this._bpmService.getClaimTask(body);
        if (!!claimTask) {
          this.showLoading(false);
          this.redirectExternalUrl(claimTask.path);
        } else { this.showErrorModal(false); }
      } else { this.redirectUrl('/portal/'); }
    } else { this.showErrorModal(false); }
  }

  /**
   * Metodo para navegar a una url externa
   * @param url Valor que representa la ruta a tomar
   */
  async redirectUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      this._router.navigate(['/externalRedirect', { externalUrl: domain }], {
        skipLocationChange: true,
      });
    }
  }

  /**
   * Metodo para navegar al login como url externa
   * @param url Valor que representa la ruta a tomar
   */
  redirectExternalUrl(url: string) {
    if (!!url) {
      let domain = window.location.origin;
      domain = domain.concat(url);
      window.open(domain, '_self');
    }
  }

  /**
   * Metodo para validar los archivos adjuntos en el formulario
   */
  validateSubmit() {
    return !!this.formUpdateData && this.formUpdateData.valid;
  }

  /**
   * Metodo que se encarga de guardar en SOR y finalizar la tarea
   */
  async submit() { await this.saveDataSor(true); }

  /**
   * Metodo para finalizar el proceso
   */
  async endProcess() {
    await this.saveDataSor(false);
    await this.redirectUrl('/portal/');
  }

  /**
   * Metodo para mostrar el error con la opcion de redirigir
   * a la bandeja de tareas
   */
  async showErrorModal(redirectLogin: boolean) {
    const errorData = {
      'showErrorModal': true,
      'redirectLogin': redirectLogin
    };
    this._compoComunicationService.emmitError(errorData);
  }

  /**
   * Metodo para controlar el componente de loading desde la pagina de buscar
   * componente
   * @param value si es verdadero muestra el loading no lo muestra en caso
   * contrario
   */
  showLoading(value: boolean) {
    this._compoComunicationService.emmitLoading(value);
  }

  /**
   * Metodo para almacenar las pantallas
   * que se actualizaran en un array
   */
  storeScreens(value: string) { this.updateList.push(value); }

  /**
   * Metodo para eliminar las pantallas
   * que se actualizaran en un array
   */
  deleteScreens(value: string) {
    const element = this.updateList.indexOf(value);
    if (element !== -1) { this.updateList.splice(element, 1); }
  }

  /**
   * Metodo para consultar la regla de enrutamiento de acuerdo
   * al camino a seguir segun el riesgo del cliente
   */
  async getRuleParticipants() {
    try {
      if (!!this.dataSolicitud.clienteJuridico.datosContacto) {
        const enrutamientoRq = mappingEnrutamiento(this.dataSolicitud.clienteJuridico.datosContacto);
        const enrutamientoRs = await this._bpmService.callBPMRule(enrutamientoRq);
        if (!!enrutamientoRs && enrutamientoRs.length > 0) {
          const participants = enrutamientoRs[0].respuestaPantalla.value.split("-");
          participants.forEach((participant: string) => {
            switch (participant) {
              case "representanteLegal":
                this.listScreens.push({ id: 1, title: "Representante Legal", name: participant });
                break;
              case "ordenantes":
                this.listScreens.push({ id: 2, title: "Ordenantes - Autorizados", name: participant });
                break;
              case "accionistas":
                this.listScreens.push({ id: 3, title: "Accionistas", name: participant });
                break;
            }
          });
          this.listScreens.sort((a, b) => a.id - b.id);
        }
      }
    } catch (error) { this.showErrorModal(false); }
  }

}
