import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UpdateFormComponent } from './update-form.component';
import { Routes, RouterModule } from '@angular/router';
import { ComponentsModule } from 'src/app/components/components.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AuthGuardService as AuthGuard } from '../../shared/services/auth-guard.service';
import { SharedModule } from 'src/app/shared/shared.module';
import { MaterialModule } from '../../material/material.module';

const routes: Routes = [
  { path: '', component: UpdateFormComponent, canActivate: [AuthGuard] }
];

@NgModule({
  declarations: [UpdateFormComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ComponentsModule,
    SharedModule,
    MaterialModule,
    RouterModule.forChild(routes)
  ]
})
export class UpdateFormModule { }
