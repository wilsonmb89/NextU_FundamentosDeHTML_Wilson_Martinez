import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ComponentCommunicationService {

  // Observable sources
  private sideBarCommunicationSource = new Subject<any>();
  private saveButtonCommunicationSource = new Subject<any>();
  private loadingCommunicationSource = new Subject<any>();
  private errorCommunicationSource = new Subject<any>();

  // Observable streams
  sideBarCommunication$ = this.sideBarCommunicationSource.asObservable();
  saveButtonCommunication$ = this.saveButtonCommunicationSource.asObservable();
  loadingCommunication$ = this.loadingCommunicationSource.asObservable();
  errorCommunication$ = this.errorCommunicationSource.asObservable();

  /**
   * Metodo para comunicacion del sidebar
   * @param sideBarData informacion para el sidebar
   */
  emmitSideBarEvent(sideBarData: any) {
    this.sideBarCommunicationSource.next(sideBarData);
  }

  /**
   * Metodo para comunicacion del boton de guardar de la barra lateral
   * @param saveButtonData informacion para el sidebar
   */
  emmitsaveButton(saveButtonData: any) {
    this.saveButtonCommunicationSource.next(saveButtonData);
  }

  /**
   * Metodo para comunicacion del boton de guardar de la barra lateral
   * @param loadingData informacion para el sidebar
   */
  emmitLoading(loadingData: any) {
    this.loadingCommunicationSource.next(loadingData);
  }

  /**
   * Metodo para mostrar el mensaje de error en la pantalla
   * @param errorData informacion para el modal de error
   */
  emmitError(errorData: any) {
    this.errorCommunicationSource.next(errorData);
  }

  constructor() { }

}
