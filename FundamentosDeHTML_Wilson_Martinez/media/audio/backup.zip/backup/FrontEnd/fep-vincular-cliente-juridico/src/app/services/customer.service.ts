import { Injectable } from '@angular/core';
import { HttpClientService } from '../shared/services/http-client.service';
import { NgxLoggerService } from '../shared/services/ngx-logger.service';
import { PATH_API_CLIENTE } from '../utils/constants/servicePath.constant';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(
    private _httpClientService: HttpClientService,
    private _logger: NgxLoggerService
  ) { }

  /**
   * Metodo para realizar la consulta del cliente de BUC en api-cliente
   * @param body Parametro que incluye los valores de entrada para la
   * consulta del cliente
   */
  searchCustomer(body) {
    return this._httpClientService.invokePostRequest(PATH_API_CLIENTE.GET_CUSTOMER, body).then(
      res => {
        this._logger.log("CustomerService: searchCustomer", res);
        return res;
      },
      error => null
    );
  }

  saveCustomer(body) {
    return this._httpClientService.invokePostRequest(PATH_API_CLIENTE.GRAPH_QL, body).then(
      res => {
        this._logger.log("CustomerService: saveCustomer", res);
        return true;
      },
      error => null
    );
  }

  getCustomer(body) {
    return this._httpClientService.invokePostRequest(PATH_API_CLIENTE.GRAPH_QL, body).then(
      res => {
        this._logger.log("CustomerService: getCustomer", res);
        return res;
      },
      error => null
    );
  }
}
