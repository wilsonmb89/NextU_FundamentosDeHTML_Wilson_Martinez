import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-general-error',
  templateUrl: './general-error.component.html',
  styleUrls: ['./general-error.component.scss']
})
export class GeneralErrorComponent implements OnInit {

  @Output()
  closeButtonEmit = new EventEmitter<boolean>();

  constructor() { }

  ngOnInit() {
  }

  /**
   * Metodo que emite el evento para cerrar la ventana con
   * un valor booleano false
   */
  emitCloseEvent() {
    this.closeButtonEmit.emit(false);
  }
}
