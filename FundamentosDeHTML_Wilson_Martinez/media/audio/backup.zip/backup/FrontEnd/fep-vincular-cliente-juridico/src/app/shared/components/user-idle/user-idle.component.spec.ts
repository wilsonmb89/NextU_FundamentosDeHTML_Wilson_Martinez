import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserIdleComponent } from './user-idle.component';
import { NgIdleModule } from '@ng-idle/core';
import { RouterTestingModule } from '@angular/router/testing';
import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';
import { HttpClientModule } from '@angular/common/http';

describe('UserIdleComponent', () => {
  let component: UserIdleComponent;
  let fixture: ComponentFixture<UserIdleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserIdleComponent ],
      imports: [
        NgIdleModule.forRoot(),
        RouterTestingModule,
        LoggerModule.forRoot({level: NgxLoggerLevel.DEBUG, serverLogLevel: NgxLoggerLevel.ERROR}),
        HttpClientModule
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserIdleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('handleIdle', () => {
    const data = {
      accion: 'START_IDLE',
      valor: '12'
    };
    component.handleIdle(data);
  });

  it('handleIdle', () => {
    const data = {
      accion: 'STILL_IDLE',
      valor: '12'
    };
    component.handleIdle(data);
  });

  it('handleIdle', () => {
    const data = {
      accion: 'ABORT_IDLE',
      valor: '12'
    };
    component.handleIdle(data);
  });

  it('handleIdle', () => {
    const data = {
      accion: 'TIMEOUT',
      valor: '12'
    };
    component.handleIdle(data);
  });

  it('handleIdle', () => {
    const data = null;
    component.handleIdle(data);
  });

  it('closeModal', () => {
    component.closeModal();
  });
});
