import { Component, OnInit, ChangeDetectorRef, OnDestroy } from '@angular/core';
import { NgIdleService } from '../../services/ng-idle.service';
import { Router } from '@angular/router';
import { ChangeDetectionStrategy } from '@angular/core';
import { NgxLoggerService } from '../../services/ngx-logger.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-user-idle',
  templateUrl: './user-idle.component.html',
  styleUrls: ['./user-idle.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class UserIdleComponent implements OnInit, OnDestroy {

  idleMessage = "";
  counterMins = "00";
  counterSecs = "00";
  modalTitle = "La sesión va a expirar";
  showIdleModal = false;
  idleSusbription: Subscription;

  constructor(
    private _idleService: NgIdleService,
    private _router: Router,
    private _logger: NgxLoggerService,
    private _changeDetector: ChangeDetectorRef
  ) {
    this.idleSusbription = _idleService.idleHandler().subscribe(
      data => {
        this.handleIdle(data);
      },
      error => {
        this._logger.logError('UserIdleComponent', error);
      },
      () => {
        this._logger.log('UserIdleComponent', 'Suscribe finish');
      }
    );
  }

  ngOnInit() {
  }

  ngOnDestroy() {
    if (!!this.idleSusbription) {
      this.idleSusbription.unsubscribe();
    }
  }

  /**
   * Metodo para controlar los eventos disparados por la libreria
   * ng-idle en para el control de la inactividad
   * @param data objeto que contiene una llave valor para detectar el tipo
   * de evento y su valor
   */
  handleIdle(data) {
    try {
      const accion = data.accion;
      const valor = data.valor;
      switch (accion) {
        case 'START_IDLE':
          this.showIdleModal = true;
          break;
        case 'STILL_IDLE':
          this.setIdleMessage(parseInt(valor));
          break;
        case 'ABORT_IDLE':
          this.showIdleModal = false;
          break;
        case 'TIMEOUT':
          this.closeSession();
          break;
        default:
          break;
      }
      this._changeDetector.detectChanges();
    } catch (e) {
      this._logger.logError('UserIdleComponent', e);
    }
  }

  /**
   * Metodo para formar el mensaje que se muestra en el timeout de la
   * inactividad
   * @param countDown Segundos faltantes para mostrar en el dialogo
   */
  setIdleMessage(countDown) {
    try {
      const minutes = Math.floor(countDown / 60);
      const seconds = countDown - minutes * 60;
      this.counterMins = (minutes < 10 ? "0" + minutes : minutes) + "";
      this.counterSecs = (seconds < 10 ? "0" + seconds : seconds) + "";
      const minutesIdle = Math.round(this._idleService.timeIdle / 60);
      this.idleMessage = `No hemos detectado actividad en los últimos ${minutesIdle} minutos, tu sesión se cerrará automáticamente en`;
    } catch (e) {
      this.idleMessage = `No hemos detectado actividad en los últimos minutos, tu sesión se cerrará automáticamente`;
    }
  }

  /**
   * Metodo para eliminar el token y realizar un routing a la
   * pantalla de login
   */
  closeSession() {
    try {
      localStorage.removeItem('token');
      document.cookie = "Authorization=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
      this.redirectLogin();
    } catch (error) {
      this._router.navigate(['/externalRedirect', { externalUrl: '/portal/' }], {
        skipLocationChange: true,
      });
    }
  }

  /**
   * Metodo para cambiar la variable que controla la visibilidad
   * del modal
   */
  closeModal() {
    this.showIdleModal = false;
    this._changeDetector.markForCheck();
  }

  /**
   * Metodo forzado sincrono para enrutar al login y en caso de un error por
   * no encontrar la ruta, enviarlo a la pagina externa del login
   */
  async redirectLogin() {
    try {
      await this._router.navigate(["login"]);
    } catch (error) {
      await this._router.navigate(['/externalRedirect', { externalUrl: '/portal/' }], {
        skipLocationChange: true,
      });
    }
  }
}
