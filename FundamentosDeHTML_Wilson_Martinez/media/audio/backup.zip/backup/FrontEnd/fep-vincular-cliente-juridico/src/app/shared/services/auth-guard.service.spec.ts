import { TestBed } from '@angular/core/testing';

import { AuthGuardService } from './auth-guard.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('AuthGuardService', () => {
  let authGuardService: AuthGuardService;
  beforeEach(
    () => {
      TestBed.configureTestingModule({
        providers: [AuthGuardService],
        imports: [RouterTestingModule]
      });
      authGuardService = TestBed.get(AuthGuardService);
    }
  );

  it('Deberia ser creado', () => {
    expect(authGuardService).toBeTruthy();
  });

  it('canActivate', () => {
    authGuardService.canActivate();
  });
});
