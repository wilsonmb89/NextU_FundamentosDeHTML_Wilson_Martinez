import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {

  constructor(
      public _router: Router
  ) {}

  canActivate(): boolean {
      let activateResponse = false;
      if (!!localStorage.getItem("token")) {
          activateResponse = true;
      } else {
        this.redirectLogin();
      }
      return activateResponse;
  }

  /**
   * Metodo forzado sincrono para enrutar al login y en caso de un error por
   * no encontrar la ruta, enviarlo a la pagina externa del login
   */
  async redirectLogin() {
    try {
      await this._router.navigate(["login"]);
    } catch (error) {
      await this._router.navigate(['/externalRedirect', { externalUrl: '/portal/' }], {
        skipLocationChange: true,
      });
    }
  }
}
