import { TestBed } from '@angular/core/testing';

import { BpmService } from './bpm.service';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';

describe('BpmService', () => {
  let bpmService: BpmService;
  beforeEach(
    () => {
      TestBed.configureTestingModule({
        providers: [BpmService],
        imports: [
          RouterTestingModule,
          HttpClientTestingModule,
          LoggerModule.forRoot({ level: NgxLoggerLevel.DEBUG, serverLogLevel: NgxLoggerLevel.ERROR })
        ]
      });
      bpmService = TestBed.get(BpmService);
    }
  );

  it('Deberia ser creado', () => {
    expect(bpmService).toBeTruthy();
  });

  it('getExposedProcessByUser', () => {
    expect(bpmService.getExposedProcessByUser).toBeTruthy();
  });

  it('getExposedProcessByUser', () => {
    expect(bpmService.getExposedProcessByUser());
  });

  it('getExposedProcessByUser', () => {
    const body = {};
    expect(bpmService.getExposedTasksByUser(body));
  });

  it('getNextTask', () => {
    const body = {};
    expect(bpmService.getNextTask(body));
  });

  it('getClaimTask', () => {
    const body = {};
    expect(bpmService.getClaimTask(body));
  });

  it('startProcessInstance', () => {
    const body = {
      data: ''
    };
    bpmService.startProcessInstance(body);
  });

  it('finishTask', () => {
    const body = {
      data: ''
    };
    bpmService.finishTask(body);
  });

  it('clearInterval', () => {
    expect(bpmService.clearInterval());
  });

  it('getTaskInfo', () => {
    const body = {
      data: ''
    };
    expect(bpmService.getTaskInfo(body));
  });

  it('upsertProcessVariables', () => {
    const body = {
      data: ''
    };
    expect(bpmService.upsertProcessVariables(body));
  });
});
