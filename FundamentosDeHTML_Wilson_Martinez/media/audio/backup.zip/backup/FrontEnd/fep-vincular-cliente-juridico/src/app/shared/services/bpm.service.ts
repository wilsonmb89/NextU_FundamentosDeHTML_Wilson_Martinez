import { Injectable } from '@angular/core';
import { HttpClientService } from './http-client.service';
import { NgxLoggerService } from './ngx-logger.service';
import { PATH_API_BPM } from '../utils/constants/servicePath.constant';

@Injectable({
  providedIn: 'root'
})
export class BpmService {

  timeInterval: any;

  constructor(
    private _httpClientService: HttpClientService,
    private _logger: NgxLoggerService
  ) { }

  /**
   * Metodo para limpiar el interval de la suscripcion de
   * getTasksList
   */
  clearInterval() {
    if (!!this.timeInterval) {
      clearInterval(this.timeInterval);
    }
  }

  /**
   * Metodo para obtener los procesos expuestos por el usuario
   * tomado desde el token en backend
   */
  getExposedProcessByUser() {
    return this._httpClientService.invokePostRequest(PATH_API_BPM.GET_EXP_PROCESS, null).then(
      res => {
        this._logger.log('BpmService: getExposedProcessByUser', res);
        return res;
      },
      error => null
    );
  }

  /**
   * Metodo para obtener las tareas asignadas a un usuario
   * tomado desde el token en backend
   */
  getExposedTasksByUser(body) {
    return this._httpClientService.invokePostRequest(PATH_API_BPM.GET_EXP_TASKS, body).then(
      res => {
        this._logger.log('BpmService: getExposedTasksByUser', res);
        return res;
      },
      error => null
    );
  }


  /**
   * Metodo para inicar el proceso
   * @param body es el objeto json que contiene el id de la instancia
   */
  startProcessInstance(body) {
    return this._httpClientService.invokePostRequest(PATH_API_BPM.START_PROCESS, body).then(
      res => {
        this._logger.log('BpmService: startProcessInstance', res);
        return res;
      },
      error => null
    );
  }

  /**
   * Metodo para inicar el proceso
   * @param body es el objeto json que contiene el id de la instancia
   */
  startProcessService(body) {
    return this._httpClientService.invokePostRequest(PATH_API_BPM.START_SERVICE, body).then(
      res => {
        this._logger.log('BpmService: startProcessService', res);
        return res;
      },
      error => null
    );
  }

  /**
   * Metodo que redirecciona a la nueva tarea
   * @param body es el objeto json que contiene el id de la instancia
   */
  getNextTask(body) {
    return this._httpClientService.invokePostRequest(PATH_API_BPM.GET_NEXT_TASK, body).then(
      res => {
        this._logger.log('BpmService: nextTask', res);
        return res;
      },
      error => null
    );
  }

  /**
   * Metodo que redirecciona a la nueva tarea
   * @param body es el objeto json que contiene el id de la instancia
   */
  getClaimTask(body) {
    return this._httpClientService.invokePostRequest(PATH_API_BPM.GET_CLAIM_TASK, body).then(
      res => {
        this._logger.log('BpmService: ClaimTask', res);
        return res;
      },
      error => null
    );
  }

  /**
   * Metodo que finaliza una tarea en el BPM Camunda
   * @param body es el objeto json que contiene el id de la instancia
   * y un objeto para almacenar en el camunda
   */
  finishTask(body) {
    return this._httpClientService.invokePostRequest(PATH_API_BPM.FINISH_TASK, body).then(
      res => {
        this._logger.log('BpmService: finishTask', res);
        return true;
      },
      error => false
    );
  }

  /**
   * Metodo para obtener la informacion detallada de una tarea a partir del id
   * de la misma
   * @param body es el objeto json que contiene el ID de la tarea a consultar
   */
  getTaskInfo(body) {
    return this._httpClientService.invokePostRequest(PATH_API_BPM.GET_TASK_INFO, body).then(
      res => {
        this._logger.log('BpmService: getTaskInfo', res);
        return res;
      },
      error => null
    );
  }

  /**
   * Metodo para anadir o actualizar alguna variable del proceso
   * @param body objeto json que contiene las variables a adicionar o actualizar en
   * el proceso
   */
  upsertProcessVariables(body) {
    return this._httpClientService.invokePostRequest(PATH_API_BPM.UPSERT_PROCESS_VARIABLES, body).then(
      res => {
        this._logger.log('BpmService: upsertProcessVariables', res);
        return res;
      },
      error => null
    );
  }

  /**
   * Metodo para enviar datos para la regla de decision de documentos requeridos
   * @param body objeto json que contiene las variables relacionadas con la regla
   */
  callBPMRule(body) {
    return this._httpClientService.invokePostRequest(PATH_API_BPM.DECISION_RULE, body).then(
      res => {
        this._logger.log('BpmService: callBPMRule - ' + body.decisionId, res);
        return res;
      },
      error => null
    );
  }

  /**
   * Metodo para obtener una variable del proceso
   * @param body objeto json que contiene la informacion relacionada con la
   * variable a obtener contiene el id de la instancia y el nombre de la variable
   * a obtener
   */
  getProcessVariable(body) {
    return this._httpClientService.invokePostRequest(PATH_API_BPM.GET_PROCESS_VARIABLE, body).then(
      res => {
        this._logger.log('BpmService: getProcessVariable', res);
        return res;
      },
      error => null
    );
  }

  /**
   * Metodo para consultar un perfil de usuario de camunda
   * @param body objeto JSON que contiene la informacion con la cual buscar el perfil
   * de un usuario de camunda
   */
  getUserData(body) {
    return this._httpClientService.invokePostRequest(PATH_API_BPM.GET_USER_DATA, body).then(
      res => {
        this._logger.log('BpmService: getUserData', res);
        return res;
      },
      error => null
    );
  }
}
