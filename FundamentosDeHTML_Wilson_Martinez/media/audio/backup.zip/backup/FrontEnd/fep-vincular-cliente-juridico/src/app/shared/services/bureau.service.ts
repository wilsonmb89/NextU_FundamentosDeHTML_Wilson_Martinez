import { Injectable } from '@angular/core';
import { HttpClientService } from './http-client.service';
import { NgxLoggerService } from './ngx-logger.service';
import { PATH_API_BUREAU } from '../utils/constants/servicePath.constant';

@Injectable({
  providedIn: 'root'
})
export class BureauService {

  constructor(
    private _httpClientService: HttpClientService,
    private _logger: NgxLoggerService
  ) { }

  /**
   * Metodo para consultar riesgo del cliente a partir del
   * servicio de stradata ubicado en api-bureau
   * @param body Canonico de entrada para el microservicio api-bureau
   */
  getStradata(body) {
    return this._httpClientService.invokePostRequest(PATH_API_BUREAU.GET_STRADATA, body).then(
      res => {
        this._logger.log("BureauService: getStradata", res);
        return res;
      },
      error => null
    );
  }

  /**
   * Metodo para consultar riesgo una lista de participantes a partir del
   * servicio de stradata ubicado en api-bureau
   * @param body Canonico de entrada para el microservicio api-bureau
   */
  getStradataList(body) {
    return this._httpClientService.invokePostRequest(PATH_API_BUREAU.GET_STRADATA_LIST, body).then(
      res => {
        this._logger.log("BureauService: getStradataList", res);
        return res;
      },
      error => null
    );
  }
}
