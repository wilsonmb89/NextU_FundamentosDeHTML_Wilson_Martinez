import { TestBed, async } from '@angular/core/testing';

import { CatalogoService } from './catalogo.service';
import { RouterTestingModule } from '@angular/router/testing';
import { NgIdleModule } from '@ng-idle/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('CatalogoService', () => {

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
      ],
      imports: [
        RouterTestingModule,
        NgIdleModule.forRoot(),
        HttpClientTestingModule,
        LoggerModule.forRoot({ level: NgxLoggerLevel.DEBUG, serverLogLevel: NgxLoggerLevel.ERROR })
      ],
      schemas: [NO_ERRORS_SCHEMA],
    })
      .compileComponents();
  }));

  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CatalogoService = TestBed.get(CatalogoService);
    expect(service).toBeTruthy();
  });

  it('getCatalog', () => {
    const service: CatalogoService = TestBed.get(CatalogoService);
    const body = {};
    expect(service.getCatalog(body));
  });
});
