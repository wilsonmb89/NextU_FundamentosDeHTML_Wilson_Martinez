import { Injectable } from '@angular/core';
import { HttpClientService } from './http-client.service';
import { NgxLoggerService } from './ngx-logger.service';
import { PATH_API_CATALOGO } from '../utils/constants/servicePath.constant';

@Injectable({
  providedIn: 'root'
})
export class CatalogoService {

  constructor(
    private _httpClientService: HttpClientService,
    private _logger: NgxLoggerService
  ) { }

  /**
   * Metodo para obtener el catalogo por un nombre de catalogo
   * embebido en un body
   * @param body parametro que contiene el nombre del catalogo
   */
  getCatalog(body) {
    return this._httpClientService.invokePostRequest(PATH_API_CATALOGO.GET_CATALOG, body).then(
      res => {
        this._logger.log('CatalogoService: getCatalog', res);
        return res;
      },
      error => null
    );
  }
}
