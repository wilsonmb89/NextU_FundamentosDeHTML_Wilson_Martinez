import { Injectable } from '@angular/core';
import { HttpClientService } from './http-client.service';
import { NgxLoggerService } from './ngx-logger.service';
import { PATH_API_COMUNICACIONES } from '../utils/constants/servicePath.constant';

@Injectable({
  providedIn: 'root'
})
export class ComunicationService {

  constructor(
    private _httpClientService: HttpClientService,
    private _logger: NgxLoggerService
  ) { }

  /**
   * Metodo para enviar al correo notificacion de rechazo
   * @param body es el objeto que contiene
   */
  sendEmail(body: any) {
    return this._httpClientService.invokePostRequest(PATH_API_COMUNICACIONES.SEND_EMAIL, body).then(
      res => {
        this._logger.log('ComunicationService: sendEmail', res);
        return true;
      },
      error => null
    );
  }

}
