import { TestBed } from '@angular/core/testing';

import { CreateFilesService } from './create-files.service';

describe('CreateFilesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CreateFilesService = TestBed.get(CreateFilesService);
    expect(service).toBeTruthy();
  });
});
