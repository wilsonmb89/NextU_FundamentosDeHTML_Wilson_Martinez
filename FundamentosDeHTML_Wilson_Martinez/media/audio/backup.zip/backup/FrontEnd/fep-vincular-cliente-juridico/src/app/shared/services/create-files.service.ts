import { Injectable } from '@angular/core';
import { HttpClientService } from './http-client.service';
import { NgxLoggerService } from './ngx-logger.service';
import { PATH_API_FORMATOS } from '../utils/constants/servicePath.constant';

@Injectable({
  providedIn: 'root'
})
export class CreateFilesService {

  constructor(
    private _httpClientService: HttpClientService,
    private _logger: NgxLoggerService
  ) { }

  /**
   * Metodo para generar archivos PDF
   * @param body es el objeto que contiene
   */
  async createPDF(body: any) {
    try {
      const res = await this._httpClientService.invokePostRequest(PATH_API_FORMATOS.GENERAR_FORMATO_VINCULACION, body);
      this._logger.log('CreateFilesService: createPDF', res);
      return res;
    } catch (error) {
      return null;
    }
  }

}
