import { Injectable } from '@angular/core';
import { HttpClientService } from './http-client.service';
import { NgxLoggerService } from './ngx-logger.service';
import { PATH_API_DOCUMENTOS } from '../utils/constants/servicePath.constant';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DocumentService {

  constructor(
    private _httpClientService: HttpClientService,
    private _logger: NgxLoggerService
  ) { }

  /**
   * Metodo para realizar la cargra de documentos del cliente en api-documentos
   * @param body Parametro que incluye los valores de entrada para la
   * carga de documentos del cliente
   */
  uploadDocument(body) {
    const headers = new HttpHeaders().append('Disabled-Content-Type', '');
    const options = { headers: headers };
    return this._httpClientService.invokePostRequest(PATH_API_DOCUMENTOS.UPLOAD_DOCUMENT, body, options).then(
      res => {
        this._logger.log("DocumentService: uploadDocument", res);
        return true;
      },
      error => null
    );
  }

  /**
   * Metodo para realizar el escaneo del un documento del participante
   * @param body objeto que contiene los datos relacionados con el documento a analizar y subir
   */
  uploadMultipartDocId(body) {
    const headers = new HttpHeaders().append('Disabled-Content-Type', '');
    const options = { headers: headers };
    return this._httpClientService.invokePostRequest(PATH_API_DOCUMENTOS.SCAN_UPLOAD_DOCUMENT, body, options).then(
      res => {
        this._logger.log("DocumentService: uploadMultipartDocId", res);
        return res;
      },
      error => null
    );
  }

  /**
   * Metodo para consultar el documento del cliente en api-documentos
   * @param body Parametro que incluye los valores de entrada para la
   * consulta de documentos del cliente
   */
  getDocument(body) {
    const options = { responseType: "arraybuffer" };
    return this._httpClientService.invokePostRequest(PATH_API_DOCUMENTOS.GET_DOCUMENT, body, options).then(
      res => {
        this._logger.log("DocumentService: getDocument", res);
        return res;
      },
      error => null
    );
  }

  /**
   * Metodo para eliminar un documento del cliente en api-documentos
   * @param body Parametro que incluye los valores de entrada para la
   * consulta de documentos del cliente y su posterior eliminacion
   */
  deleteDocument(body) {
    return this._httpClientService.invokePostRequest(PATH_API_DOCUMENTOS.DELETE_DOCUMENT, body).then(
      res => {
        this._logger.log("DocumentService: deleteDocument", res);
        return true;
      },
      error => null
    );
  }

  /**
   * Metodo para obtener lo documentos de un path
   * @param body Parametro que incluye los valores de entrada para la
   * consulta de documentos del cliente
   */
  getDocumentsByPath(body) {
    return this._httpClientService.invokePostRequest(PATH_API_DOCUMENTOS.GET_DOCUMENTS_BY_PATH, body).then(
      res => {
        this._logger.log("DocumentService: getDocumentsByPath", res);
        return res;
      },
      error => null
    );
  }


}
