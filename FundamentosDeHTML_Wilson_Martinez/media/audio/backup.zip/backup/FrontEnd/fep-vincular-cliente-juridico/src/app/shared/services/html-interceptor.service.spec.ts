import { TestBed } from '@angular/core/testing';

import { HtmlInterceptorService } from './html-interceptor.service';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';

describe('HtmlInterceptorService', () => {
  let htmlInterceptorService;
  beforeEach(
    () => {
      TestBed.configureTestingModule({
        providers: [
          HtmlInterceptorService
        ],
        imports: [
          RouterTestingModule,
          HttpClientModule
        ]
      });
      htmlInterceptorService = TestBed.get(HtmlInterceptorService);
    }
  );

  it('Deberia ser creado', () => {
    expect(htmlInterceptorService).toBeTruthy();
  });
});
