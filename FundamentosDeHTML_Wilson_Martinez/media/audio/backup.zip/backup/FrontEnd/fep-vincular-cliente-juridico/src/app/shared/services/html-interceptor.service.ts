import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpInterceptor
} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HtmlInterceptorService implements HttpInterceptor {

  /**
   * Metodo para interceptar una peticion http, en donde se agrega el token
   * y el content-type a las peticiones realizadas
   * @param req Request de la peticion interceptada
   * @param next Manejador de las peticiones http
   */
  intercept(req: HttpRequest<any>, next: HttpHandler) {
    if (!!localStorage.getItem("token")) {
      req = req.clone({ headers: req.headers.set('Authorization', localStorage.getItem('token')) });
    }

    if (!req.headers.has('Content-Type') && !req.headers.has("Disabled-Content-Type")) {
      req = req.clone({ headers: req.headers.set('Content-Type', 'application/json') });
    }

    return next.handle(req);
  }
}
