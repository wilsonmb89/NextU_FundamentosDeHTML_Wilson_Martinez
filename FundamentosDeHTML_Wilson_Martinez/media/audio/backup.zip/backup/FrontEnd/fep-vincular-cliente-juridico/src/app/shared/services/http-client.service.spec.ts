import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { HttpClientService } from './http-client.service';
import { RouterTestingModule } from '@angular/router/testing';

describe('HttpClientService', () => {
  let httpClientService;
  beforeEach(
    () => {
      TestBed.configureTestingModule({
        providers: [
          HttpClientService
        ],
        imports: [
          RouterTestingModule,
          HttpClientTestingModule
        ]
      });
      httpClientService = TestBed.get(HttpClientService);
    }
  );

  it('Deberia ser creado', () => {
    expect(httpClientService).toBeTruthy();
  });

  it('invokeGetRequest', () => {
    expect(httpClientService.invokeGetRequest('', '', '', true, true));
  });

  it('invokePutRequest', () => {
    expect(httpClientService.invokePutRequest('', '', true, true));
  });

  it('invokeDeleteRequest', () => {
    expect(httpClientService.invokeDeleteRequest('', '', true, true));
  });

  it('retryRequest', () => {
    expect(httpClientService.retryRequest('', '', '', '', 1, 1, true));
  });
});
