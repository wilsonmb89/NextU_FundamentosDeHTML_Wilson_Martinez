import { Injectable } from '@angular/core';
import { Router } from "@angular/router";
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { map, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class HttpClientService {

    constructor(
        public router: Router,
        public _http: HttpClient
    ) { }

    /**
     * Construye y ejecuta un request de tipo POST y retorna una Promesa.
     * @name invokePostRequest
     * @example
     *
     * // Sin headers:
     * invokePostRequest('http://localhost/', body);
     * // Con headers:
     * const headers = new HttpHeaders().append('Content-Type', 'application/pdf');
     * const options = {
     *      responseType: "arraybuffer",
     *      headers: headers
     * };
     * invokePostRequest('http://localhost/', body, options);
     *
     * @return a `Promise<any>`
     **/
    invokePostRequest(url: string, body: any, options?: any, retry?: boolean, returnBody?: boolean) {
        return this.sendPostRequest(url, body, options, 0, 0, retry, returnBody);
    }

    private sendPostRequest(url: string, body: any, options: any, intentos: number,
        timer: number, retry?: boolean, returnBody?: boolean) {

        const res = this._http.post(url, body, options);
        return this.validateResponse(url, body, options, intentos, timer, "post", res, retry, returnBody);
    }


    /**
     * Construye y ejecuta un request de tipo GET y retorna una Promesa.
     * @name invokeGetRequest
     * @example
     *
     * // Sin headers:
     * invokeGetRequest('http://localhost/');
     * // Con headers:
     * let params = new HttpParams().set('logNamespace', logNamespace);
     * let headers = new HttpHeaders().append('Content-Type', 'application/xml');
     * const options = {
     *      headers: headers,
     *      params: params
     * };
     * invokeGetRequest('http://localhost/', options);
     *
     * @return a `Promise<any>`
     **/
    invokeGetRequest(url: string, options?: any, retry?: boolean, returnBody?: boolean) {

        return this.sendGetRequest(url, options, 0, 0, retry, returnBody);
    }

    private sendGetRequest(url: string, options: any, intentos: number, timer: number, retry?: boolean, returnBody?: boolean) {

        const res = this._http.get(url, options);
        return this.validateResponse(url, null, options, intentos, timer, "get", res, retry, returnBody);
    }


    /**
     * Construye y ejecuta un request de tipo PUT y retorna una Promesa.
     * @name invokePutRequest
     * @example
     *
     * // Sin headers:
     * invokePutRequest('http://localhost/', body);
     * // Con headers:
     * let headers = new HttpHeaders().append('Content-Type', 'application/xml');
     * const options = {
     *      headers: headers,
     * };
     * invokePutRequest('http://localhost/', body, options);
     *
     * @return a `Promise<any>`
     **/
    invokePutRequest(url: string, body: any, options?: any, retry?: boolean, returnBody?: boolean) {

        return this.sendPutRequest(url, body, options, 0, 0, retry, returnBody);
    }

    private sendPutRequest(url: string, body: any, options: any, intentos: number, timer: number, retry?: boolean, returnBody?: boolean) {

        const res = this._http.put(url, body, options);
        return this.validateResponse(url, body, options, intentos, timer, "put", res, retry, returnBody);
    }


    /**
     * Construye y ejecuta un request de tipo DELETE y retorna una Promesa.
     * @name invokeDeleteRequest
     * @example
     *
     * // Sin headers:
     * invokeDeleteRequest('http://localhost/');
     * // Con headers:
     * let headers = new HttpHeaders().append('Content-Type', 'application/xml');
     * const options = {
     *      headers: headers,
     * };
     * invokeDeleteRequest('http://localhost/', options);
     *
     * @return a `Promise<any>`
     **/
    invokeDeleteRequest(url: string, options?: any, retry?: boolean, returnBody?: boolean) {
        return this.sendDeleteRequest(url, options, 0, 0, retry, returnBody);
    }

    private sendDeleteRequest(url: string, options: any, intentos: number, timer: number, retry?: boolean, returnBody?: boolean) {

        const res = this._http.delete(url, options);
        return this.validateResponse(url, null, options, intentos, timer, "delete", res, retry, returnBody);
    }

    private validateResponse(url: string, body: any, options: any, intentos: number,
        timer: number, requestType: string, res: Observable<any>, retry?: boolean, returnBody?: boolean): Promise<any> {

        return res.pipe(
            map(
                httpResponse => {
                    if (!!httpResponse) {
                        if (!!httpResponse.header) {
                            if (Number(httpResponse.header.status) !== 200) {
                                if (retry) {
                                    this.retryRequest(url, body, options, requestType, intentos, timer, returnBody);
                                }
                            }
                        }
                    }
                    return this.returnResponse(httpResponse, returnBody);
                }
            ),
            catchError(
                httpResponse => {
                    return throwError(this.returnResponse(httpResponse, returnBody));
                }
            )
        ).toPromise();
    }

    /**
     * Metodo para retornar el response de la peticion o solo el body de esta
     * @param httpResponse respuesta de la peticion
     * @param returnBody flag para determinar si se retorna solo el body
     */
    private returnResponse(httpResponse: any, returnBody: boolean): string {
        return returnBody ? httpResponse.body : httpResponse;
    }

    private retryRequest(url: string, body: any, options: any, requestType: string, intentos: number, timer: number, returnBody?: boolean) {
        intentos += 1;
        console.log("Reintentando request ... intento: ".concat(intentos.toString()));
        if (intentos < 3) {
            const segundos = Number(intentos) * Number(15);
            timer = segundos;
            setTimeout(() => {

                switch (requestType) {
                    case "get":
                        this.sendGetRequest(url, options, intentos, timer, true, returnBody);
                        break;
                    case "post":
                        this.sendPostRequest(url, body, options, intentos, timer, true, returnBody);
                        break;
                    case "put":
                        this.sendPutRequest(url, body, options, intentos, timer, true, returnBody);
                        break;
                    case "delete":
                        this.sendDeleteRequest(url, options, intentos, timer, true, returnBody);
                        break;
                    default:
                        break;
                }
            }, segundos * 1000);
            const intervalError = setInterval(() => {
                timer = timer - 1;
                if (timer < 2) {
                    clearInterval(intervalError);
                }
            }, 1000);
        }
    }
}
