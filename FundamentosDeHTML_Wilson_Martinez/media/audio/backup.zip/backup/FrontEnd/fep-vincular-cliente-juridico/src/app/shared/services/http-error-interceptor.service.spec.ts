import { TestBed } from '@angular/core/testing';

import { HttpErrorInterceptorService } from './http-error-interceptor.service';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';

describe('HttpErrorInterceptorService', () => {
  let httpErrorInterceptorService: HttpErrorInterceptorService;
  beforeEach(
    () => {
      TestBed.configureTestingModule({
        providers: [
          HttpErrorInterceptorService
        ],
        imports: [
          RouterTestingModule,
          HttpClientModule,
          LoggerModule.forRoot({level: NgxLoggerLevel.DEBUG, serverLogLevel: NgxLoggerLevel.ERROR})
        ]
      });
      httpErrorInterceptorService = TestBed.get(HttpErrorInterceptorService);
    }
  );

  it('Deberia ser creado', () => {
    expect(httpErrorInterceptorService).toBeTruthy();
  });

  it('redirectLogin', () => {
    expect(httpErrorInterceptorService.redirectLogin());
  });
});
