import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpErrorResponse } from '@angular/common/http';
import { tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { NgxLoggerService } from './ngx-logger.service';

@Injectable({
  providedIn: 'root'
})
export class HttpErrorInterceptorService implements HttpInterceptor {

  constructor(
    private _router: Router,
    private _logger: NgxLoggerService
  ) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(tap(
        (event: any) => {},
        (err: any) => {
        if (err instanceof HttpErrorResponse) {
          this._logger.logError("HttpErrorInterceptorService", err);
          if (Number(err.status) === 401) {
            this.logOut();
          }
        }
      })
    );
  }

  private logOut() {
    this._logger.logDebug("HttpErrorInterceptorService", "Usuario no autorizado. Redirigiendo a login ...");

    if (this._router.url !== "/login") {
      try {
        localStorage.removeItem("token");
        this.redirectLogin();
      } catch (err) {
        this._router.navigate(['/externalRedirect', { externalUrl: '/portal/' }], {
          skipLocationChange: true
        });
      }
    }
  }

  /**
   * Metodo forzado sincrono para enrutar al login y en caso de un error por
   * no encontrar la ruta, enviarlo a la pagina externa del login
   */
  async redirectLogin() {
    try {
      await this._router.navigate(["login"]);
    } catch (error) {
      await this._router.navigate(['/externalRedirect', { externalUrl: '/portal/' }], {
        skipLocationChange: true,
      });
    }
  }
}
