import { TestBed } from '@angular/core/testing';

import { NgIdleService } from './ng-idle.service';
import { RouterTestingModule } from '@angular/router/testing';
import { NgIdleModule } from '@ng-idle/core';

describe('NgIdleService', () => {
  let ngIdleService: NgIdleService;
  beforeEach(
    () => {
      TestBed.configureTestingModule({
        providers: [NgIdleService],
        imports: [
          RouterTestingModule,
          NgIdleModule.forRoot()
        ]
      });
      ngIdleService = TestBed.get(NgIdleService);
    }
  );

  it('Deberia ser creado', () => {
    expect(ngIdleService).toBeTruthy();
  });

  it('should be created', () => {
    expect(ngIdleService.idleHandler()).toBeTruthy();
  });
});
