import { Injectable } from '@angular/core';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { getTokenValue } from 'src/app/utils/functions/tokenUtils';
import { Observable, merge } from 'rxjs';
import { mapTo, map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class NgIdleService {

  // Se configuran los tiempos respectivos para la inactividad
  timeIdle = parseInt(getTokenValue('timeIdleFront')) || 720;
  timeOut = parseInt(getTokenValue('timeOutFront')) || 180;

  constructor(
    private _idle: Idle
  ) {
    // sets an idle timeout.
    _idle.setIdle(this.timeIdle);
    // sets a timeout period.
    _idle.setTimeout(this.timeOut);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    _idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
  }

  /**
   * Metodo para iniciar el listener de la inactividad
   */
  reset() {
    this._idle.watch();
  }

  /**
   * Controlador de cada uno de los eventos de la inactividad
   * donde se envía un objeto por cada evento
   */
  idleHandler(): Observable<any> {
    const handler = merge(
      this._idle.onIdleEnd.pipe(mapTo({ "accion" : "ABORT_IDLE", "valor" : "" })),
      this._idle.onTimeout.pipe(mapTo({ "accion" : "TIMEOUT", "valor" : "" })),
      this._idle.onIdleStart.pipe(mapTo({ "accion" : "START_IDLE", "valor" : "" })),
      this._idle.onTimeoutWarning.pipe(
          map(
            (countdown) => {
              return  { "accion" : "STILL_IDLE", "valor" : countdown };
            }
          )
        )
    );
    if (!this._idle.isRunning()) {
      this.reset();
    }
    return handler;
  }
}
