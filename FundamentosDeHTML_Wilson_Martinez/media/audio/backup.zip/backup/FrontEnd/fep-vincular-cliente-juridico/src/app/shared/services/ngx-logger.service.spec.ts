import { TestBed } from '@angular/core/testing';

import { NgxLoggerService } from './ngx-logger.service';
import { HttpClientModule } from '@angular/common/http';
import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';

describe('NgxLoggerService', () => {
  let ngxLoggerService: NgxLoggerService;
  beforeEach(
    () => {
      TestBed.configureTestingModule({
        providers: [
          NgxLoggerService
        ],
        imports: [
          HttpClientModule,
          LoggerModule.forRoot({level: NgxLoggerLevel.DEBUG, serverLogLevel: NgxLoggerLevel.ERROR})
        ]
      });
      ngxLoggerService = TestBed.get(NgxLoggerService);
    }
  );

  it('Deberia ser creado', () => {
    expect(ngxLoggerService).toBeTruthy();
  });

  it('logDebug', () => {
    expect(ngxLoggerService.logDebug('', ''));
  });

  it('logInfo', () => {
    expect(ngxLoggerService.logInfo('', ''));
  });

  it('log', () => {
    expect(ngxLoggerService.log('', ''));
  });
});
