import { Injectable } from '@angular/core';
import { NGXLogger } from 'ngx-logger';
import { getTokenValue } from 'src/app/utils/functions/tokenUtils';

@Injectable({
  providedIn: 'root'
})
export class NgxLoggerService {

  private usuario = "";

  constructor(
    private _logger: NGXLogger
  ) { }

  /**
   * Metodo para registrar un mensaje de error en el log
   * @param origin Clase fuente del mensaje
   * @param errorMessage mensaje de error
   */
  logError(origin, errorMessage) {
    this._logger.error("- Usuario: " + this.getLogUser(), "- Origen: " + origin, "-", errorMessage);
  }

  /**
   * Metodo para registrar un mensaje de debug en el log
   * @param origin Clase fuente del mensaje
   * @param debugMessage mensaje de debug
   */
  logDebug(origin, debugMessage) {
    this._logger.debug("- Usuario: " + this.getLogUser(), "- Origen: " + origin, "-", debugMessage);
  }

  /**
   * Metodo para registrar un mensaje de informacion en el log
   * @param origin Clase fuente del mensaje
   * @param infoMessage mensaje de informacion
   */
  logInfo(origin, infoMessage) {
    this._logger.info("- Usuario: " + this.getLogUser(), "- Origen: " + origin, "-", infoMessage);
  }

  /**
   * Metodo para registrar un mensaje
   * @param origin Clase fuente del mensaje
   * @param logMessage mensaje
   */
  log(origin, logMessage) {
    this._logger.log("- Usuario: " + this.getLogUser(), "- Origen: " + origin, "-", logMessage);
  }

  /**
   * Metodo para obtener el usuario registrado a partir del token generado
   */
  getLogUser(): string {
    return getTokenValue("userName");
  }
}
