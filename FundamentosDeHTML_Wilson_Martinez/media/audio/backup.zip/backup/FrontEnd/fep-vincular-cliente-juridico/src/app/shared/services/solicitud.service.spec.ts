import { TestBed } from '@angular/core/testing';

import { SolicitudService } from './solicitud.service';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientModule } from '@angular/common/http';
import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';

describe('SolicitudService', () => {
  let solicitudService: SolicitudService;
  beforeEach(
    () => {
      TestBed.configureTestingModule({
        providers: [SolicitudService],
        imports: [
          RouterTestingModule,
          HttpClientModule,
          LoggerModule.forRoot({ level: NgxLoggerLevel.DEBUG, serverLogLevel: NgxLoggerLevel.ERROR })
        ]
      });
      solicitudService = TestBed.get(SolicitudService);
    }
  );

  it('Deberia ser creado', () => {
    expect(solicitudService).toBeTruthy();
  });

  it('saveSolicitud', () => {
    const body = {};
    expect(solicitudService.saveSolicitud(body));
  });

  it('getSolicitud', () => {
    const body = {};
    expect(solicitudService.getSolicitud(body));
  });
});
