import { Injectable } from '@angular/core';
import { HttpClientService } from './http-client.service';
import { NgxLoggerService } from './ngx-logger.service';
import { PATH_API_SOLICITUD } from '../utils/constants/servicePath.constant';

@Injectable({
  providedIn: 'root'
})
export class SolicitudService {

  constructor(
    private _httpClientService: HttpClientService,
    private _logger: NgxLoggerService
  ) { }

  /**
   * Metodo para guardar o actualizar una solicitud en sor
   * @param body parametro que corresponde a la entrada de la operacion
   */
  saveSolicitud(body) {
    return this._httpClientService.invokePostRequest(PATH_API_SOLICITUD.UPSERT, body).then(
      res => {
        this._logger.log("SolicitudService: saveSolicitud", res);
        return res;
      },
      error => {
        return null;
      }
    );
  }

  /**
   * Metodo para consultar una solicitud en SOR por ID de instancia
   * @param body objeto JSON que contiene el id de la solicitud a buscar
   */
  getSolicitud(body) {
    return this._httpClientService.invokePostRequest(PATH_API_SOLICITUD.FIND_BY_ID, body).then(
      res => {
        this._logger.log("SolicitudService: getSolicitud", res);
        return res;
      },
      error => {
        return null;
      }
    );
  }
}
