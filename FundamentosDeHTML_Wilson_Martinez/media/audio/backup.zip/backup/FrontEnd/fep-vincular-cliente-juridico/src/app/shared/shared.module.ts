// Modules
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedRoutingModule } from './shared-routing.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';
import { NgIdleModule } from '@ng-idle/core';

// Pipes
import { FormatTextPipe } from './utils/pipes/format-text.pipe';
import { FormatAddressPipe } from './utils/pipes/format-address.pipe';
import { CurrencyMoneyPipe } from './utils/pipes/currency-money.pipe';

// Directives
import { OnlyNumbersDirective } from './utils/directives/only-numbers.directive';
import { AddessNormalizeDirective } from './utils/directives/addess-normalize.directive';
import { TextCapitalizeDirective } from './utils/directives/text-capitalize.directive';
import { TextUppercaseDirective } from './utils/directives/text-uppercase.directive';
import { TextLowercaseDirective } from './utils/directives/text-lowercase.directive';
import { AddressValidatorDirective } from './utils/directives/address-validator.directive';
import { OnlyLettersDirective } from './utils/directives/only-letters.directive';
import { AlphanumericDirective } from './utils/directives/alphanumeric.directive';

// Services
import { AuthGuardService } from './services/auth-guard.service';
import { HttpClientService } from './services/http-client.service';
import { NgxLoggerService } from './services/ngx-logger.service';
import { HtmlInterceptorService } from './services/html-interceptor.service';
import { HttpErrorInterceptorService } from './services/http-error-interceptor.service';
import { NgIdleService } from './services/ng-idle.service';
import { BpmService } from './services/bpm.service';
import { SolicitudService } from './services/solicitud.service';
import { CatalogoService } from './services/catalogo.service';
import { ComunicationService } from './services/comunication.service';
import { CreateFilesService } from './services/create-files.service';
import { BureauService } from './services/bureau.service';

// Components
import { LoadingComponent } from './components/modals/loading/loading.component';
import { UserIdleComponent } from './components/user-idle/user-idle.component';
import { GeneralErrorComponent } from './components/modals/general-error/general-error.component';
import { DragDropDirectiveDirective } from './directives/drag-and-drop.directive';

@NgModule({
  declarations: [
    LoadingComponent,
    UserIdleComponent,
    GeneralErrorComponent,
    FormatTextPipe,
    FormatAddressPipe,
    OnlyNumbersDirective,
    AddessNormalizeDirective,
    TextCapitalizeDirective,
    TextUppercaseDirective,
    TextLowercaseDirective,
    AddressValidatorDirective,
    CurrencyMoneyPipe,
    OnlyLettersDirective,
    AlphanumericDirective,
    DragDropDirectiveDirective
  ],
  imports: [
    CommonModule,
    SharedRoutingModule,
    HttpClientModule,
    LoggerModule.forRoot({level: NgxLoggerLevel.DEBUG, serverLogLevel: NgxLoggerLevel.ERROR}),
    NgIdleModule.forRoot()
  ],
  providers: [
    AuthGuardService,
    HttpClientService,
    NgxLoggerService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HtmlInterceptorService,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpErrorInterceptorService,
      multi: true
    },
    NgIdleService,
    BpmService,
    BureauService,
    SolicitudService,
    CatalogoService,
    ComunicationService,
    CreateFilesService,
    FormatTextPipe,
    FormatAddressPipe,
    OnlyNumbersDirective,
    AddessNormalizeDirective,
    TextCapitalizeDirective,
    TextUppercaseDirective,
    TextLowercaseDirective,
    AddressValidatorDirective
  ],
  exports: [
    UserIdleComponent,
    LoadingComponent,
    GeneralErrorComponent,
    FormatTextPipe,
    FormatAddressPipe,
    OnlyNumbersDirective,
    AddessNormalizeDirective,
    TextCapitalizeDirective,
    TextUppercaseDirective,
    TextLowercaseDirective,
    AddressValidatorDirective,
    CurrencyMoneyPipe,
    OnlyLettersDirective,
    AlphanumericDirective,
    DragDropDirectiveDirective
  ]
})
export class SharedModule { }
