import { environment } from 'src/environments/environment';

export const PATH_API_BPM = {
    DECISION_RULE: environment.API_GATEWAY.concat('/bpm/dmn/desicion/rule'),
    GET_EXP_PROCESS: environment.API_GATEWAY.concat('/bpm/process/getExposedProcess'),
    GET_EXP_TASKS: environment.API_GATEWAY.concat('/bpm/task/getAssignedTask'),
    START_PROCESS: environment.API_GATEWAY.concat('/bpm/process/startProcessInstance'),
    GET_NEXT_TASK: environment.API_GATEWAY.concat('/bpm/task/getNextTask'),
    GET_CLAIM_TASK: environment.API_GATEWAY.concat('/bpm/task/claimTask'),
    FINISH_TASK: environment.API_GATEWAY.concat('/bpm/task/finishTask'),
    GET_TASK_INFO: environment.API_GATEWAY.concat('/bpm/task/getTaskById'),
    UPSERT_PROCESS_VARIABLES: environment.API_GATEWAY.concat('/bpm/process/createUpdateProcessVariables'),
    GET_PROCESS_VARIABLE: environment.API_GATEWAY.concat('/bpm/process/getProcessVariable'),
    GET_USER_DATA: environment.API_GATEWAY.concat('/bpm/user/getUserProfile'),
    START_SERVICE: environment.API_GATEWAY.concat('/bpm/service/claimService'),
};

export const PATH_API_SOLICITUD = {
    UPSERT: environment.API_GATEWAY.concat('/solicitud/createUpdate'),
    FIND_BY_ID: environment.API_GATEWAY.concat('/solicitud/findById')
};

export const PATH_API_CATALOGO = {
    GET_CATALOG: environment.API_GATEWAY.concat('/catalogo/getCatalog')
};

export const PATH_API_COMUNICACIONES = {
    SEND_EMAIL: environment.API_GATEWAY.concat('/comunicaciones/email/sendEmail')
};

export const PATH_API_FORMATOS = {
    GENERAR_FORMATO_VINCULACION: environment.API_GATEWAY.concat('/reports/getPDF')
};

export const PATH_API_BUREAU = {
    GET_STRADATA: environment.API_GATEWAY.concat('/bureau/listasriesgo/estradata'),
    GET_STRADATA_LIST: environment.API_GATEWAY.concat('/bureau/listasriesgo/consultaestradata')
};

export const PATH_API_DOCUMENTOS = {
    UPLOAD_DOCUMENT: environment.API_GATEWAY.concat('/document/docmanagment/uploadMultipart'),
    SCAN_UPLOAD_DOCUMENT: environment.API_GATEWAY.concat('/document/docmanagment/uploadMultipartDocId'),
    GET_DOCUMENT: environment.API_GATEWAY.concat('/document/docmanagment/getBytes'),
    DELETE_DOCUMENT: environment.API_GATEWAY.concat('/document/docmanagment/delete'),
    GET_DOCUMENTS_BY_PATH: environment.API_GATEWAY.concat('/document/docmanagment/getListsDocNames'),
};
