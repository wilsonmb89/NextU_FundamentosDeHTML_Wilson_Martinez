import { AddessNormalizeDirective } from './addess-normalize.directive';

describe('AddessNormalizeDirective', () => {
  it('should create an instance', () => {
    const elRefMock = {
      nativeElement: document.createElement('div').setAttribute('type', 'text')
    };
    const directive = new AddessNormalizeDirective(elRefMock);
    expect(directive).toBeTruthy();
  });
});
