import { Directive, ElementRef, HostListener } from '@angular/core';
import { ValidAddress } from '../functions/ValidAddress';

@Directive({
  selector: '[addressNormalize]'
})
export class AddessNormalizeDirective {
  public validAddress = new ValidAddress();

  constructor(private _el: ElementRef) { }

  @HostListener('blur', ['$event']) onblur(event) {
      const initalValue = this._el.nativeElement.value;

      this._el.nativeElement.value = this.validAddress.validacionDireccion(initalValue);

      if (initalValue !== this._el.nativeElement.value) {
        event.stopPropagation();
      }
  }
}
