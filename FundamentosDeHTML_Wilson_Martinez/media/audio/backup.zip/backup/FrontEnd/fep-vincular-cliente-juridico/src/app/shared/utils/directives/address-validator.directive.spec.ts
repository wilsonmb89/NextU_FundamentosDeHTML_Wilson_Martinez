import { AddressValidatorDirective } from './address-validator.directive';

describe('AddressValidatorDirective', () => {
  it('should create an instance', () => {
    const directive = new AddressValidatorDirective();
    expect(directive).toBeTruthy();
  });
});
