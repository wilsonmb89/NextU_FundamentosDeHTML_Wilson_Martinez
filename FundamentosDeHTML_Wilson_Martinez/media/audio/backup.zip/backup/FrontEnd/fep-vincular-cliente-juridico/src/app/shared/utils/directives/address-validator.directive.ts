import { NG_VALIDATORS, FormControl, ValidatorFn } from '@angular/forms';
import { Directive } from '@angular/core';
import { ADRESSES } from '../constants/utils.constant';

@Directive({
  selector: '[addressComparison][ngModel]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: AddressValidatorDirective,
      multi: true
    }
  ]
})
export class AddressValidatorDirective {
  validator: ValidatorFn;

  constructor() { this.validator = this.addressComparison(); }

  validate(c: FormControl) { return this.validator(c); }

  addressComparison(): ValidatorFn {
    return (c: FormControl) => {
      if (!!c.value) {
        const arrayAddress = c.value.split(" ");
        for (let i = 0; i < arrayAddress.length; i++) {
          let element = arrayAddress[0].toUpperCase();
          element = element.normalize('NFD').replace(/([aeio])\u0301|(u)[\u0301\u0308]/gi, "$1$2").normalize();
          if (ADRESSES.indexOf(element) !== -1) {
            const onlyLettersNumbers = new RegExp(/^[A-Za-z0-9\s]+$/g);
            if (onlyLettersNumbers.test(c.value)) { return null; }
          } else {
            return { addressComparison: { valid: false } };
          }
        }
      }
    };
  }
}
