import { Directive, HostListener, ElementRef } from '@angular/core';
import { replaceOnlyAlphanumeric } from '../functions/transform';

@Directive({
  selector: '[onlyAlphanumeric]'
})
export class AlphanumericDirective {

  constructor(
    private _elementRef: ElementRef
  ) { }

  @HostListener('keydown', ['$event'])
  onKeyDown(e: KeyboardEvent) {
    if (
      // Allow: Delete, Backspace, Tab, Escape, Enter, Space
      [46, 8, 9, 27, 13, 32].indexOf(e.keyCode) !== -1 ||
      (e.keyCode === 65 && e.ctrlKey === true) || // Allow: Ctrl+A
      (e.keyCode === 67 && e.ctrlKey === true) || // Allow: Ctrl+C
      (e.keyCode === 86 && e.ctrlKey === true) || // Allow: Ctrl+V
      (e.keyCode === 88 && e.ctrlKey === true) || // Allow: Ctrl+X
      (e.keyCode === 65 && e.metaKey === true) || // Cmd+A (Mac)
      (e.keyCode === 67 && e.metaKey === true) || // Cmd+C (Mac)
      (e.keyCode === 86 && e.metaKey === true) || // Cmd+V (Mac)
      (e.keyCode === 88 && e.metaKey === true) || // Cmd+X (Mac)
      (e.keyCode >= 35 && e.keyCode <= 39) // Home, End, Left, Right
    ) {
      return;  // let it happen, don't do anything
    }

    if (!(/[0-9a-zA-Z\sñ]/g).test(e.key)) {
      e.preventDefault();
    }
  }

  @HostListener('paste', ['$event'])
  onPaste(event: ClipboardEvent) {
    event.preventDefault();
    const pastedInput: string = replaceOnlyAlphanumeric(event.clipboardData.getData('text/plain'));
    document.execCommand('insertText', false, pastedInput);
  }

  @HostListener('drop', ['$event'])
  onDrop(event: DragEvent) {
    event.preventDefault();
    const textData = replaceOnlyAlphanumeric(event.dataTransfer.getData('text'));
    document.execCommand('insertText', false, textData);
  }

  @HostListener('input', ['$event']) onInputChange(event) {
    const initalValue = this._elementRef.nativeElement.value;
    this._elementRef.nativeElement.value = replaceOnlyAlphanumeric(initalValue);
    if (initalValue !== this._elementRef.nativeElement.value) {
      event.stopPropagation();
    }
  }
}
