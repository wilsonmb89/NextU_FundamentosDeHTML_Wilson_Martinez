import { OnlyLettersDirective } from './only-letters.directive';

describe('OnlyLettersDirective', () => {
  it('should create an instance', () => {
    const directive = new OnlyLettersDirective();
    expect(directive).toBeTruthy();
  });
});
