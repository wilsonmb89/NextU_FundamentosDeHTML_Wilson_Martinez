import { OnlyNumbersDirective } from './only-numbers.directive';
import { TestBed } from '@angular/core/testing';

describe('OnlyNumbersDirective', () => {
  it('should create an instance', () => {
    const elRefMock = {
      nativeElement: document.createElement('div')
    };
    const directive = new OnlyNumbersDirective(elRefMock);
    expect(directive).toBeTruthy();
  });
});
