import { TextCapitalizeDirective } from './text-capitalize.directive';

describe('TextCapitalizeDirective', () => {
  // it('should create an instance', () => {
  //   const directive = new TextCapitalizeDirective();
  //   expect(directive).toBeTruthy();
  // });
});
