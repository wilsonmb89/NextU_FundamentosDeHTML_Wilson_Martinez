import { Directive, ElementRef, HostListener } from '@angular/core';
import { FormatTextPipe } from '../pipes/format-text.pipe';

@Directive({
  selector: '[textCapitalize]'
})
export class TextCapitalizeDirective {

  public _formattextPipe = new FormatTextPipe();

  constructor(private _el: ElementRef) { }

  @HostListener('blur', ['$event']) onblur(event) {
    const initalValue = this._el.nativeElement.value;

    this._el.nativeElement.value = this._formattextPipe.transform(initalValue, 'cap');

    if (initalValue !== this._el.nativeElement.value) {
      event.stopPropagation();
    }
  }
  @HostListener('keyup', ['$event']) keyUp(event) {
    const initalValue = this._el.nativeElement.value;

    this._el.nativeElement.value = this._formattextPipe.transform(initalValue, 'cap');

    if (initalValue !== this._el.nativeElement.value) {
      event.stopPropagation();
    }
  }

}
