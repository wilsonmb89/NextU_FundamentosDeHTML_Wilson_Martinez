import { TextLowercaseDirective } from './text-lowercase.directive';

describe('TextLowercaseDirective', () => {
  // it('should create an instance', () => {
  //   const directive = new TextLowercaseDirective();
  //   expect(directive).toBeTruthy();
  // });
});
