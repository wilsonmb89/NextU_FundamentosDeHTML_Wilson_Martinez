import { TextUppercaseDirective } from './text-uppercase.directive';

describe('TextUppercaseDirective', () => {
  // it('should create an instance', () => {
  //   const directive = new TextUppercaseDirective();
  //   expect(directive).toBeTruthy();
  // });
});
