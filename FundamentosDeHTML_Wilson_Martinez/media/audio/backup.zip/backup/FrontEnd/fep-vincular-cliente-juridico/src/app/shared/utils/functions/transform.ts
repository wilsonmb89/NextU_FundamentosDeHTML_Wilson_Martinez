export function replaceOnlyNumbers(val) {
  let result = "";
  try {
    result = val.replace(/[^0-9]*/g, '');
  } catch (err) {
    result = "";
  }
  return result;
}

export function replaceOnlyLetters(val) {
  let result = "";
  try {
    result = val.replace(/[^a-zA-ZÀ-ÿ\u00f1\u00d1\s]*/g, '');
  } catch (err) {
    result = "";
  }
  return result;
}

export function replaceOnlyAlphanumeric(val) {
  let result = "";
  try {
    result = val.replace(/[^0-9a-zA-Z\sñ]*/g, '');
  } catch (err) {
    result = "";
  }
  return result;
}

export function capitalizeText(val) {
  let result = "";
  try {
    result = val.replace(/(?:^|\s)\S/g, function (a) { return a.toUpperCase(); });
  } catch (error) {
    result = val;
  }
  return result;
}

export function convertBase64(file: File) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => {
      resolve(reader.result);
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export function base64ToBlob(b64Data: string, contentType = 'application/octet-stream', sliceSize = 512) {
  const byteCharacters = atob(b64Data);
  const byteArrays = [];
  for (let offset = 0; offset < byteCharacters.length; offset += sliceSize) {
    const slice = byteCharacters.slice(offset, offset + sliceSize);
    const byteNumbers = new Array(slice.length);
    for (let i = 0; i < slice.length; i++) {
      byteNumbers[i] = slice.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);
    byteArrays.push(byteArray);
  }
  const blob = new Blob(byteArrays, { type: contentType });
  return blob;
}

/**
 * Metodo para descargar el PDF
 * @param body
 * @param filename
 * @param extension
 */
export function createAndDownloadBlobFile(body, filename, extension = 'pdf') {
  const fileName = `${filename}.${extension}`;
  if (navigator.msSaveBlob) {
    // IE 10+
    navigator.msSaveBlob(body, fileName);
  } else {
    const link = document.createElement('a');
    // Browsers that support HTML5 download attribute
    if (link.download !== undefined) {
      const url = URL.createObjectURL(body);
      link.setAttribute('href', url);
      link.setAttribute('download', fileName);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  }
}
