/**
 * Metodo para descargar un documento en el navegador
 * @param fileName nombre del documento
 * @param base64File archivo en base 64, debe incluir el encabezado 'data:application/pdf;base64,'
 */
export function downloadFile(fileName: string, base64File: string) {
	const element = document.createElement('a');
	element.setAttribute('href', base64File);
	element.setAttribute('download', fileName);
	element.style.display = 'none';
	document.body.appendChild(element);
	element.click();
	document.body.removeChild(element);
}

export function setScrolIntoView(inputList: []) {
	if (!!inputList) {
		inputList.forEach((input: HTMLElement) => {
			input.addEventListener('focus', () => {
				scrollIntoElement(input);
			});
			input.addEventListener('blur', () => {
				scrollIntoElement(input);
			});
		});
	}
}

/**
 * Metodo para navegar hacia un elemento DOM en el navegador
 * mediante el scroll
 * @param domToScroll
 */
export function scrollIntoElement(domToScroll) {
	if (!!domToScroll) {
		domToScroll.scrollIntoView({ block: "center", behavior: "smooth" });
	}
}
