export class CatalogoRequest {
    catalogName: string;
    idParent: string;
    idLike: string;
    nameLike: string;
    ordered: boolean;
}
