export class Email {
    [key: string]: any;
}
