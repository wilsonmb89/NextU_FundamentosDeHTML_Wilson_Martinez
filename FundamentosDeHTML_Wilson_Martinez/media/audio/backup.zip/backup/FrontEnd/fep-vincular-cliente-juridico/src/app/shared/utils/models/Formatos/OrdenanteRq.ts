export class OrdenanteRq {
    numDocumento: string;
    nombreCompleto: string;
}
