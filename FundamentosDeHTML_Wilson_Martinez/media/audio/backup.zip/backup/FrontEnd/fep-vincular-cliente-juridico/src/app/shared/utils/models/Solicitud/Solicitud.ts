export class Solicitud {
    idSolicitud: string;
    datosSolicitud: string;

    setDatosSolicitud(datosSolicitud) {
        this.datosSolicitud = (!!datosSolicitud) ? JSON.stringify(datosSolicitud) : "";
    }
}
