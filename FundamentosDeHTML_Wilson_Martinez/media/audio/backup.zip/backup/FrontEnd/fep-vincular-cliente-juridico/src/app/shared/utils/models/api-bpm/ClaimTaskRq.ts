export class ClaimTaskRequest {
    idTask: string;
}
