export class ClientRequest {
    tipoIdentificacion: string;
    identificacion: string;
}
