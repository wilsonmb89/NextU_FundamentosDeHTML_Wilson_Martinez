export class FinishTaskRequest {
    taskId: string;
    variable?: any;
}
