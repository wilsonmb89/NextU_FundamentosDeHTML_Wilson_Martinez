export class GetTaskByIdRequest {
    taskId: string;
}
