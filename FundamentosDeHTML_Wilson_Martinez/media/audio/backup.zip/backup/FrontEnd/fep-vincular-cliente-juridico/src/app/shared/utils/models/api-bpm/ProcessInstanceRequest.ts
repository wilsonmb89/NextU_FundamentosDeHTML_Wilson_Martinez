export class ProcessInstanceRequest {
    processInstanceId: string;
}
