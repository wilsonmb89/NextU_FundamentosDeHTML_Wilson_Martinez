export class CreateUpdateProcessVariablesRequest {
    processInstanceId: string;
    variables: any;
}
