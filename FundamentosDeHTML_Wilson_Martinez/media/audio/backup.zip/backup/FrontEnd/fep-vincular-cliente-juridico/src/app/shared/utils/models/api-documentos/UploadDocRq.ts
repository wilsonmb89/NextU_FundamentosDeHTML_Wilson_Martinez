export class UploadDocRq {
    base64File: string;
    documentId: string;
    documentType: string;
    fileName: string;
    metadata: any;
}
