import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'currencyMoney'
})
export class CurrencyMoneyPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    let transform = !!value ? value.toString().replace(/[$.\""]/g, "") : "";
    transform = transform.toString().replace(/(\d)(?=(\d{3})+\b)/g, "$1.");
    return !!transform ? transform : "";
  }
}
