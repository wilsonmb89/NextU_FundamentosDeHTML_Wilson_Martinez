import { FormatAddressPipe } from './format-address.pipe';

describe('FormatAddressPipe', () => {
  it('create an instance', () => {
    const pipe = new FormatAddressPipe();
    expect(pipe).toBeTruthy();
  });
});
