import { Pipe, PipeTransform } from '@angular/core';
import { ValidAddress } from '../functions/ValidAddress';

@Pipe({
  name: 'formatAddress'
})
export class FormatAddressPipe implements PipeTransform {
  public validAddress = new ValidAddress();

  transform(value: any): any {
      return this.validAddress.validacionDireccion(value);
  }
}
