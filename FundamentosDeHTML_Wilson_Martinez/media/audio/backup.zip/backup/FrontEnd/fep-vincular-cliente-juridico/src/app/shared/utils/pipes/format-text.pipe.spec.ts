import { FormatTextPipe } from './format-text.pipe';

describe('FormatTextPipe', () => {
  it('create an instance', () => {
    const pipe = new FormatTextPipe();
    expect(pipe).toBeTruthy();
  });

  it('transform Capitalize', () => {
    const pipe = new FormatTextPipe();
    const value = 'ejemplo';
    const format = 'cap';
    expect(pipe.transform(value, format));
  });

  it('transform Uppercase', () => {
    const pipe = new FormatTextPipe();
    const value = 'ejemplo';
    const format = 'upp';
    expect(pipe.transform(value, format));
  });

  it('transform Lowercase ', () => {
    const pipe = new FormatTextPipe();
    const value = 'ejemplo';
    const format = '';
    expect(pipe.transform(value, format));
  });
});
