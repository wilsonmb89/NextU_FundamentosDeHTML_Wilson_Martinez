import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'formatText'
})
export class FormatTextPipe implements PipeTransform {

  transform(value: string, format: string): any {
    switch (format) {
      case 'cap':
        try {
          value = value.toLowerCase();
          value = value.replace(/(^|\s)[a-z\u00E0-\u00FC]/g, l => l.toUpperCase());
        } catch (err) {
          value = "";
        }
        return value;
      case 'upp':
        try {
          value = value.toUpperCase();
        } catch (err) {
          value = "";
        }
        return value;

      default:
        try {
          value = value.toLowerCase();
        } catch (err) {
          value = "";
        }
        return value;
    }
  }

}
