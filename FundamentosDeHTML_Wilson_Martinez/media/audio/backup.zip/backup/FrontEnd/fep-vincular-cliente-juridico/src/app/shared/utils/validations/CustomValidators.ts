import { ValidatorFn, AbstractControl} from "@angular/forms";

export function valueCatalogValidator(catalogo): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    if (!!catalogo) {
      const validData = catalogo.find(function (obj) { return (obj.name).toUpperCase() === control.value.toUpperCase(); });
      return (!!validData) ? null : { value: false };
    } else {
      return null;
    }
  };
}

export function idValueCatalogValidator(catalogo): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    if (!!catalogo && !!control.value) {
      const validData = catalogo.find(function (obj) { return (obj.id + " - " + obj.name).toUpperCase() === control.value.toUpperCase(); });
      return (!!validData) ? null : { value: false };
    } else {
      return null;
    }
  };
}

export function parentValueCatalogValidator(catalogo): ValidatorFn {
  return (control: AbstractControl): { [key: string]: any } | null => {
    if (!!catalogo && !!control.value) {
      const validData = catalogo.find(function (obj) { return (obj.id + " - " + obj.name + " - " + obj.parent).toUpperCase() === control.value.toUpperCase(); });
      return (!!validData) ? null : { value: false };
    } else {
      return null;
    }
  };
}
