export enum TipoParticipante {
    representanteLegal = 1,
    ordenante,
    autorizado,
    accionista,
    tercero,
}
