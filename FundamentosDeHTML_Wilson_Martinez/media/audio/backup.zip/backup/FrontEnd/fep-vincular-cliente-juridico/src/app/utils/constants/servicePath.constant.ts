import { environment } from '../../../environments/environment';

export const PATH_API_SEGURIDAD = {
    LOGIN : environment.API_GATEWAY.concat('/security/login/loginUser'),
    LOGOUT : environment.API_GATEWAY.concat('/security/login/logoutUser')
};

export const PATH_API_CLIENTE = {
    GET_CUSTOMER : environment.API_GATEWAY.concat('/cliente/clients/getClient'),
    GRAPH_QL : environment.API_GATEWAY.concat('/cliente/graphql')
};

export const PATH_API_BUREAU = {
    GET_BUREAU : environment.API_GATEWAY.concat('/bureau/validarBureau/getBureau'),
    GET_STRADATA : environment.API_GATEWAY.concat('/bureau/listasriesgo/estradata')
};

export const PATH_API_DOCUMENTOS = {
    UPLOAD_DOCUMENT : environment.API_GATEWAY.concat('/document/docmanagment/upload'),
    GET_DOCUMENT : environment.API_GATEWAY.concat('/document/docmanagment/get'),
    DELETE_DOCUMENT: environment.API_GATEWAY.concat('/document/docmanagment/delete')
};
