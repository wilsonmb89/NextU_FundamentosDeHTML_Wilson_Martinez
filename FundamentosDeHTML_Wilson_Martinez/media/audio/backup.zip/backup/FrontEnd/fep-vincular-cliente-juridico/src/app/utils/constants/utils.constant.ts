// Constantes para catalogos
export const CATALOGS_DATA_CUSTOMER = ["Pais", "CIIU", "Ocupacion", "Documento", "EstadoCivil", "Banco", "tipoEntidad", "Comercial"];
export const CATALOGS_SEARCH_CUSTOMER = "TipoDocumento";
export const CATALOGS_DOCUMENT_CUSTOMER = "Documento";

// Constantes para reglas
export const RULE_ID = { DOCUMENTOS_ID: "FiltroDocumentos", ENRUTAMIENTO_ID: "enrutamientoCliente", ENRUTAMIENTO_PJ: "enrutamientoClientePJ"};
export const RULE_DATA_TYPES = { DOUBLE_TYPE: "Double", STRING_TYPE: "String", BOOLEAN_TYPE: "Boolean", VALUE_PARTICIPANT: "CLI" };

// Constantes para Emails
export const EMAIL = { NOTIFY_REVIEW: "NOTIFICACION_REVISION", REJECT_CLIENT: "RECHAZO_CLIENTE", REJECT_APM: "RECHAZO_APM", REJECT_REASON: "Rechazo" };

// Constantes BPM
export const CONST_USER_VAR_BPM = "initiator";
export const CONST_GATEWAY_DEC_VAR_BPM = "decisionGateway";

// Constante para imagen 'vacia' - PDF
export const CONST_IMAGE_DEFAULT = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAIAAACQd1PeAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAAMSURBVBhXY/j//z8ABf4C/qc1gYQAAAAASUVORK5CYII=";

// Constante para documentos generados automaticamente
export const GENERATED_DOCUMENTS = ["Registro firmas", "Vinculación / actualización"];
