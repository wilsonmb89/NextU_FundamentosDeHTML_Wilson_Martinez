/**
 * Metodo para obtener el valor primitivo en String
 * del token guardado de la base de datos
 * @param dataName nombre de la propiedad para generar el valor
 */
export function getTokenValue(dataName): string {
    let value = '';
    const dataToken = localStorage.getItem("token") || "";
    if (!!dataToken) {
      try {
        const jsonData = JSON.parse(atob(dataToken.split('.')[1]));
        value = jsonData[dataName] || '';
      } catch (error) {
        value = '';
      }
    }
    return value;
}
