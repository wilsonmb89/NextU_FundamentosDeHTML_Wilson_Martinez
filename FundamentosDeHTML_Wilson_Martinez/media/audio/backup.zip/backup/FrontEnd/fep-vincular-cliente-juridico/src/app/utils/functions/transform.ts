export function getTipoDocumentoCode(tipoDocName: string) {
  let result = "";
  const tipoDocSwitch = tipoDocName.indexOf('-') !== -1 ? tipoDocName.split("-")[1] : tipoDocName;
  if (!!tipoDocName) {
    switch (tipoDocSwitch) {
      case "Cédula":
        result = "1";
        break;
      case "Sociedad Extranjera":
        result = "6";
        break;
      case "NIT":
        result = "5";
        break;
      /**
      * ToDo Agregar tipos de documentos futuros a hologoar
      */
      default:
        break;
    }
  }
  return result;
}

export function getTipoDocumentoCodaName(tipoDocName: string) {
  let result = "";
  const tipoDocSwitch = tipoDocName.indexOf('-') !== -1 ? tipoDocName.split("-")[1] : tipoDocName;
  if (!!tipoDocName) {
    switch (tipoDocSwitch) {
      case "Cédula":
        result = "1";
        break;
      case "Cédula Extranjería":
        result = "2";
        break;
      case "Sociedad Extranjera":
        result = "6";
        break;
      case "Pasaporte":
        result = "7";
        break;
      case "NIT":
        result = "5";
        break;
      /**
      * ToDo Agregar tipos de documentos futuros a hologoar
      */
      default:
        break;
    }
    result = !!result ? (result + "-" + tipoDocSwitch) : "";
  }
  return result;
}

export function getNombresCalidad(propiedades: any[]) {
  const formatTxt = [];
  propiedades.forEach(propiedad => {
    const txt = propiedad.replace(/([a-z])([A-Z])/g, '$1 $2');
    propiedad = txt.charAt(0).toUpperCase() + txt.slice(1);
    formatTxt.push(propiedad);
  });
  return formatTxt;
}

export function getAcronimoTipoParticipante(tipoParticipante: string) {
  let result = "";
  if (!!tipoParticipante) {
    switch (tipoParticipante) {
      case "Ordenantes":
        result = "ORD";
        break;
      case "Accionistas":
        result = "ACC";
        break;
      case "Representante Legal":
        result = "REP";
        break;
      default:
        break;
    }
  }
  return result;
}
