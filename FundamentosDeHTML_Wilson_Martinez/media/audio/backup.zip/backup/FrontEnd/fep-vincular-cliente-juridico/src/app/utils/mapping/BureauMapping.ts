import { FormGroup } from '@angular/forms';
import { StradataRequest } from '../models/api-bureau/StradataRequest';
import { DatosSolicitud } from '../models/api-solicitud/DatosSolicitud';
import { Participante } from '../models/api-solicitud/Participante';
import { DatosRiesgo } from '../models/api-solicitud/DatosRiesgo';

export function mappingStradata(form: FormGroup, datosSolicitud: DatosSolicitud) {
  const stradataRq = new StradataRequest();
  if (!!form) {
    stradataRq.tipoDoc = datosSolicitud.clienteJuridico.datosGenerales.tipoDocumento.split('-')[0];
    stradataRq.numeroDoc = datosSolicitud.clienteJuridico.datosGenerales.numeroDocumento.replace(/\./g, '');
    stradataRq.nombre = !!form.get('nombre') ? (form.get('nombre').value).toUpperCase() : '';
  }
  return stradataRq;
}

export function mappingStradataFromParticipant(participantList: Array<Participante>) {
  const stradataRq = {};
  if (!!participantList && participantList.length > 0) {
    participantList.forEach(
      (par) => {
        stradataRq[par.numeroDocumento.replace(/\-/g, '').replace(/\./g, '')] = {
          "nombre" : par.nombre.toUpperCase(),
          "tipoDoc" : par.tipoDocumento.split('-')[0],
          "numeroDoc" : par.numeroDocumento.replace(/\./g, '')
        };
      }
    );
  }
  return stradataRq;
}

/**
 * Metodo para crear un canonico de datos risgo a partir del resultado
 * de la consulta de estradata
 * @param riskSummary respuesta del servicio de estradata
 */
export function setDatosRiesgo(riskSummary) {
  const datosRiesgo = new DatosRiesgo();
  if (!!riskSummary) {
    datosRiesgo.continuarPorProcuraduria = riskSummary.continuarPorProcuraduria;
    datosRiesgo.isMedia = riskSummary.isMedia;
    datosRiesgo.isPep = riskSummary.isPep ? "si" : "no";
    datosRiesgo.listasNoVinculantes = riskSummary.listasNoVinculantes;
    datosRiesgo.listasReportado = riskSummary.listasReportado;
    datosRiesgo.listasVinculantes = riskSummary.listasVinculantes;
    datosRiesgo.nombreProcuraduria = riskSummary.nombreProcuraduria;
    datosRiesgo.porcentajeListaNoVinculante = riskSummary.porcentajeListaNoVinculante;
    datosRiesgo.porcentajeListaVinculante = riskSummary.porcentajeListaVinculante;
    datosRiesgo.porcentajeMedia = riskSummary.porcentajeMedia;
    datosRiesgo.porcentajePep = riskSummary.porcentajePep;
    datosRiesgo.scapRisk = riskSummary.scapRisk;
    datosRiesgo.siapRisk = riskSummary.siapRisk;
  }
  return datosRiesgo;
}

/**
 * Metodo para actualizar el riesgo mas alto de los participantes en el cliente juridico
 * @param riskSummary corresponde al resumen del riesgo obtenido por la consulta de estradata
 */
export function updateDatosRiesgoJuridico(riskSummary: any, datosRiesgo: DatosRiesgo) {
  if (datosRiesgo.isPep === "no") {
    datosRiesgo.isPep = riskSummary.isPep ? "si" : "no";
    datosRiesgo.porcentajePep = riskSummary.porcentajePep;
  }
  if (!datosRiesgo.isMedia) {
    datosRiesgo.isMedia = riskSummary.isMedia;
    datosRiesgo.porcentajeMedia = riskSummary.porcentajeMedia;
  }
  if (!datosRiesgo.listasVinculantes
      || (datosRiesgo.listasVinculantes && datosRiesgo.porcentajeListaVinculante < riskSummary.porcentajeListaVinculante)) {
    datosRiesgo.listasVinculantes = riskSummary.listasVinculantes;
    datosRiesgo.porcentajeListaVinculante = riskSummary.porcentajeListaVinculante;
  }
  if (!datosRiesgo.listasNoVinculantes
      || (datosRiesgo.listasNoVinculantes && datosRiesgo.porcentajeListaNoVinculante < riskSummary.porcentajeListaNoVinculante)) {
    datosRiesgo.listasNoVinculantes = riskSummary.listasNoVinculantes;
    datosRiesgo.porcentajeListaNoVinculante = riskSummary.porcentajeListaNoVinculante;
  }
  if (!(!!datosRiesgo.listasReportado)
      || (!!riskSummary.listasReportado && !!datosRiesgo.listasReportado && datosRiesgo.listasReportado.length < riskSummary.listasReportado.length)) {
    datosRiesgo.listasReportado = riskSummary.listasReportado;
  }
  return datosRiesgo;
}

/**
 * Metodo para establecer el SCAP general de la persona juridica
 */
export function setClienteJuridicoSCAP(datosSolicitud: DatosSolicitud) {
  if (!!datosSolicitud
      && !!datosSolicitud.clienteJuridico
      && !!datosSolicitud.clienteJuridico.datosRiesgo) {
    const SCAPJuridico = datosSolicitud.clienteJuridico.datosRiesgo.scapRisk;
    let SCAPRepresentantesLegales = 'bajo';
    if (!!datosSolicitud.clienteJuridico.datosRepresentanteLegal && datosSolicitud.clienteJuridico.datosRepresentanteLegal.length > 0) {
      SCAPRepresentantesLegales = !!datosSolicitud.clienteJuridico.datosRepresentanteLegal.find((obj) => !!obj.datosRiesgo && !!obj.datosRiesgo.scapRisk && obj.datosRiesgo.scapRisk === 'prohibido') ? 'prohibido' : (!!datosSolicitud.clienteJuridico.datosRepresentanteLegal.find((obj) => !!obj.datosRiesgo && !!obj.datosRiesgo.scapRisk && obj.datosRiesgo.scapRisk === 'sensible') ? 'sensible' : 'bajo');
    }
    let SCAPOrdenantes = 'bajo';
    if (!!datosSolicitud.clienteJuridico.datosOrdenantes && datosSolicitud.clienteJuridico.datosOrdenantes.length > 0) {
      SCAPOrdenantes = !!datosSolicitud.clienteJuridico.datosOrdenantes.find((obj) => !!obj.datosRiesgo && !!obj.datosRiesgo.scapRisk && obj.datosRiesgo.scapRisk === 'prohibido') ? 'prohibido' : (!!datosSolicitud.clienteJuridico.datosOrdenantes.find((obj) => !!obj.datosRiesgo && !!obj.datosRiesgo.scapRisk && obj.datosRiesgo.scapRisk === 'sensible') ? 'sensible' : 'bajo');
    }
    datosSolicitud.clienteJuridico.datosRiesgo.scapRisk = ((SCAPJuridico.indexOf('prohibido') !== -1 || SCAPRepresentantesLegales.indexOf('prohibido') !== -1 || SCAPOrdenantes.indexOf('prohibido') !== -1) ? 'prohibido' : ((SCAPJuridico.indexOf('sensible') !== -1 || SCAPRepresentantesLegales.indexOf('sensible') !== -1 || SCAPOrdenantes.indexOf('sensible') !== -1) ? 'sensible' : 'bajo'));
  }
  return datosSolicitud;
}

/**
 * Metodo para establecer el SIAP general de la persona juridica
 */
export function setClienteJuridicoSIAP(datosSolicitud: DatosSolicitud) {
  if (!!datosSolicitud
      && !!datosSolicitud.clienteJuridico
      && !!datosSolicitud.clienteJuridico.datosRiesgo) {
    const SIAPJuridico = datosSolicitud.clienteJuridico.datosRiesgo.siapRisk;
    let SIAPRepresentantesLegales = 'bajo';
    if (!!datosSolicitud.clienteJuridico.datosRepresentanteLegal && datosSolicitud.clienteJuridico.datosRepresentanteLegal.length > 0) {
      SIAPRepresentantesLegales = !!datosSolicitud.clienteJuridico.datosRepresentanteLegal.find((obj) => !!obj.datosRiesgo && !!obj.datosRiesgo.siapRisk && obj.datosRiesgo.siapRisk === 'alto') ? 'alto' : (!!datosSolicitud.clienteJuridico.datosRepresentanteLegal.find((obj) => !!obj.datosRiesgo && !!obj.datosRiesgo.siapRisk && obj.datosRiesgo.siapRisk === 'sensible') ? 'sensible' : 'bajo');
    }
    let SIAPOrdenantes = 'bajo';
    if (!!datosSolicitud.clienteJuridico.datosOrdenantes && datosSolicitud.clienteJuridico.datosOrdenantes.length > 0) {
      SIAPOrdenantes = !!datosSolicitud.clienteJuridico.datosOrdenantes.find((obj) => !!obj.datosRiesgo && !!obj.datosRiesgo.siapRisk && obj.datosRiesgo.siapRisk === 'alto') ? 'alto' : (!!datosSolicitud.clienteJuridico.datosOrdenantes.find((obj) => !!obj.datosRiesgo && !!obj.datosRiesgo.siapRisk && obj.datosRiesgo.siapRisk === 'sensible') ? 'sensible' : 'bajo');
    }
    datosSolicitud.clienteJuridico.datosRiesgo.siapRisk = ((SIAPJuridico.indexOf('alto') !== -1 || SIAPRepresentantesLegales.indexOf('alto') !== -1 || SIAPOrdenantes.indexOf('alto') !== -1) ? 'alto' : ((SIAPJuridico.indexOf('sensible') !== -1 || SIAPRepresentantesLegales.indexOf('sensible') !== -1 || SIAPOrdenantes.indexOf('sensible') !== -1) ? 'sensible' : 'bajo'));
  }
  return datosSolicitud;
}
