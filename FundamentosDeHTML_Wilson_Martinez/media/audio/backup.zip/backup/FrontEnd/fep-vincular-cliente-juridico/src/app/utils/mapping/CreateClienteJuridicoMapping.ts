import { ClienteJuridico } from '../models/api-solicitud/ClienteJuridico';
import { PersonaJuridica } from '../models/api-cliente/PersonaJuridica';
import { DatosRepresentanteLegalPJ } from '../models/api-cliente/DatosRepresentanteLegalPJ';
import { EstradataPJ } from '../models/api-cliente/EstradataPJ';
import { DatosOrdenantePJ } from '../models/api-cliente/DatosOrdenantePJ';
import { AccionistaPJ } from '../models/api-cliente/AccionistaPJ';
import { DatosAutorizadosPJ } from '../models/api-cliente/DatosAutorizadosPJ';
import { DatosTercerosPJ } from '../models/api-cliente/DatosTercerosPJ';
import { OperacionInternacionalPJ } from '../models/api-cliente/OperacionInternacionalPJ';

export function newPersonaJuridicaMapping (clienteJuridico: ClienteJuridico): PersonaJuridica {

  const personaJuridica = new PersonaJuridica();

  if (!!clienteJuridico) {
    try {

      // Mapping Datos Generales
      if (!!clienteJuridico.datosGenerales) {
        personaJuridica.tipoIdentificacion = clienteJuridico.datosGenerales.tipoDocumento.split('-')[0].trim() || '';
        personaJuridica.numeroIdentificacion = clienteJuridico.datosGenerales.numeroDocumento.replace(/\./g, '') || '';
      }
      personaJuridica.idPersona = clienteJuridico.idCliente;
      // Mapping Datos Contacto
      if (!!clienteJuridico.datosContacto) {
        const datosContacto = clienteJuridico.datosContacto;
        personaJuridica.datosContactoPJ.idDatosContacto = datosContacto.idDatosContacto;
        personaJuridica.datosContactoPJ.checkCorreo = datosContacto.checkCorreo || false;
        personaJuridica.datosContactoPJ.ciudad = datosContacto.ciudad || '';
        personaJuridica.datosContactoPJ.claseSociedad = datosContacto.claseSociedad || '';
        personaJuridica.datosContactoPJ.codigoCIIU = datosContacto.codigoCIIU || '';
        personaJuridica.datosContactoPJ.comercialRM = datosContacto.comercialRM || '';
        personaJuridica.datosContactoPJ.correo = datosContacto.correo || '';
        personaJuridica.datosContactoPJ.correoOpcional = datosContacto.correoOpcional || '';
        personaJuridica.datosContactoPJ.departamento = datosContacto.departamento || '';
        personaJuridica.datosContactoPJ.direccion = datosContacto.direccion || '';
        personaJuridica.datosContactoPJ.nombre = datosContacto.nombre || '';
        personaJuridica.datosContactoPJ.pais = datosContacto.pais || '';
        personaJuridica.datosContactoPJ.telefono = datosContacto.telefono || '';
        personaJuridica.datosContactoPJ.tipoEntidad = datosContacto.tipoEntidad || '';
      }

      // Mapping representantes legales
      if (!!clienteJuridico.datosRepresentanteLegal && clienteJuridico.datosRepresentanteLegal.length > 0) {
        const datosRepresentanteLegal = clienteJuridico.datosRepresentanteLegal;
        datosRepresentanteLegal.forEach(
          (rep) => {
            const representante = new DatosRepresentanteLegalPJ();
            representante.idParticipante = rep.idParticipante;
            representante.ciudadExpedicion = rep.ciudadExpedicion || '';
            representante.ciudadNacimiento = rep.ciudadNacimiento || '';
            representante.ciudadResidencia = rep.ciudadResidencia || '';
            representante.codigoCIIU = rep.codigoCIIU || '';
            if (!!rep.datosAml) {
              representante.datosAMLPJ.idDatosAML = rep.datosAml.idDatosAML;
              representante.datosAMLPJ.decision = rep.datosAml.decision || '';
              representante.datosAMLPJ.motivo = rep.datosAml.motivo || '';
              representante.datosAMLPJ.idUsuario = rep.datosAml.idUsuario || '';
              representante.datosAMLPJ.nombreUsuario = rep.datosAml.nombre || '';
              representante.datosAMLPJ.fecha = rep.datosAml.fecha || '';
            }
            if (!!rep.datosCumplimiento) {
              representante.datosCumplimientoPJ.idDatosCumplimiento = rep.datosCumplimiento.idDatosAML;
              representante.datosCumplimientoPJ.decision = rep.datosCumplimiento.decision || '';
              representante.datosCumplimientoPJ.motivo = rep.datosCumplimiento.motivo || '';
              representante.datosCumplimientoPJ.idUsuario = rep.datosCumplimiento.idUsuario || '';
              representante.datosCumplimientoPJ.nombreUsuario = rep.datosCumplimiento.nombre || '';
              representante.datosCumplimientoPJ.fecha = rep.datosCumplimiento.fecha || '';
            }
            if (!!rep.datosRiesgo) {
              representante.datosRiesgoPJ.idDatosRiesgo = rep.datosRiesgo.idDatosRiesgo;
              representante.datosRiesgoPJ.continuarPorProcuraduria = rep.datosRiesgo.continuarPorProcuraduria || null;
              representante.datosRiesgoPJ.isMedia = rep.datosRiesgo.isMedia || null;
              representante.datosRiesgoPJ.isPep = rep.datosRiesgo.isPep || null;
              representante.datosRiesgoPJ.listasNoVinculantes = rep.datosRiesgo.listasNoVinculantes || null;
              if (!!rep.datosRiesgo.listasReportado && rep.datosRiesgo.listasReportado.length > 0) {
                rep.datosRiesgo.listasReportado.forEach(
                  (listaReportado) => {
                    const listaReportadoNew = new EstradataPJ();
                    listaReportadoNew.idEstradata = listaReportado.idEstradata;
                    listaReportadoNew.identificacion = listaReportado.identificacion || '';
                    listaReportadoNew.nacionalidad = listaReportado.nacionalidad || '';
                    listaReportadoNew.nombreLista = listaReportado.nombreLista || '';
                    listaReportadoNew.porcentaje = listaReportado.porcentaje || '';
                    representante.datosRiesgoPJ.listaEstradata.push(listaReportadoNew);
                  }
                );
              }
              representante.datosRiesgoPJ.listasVinculantes = rep.datosRiesgo.listasVinculantes || null;
              representante.datosRiesgoPJ.nombreProcuraduria = rep.datosRiesgo.nombreProcuraduria || null;
              representante.datosRiesgoPJ.pepReasons = rep.datosRiesgo.pepReasons || null;
              representante.datosRiesgoPJ.porcentajeListaNoVinculante = rep.datosRiesgo.porcentajeListaNoVinculante || 0;
              representante.datosRiesgoPJ.porcentajeListaVinculante = rep.datosRiesgo.porcentajeListaVinculante || 0;
              representante.datosRiesgoPJ.porcentajeMedia = rep.datosRiesgo.porcentajeMedia || 0;
              representante.datosRiesgoPJ.porcentajePep = rep.datosRiesgo.porcentajePep || 0;
              representante.datosRiesgoPJ.risk = rep.datosRiesgo.risk || null;
              representante.datosRiesgoPJ.scapRisk = rep.datosRiesgo.scapRisk || null;
              representante.datosRiesgoPJ.siapRisk = rep.datosRiesgo.siapRisk || null;
            }
            representante.departamentoExpedicion = rep.departamentoExpedicion || '';
            representante.departamentoNacimiento = rep.departamentoNacimiento || '';
            representante.departamentoResidencia = rep.departamentoResidencia || '';
            representante.direccionResidencia = rep.direccionResidencia || '';
            representante.fechaExpedicion = rep.fechaExpedicion || '';
            representante.isPrincipal = (!!rep.isPrincipal && rep.isPrincipal.toLowerCase() === 'si') || false;
            representante.nombre = rep.nombre || '';
            representante.numeroDocumento = rep.numeroDocumento.replace(/\./g, '') || '';
            representante.ocupacion = rep.ocupacion || '';
            representante.paisExpedicion = rep.paisExpedicion || '';
            representante.paisNacimiento = rep.paisNacimiento || '';
            representante.paisResidencia = rep.paisResidencia || '';
            representante.tipoDocumento = rep.tipoDocumento.split('-')[0].trim() || '';
            personaJuridica.listaRepresentantesLegal.push(representante);
          }
        );
      }

      // Mapping Ordenantes
      if (!!clienteJuridico.datosOrdenantes && clienteJuridico.datosOrdenantes.length > 0) {
        clienteJuridico.datosOrdenantes.forEach(
          (ord) => {
            const newOrdenante = new DatosOrdenantePJ();
            newOrdenante.idParticipante = ord.idParticipante;
            newOrdenante.ciudadExpedicion = ord.ciudadExpedicion || '';
            newOrdenante.ciudadNacimiento = ord.ciudadNacimiento || '';
            newOrdenante.ciudadResidencia = ord.ciudadResidencia || '';
            newOrdenante.codigoCIIU = ord.codigoCIIU || '';
            if (!!ord.datosAml) {
              newOrdenante.datosAMLPJ.idDatosAML = ord.datosAml.idDatosAML;
              newOrdenante.datosAMLPJ.decision = ord.datosAml.decision || '';
              newOrdenante.datosAMLPJ.motivo = ord.datosAml.motivo || '';
              newOrdenante.datosAMLPJ.idUsuario = ord.datosAml.idUsuario || '';
              newOrdenante.datosAMLPJ.nombreUsuario = ord.datosAml.nombre || '';
              newOrdenante.datosAMLPJ.fecha = ord.datosAml.fecha || '';
            }
            if (!!ord.datosCumplimiento) {
              newOrdenante.datosCumplimientoPJ.idDatosCumplimiento = ord.datosCumplimiento.idDatosAML;
              newOrdenante.datosCumplimientoPJ.decision = ord.datosCumplimiento.decision || '';
              newOrdenante.datosCumplimientoPJ.motivo = ord.datosCumplimiento.motivo || '';
              newOrdenante.datosCumplimientoPJ.idUsuario = ord.datosCumplimiento.idUsuario || '';
              newOrdenante.datosCumplimientoPJ.nombreUsuario = ord.datosCumplimiento.nombre || '';
              newOrdenante.datosCumplimientoPJ.fecha = ord.datosCumplimiento.fecha || '';
            }
            if (!!ord.datosRiesgo) {
              newOrdenante.datosRiesgoPJ.idDatosRiesgo = ord.datosRiesgo.idDatosRiesgo;
              newOrdenante.datosRiesgoPJ.continuarPorProcuraduria = ord.datosRiesgo.continuarPorProcuraduria || null;
              newOrdenante.datosRiesgoPJ.isMedia = ord.datosRiesgo.isMedia || null;
              newOrdenante.datosRiesgoPJ.isPep = ord.datosRiesgo.isPep || null;
              newOrdenante.datosRiesgoPJ.listasNoVinculantes = ord.datosRiesgo.listasNoVinculantes || null;
              if (!!ord.datosRiesgo.listasReportado && ord.datosRiesgo.listasReportado.length > 0) {
                ord.datosRiesgo.listasReportado.forEach(
                  (listaReportado) => {
                    const listaReportadoNew = new EstradataPJ();
                    listaReportadoNew.idEstradata = listaReportado.idEstradata;
                    listaReportadoNew.identificacion = listaReportado.identificacion || '';
                    listaReportadoNew.nacionalidad = listaReportado.nacionalidad || '';
                    listaReportadoNew.nombreLista = listaReportado.nombreLista || '';
                    listaReportadoNew.porcentaje = listaReportado.porcentaje || '';
                    newOrdenante.datosRiesgoPJ.listaEstradata.push(listaReportadoNew);
                  }
                );
              }
              newOrdenante.datosRiesgoPJ.listasVinculantes = ord.datosRiesgo.listasVinculantes || null;
              newOrdenante.datosRiesgoPJ.nombreProcuraduria = ord.datosRiesgo.nombreProcuraduria || null;
              newOrdenante.datosRiesgoPJ.pepReasons = ord.datosRiesgo.pepReasons || null;
              newOrdenante.datosRiesgoPJ.porcentajeListaNoVinculante = ord.datosRiesgo.porcentajeListaNoVinculante || 0;
              newOrdenante.datosRiesgoPJ.porcentajeListaVinculante = ord.datosRiesgo.porcentajeListaVinculante || 0;
              newOrdenante.datosRiesgoPJ.porcentajeMedia = ord.datosRiesgo.porcentajeMedia || 0;
              newOrdenante.datosRiesgoPJ.porcentajePep = ord.datosRiesgo.porcentajePep || 0;
              newOrdenante.datosRiesgoPJ.risk = ord.datosRiesgo.risk || null;
              newOrdenante.datosRiesgoPJ.scapRisk = ord.datosRiesgo.scapRisk || null;
              newOrdenante.datosRiesgoPJ.siapRisk = ord.datosRiesgo.siapRisk || null;
            }
            newOrdenante.departamentoExpedicion = ord.departamentoExpedicion || '';
            newOrdenante.departamentoNacimiento = ord.departamentoNacimiento || '';
            newOrdenante.departamentoResidencia = ord.departamentoResidencia || '';
            newOrdenante.direccionResidencia = ord.direccionResidencia || '';
            newOrdenante.fechaExpedicion = ord.fechaExpedicion || '';
            newOrdenante.nombre = ord.nombre || '';
            newOrdenante.numeroDocumento = ord.numeroDocumento.replace(/\./g, '') || '';
            newOrdenante.ocupacion = ord.ocupacion || '';
            newOrdenante.paisExpedicion = ord.paisExpedicion || '';
            newOrdenante.paisNacimiento = ord.paisNacimiento || '';
            newOrdenante.paisResidencia = ord.paisResidencia || '';
            newOrdenante.tipoDocumento = ord.tipoDocumento.split('-')[0].trim() || '';
            newOrdenante.datosAdicionalesOrdenantePJ = ord.datosAdicionales;
            personaJuridica.listaOrdenantes.push(newOrdenante);
          }
        );
      }

      // Mapping accionistas
      if (!!clienteJuridico.datosAccionistas) {
        personaJuridica.datosAccionistasPJ.idDatosAccionistas = clienteJuridico.datosAccionistas.idDatosAccionistas;
        personaJuridica.datosAccionistasPJ.emisorInscrito = clienteJuridico.datosAccionistas.emisorInscrito;
        if (!!clienteJuridico.datosAccionistas.accionistas && clienteJuridico.datosAccionistas.accionistas.length > 0) {
          clienteJuridico.datosAccionistas.accionistas.forEach(
            (acc) => {
              const newAccionista = new AccionistaPJ();
              newAccionista.idParticipante = acc.idParticipante;
              if (!!acc.datosAml) {
                newAccionista.datosAMLPJ.idDatosAML = acc.datosAml.idDatosAML;
                newAccionista.datosAMLPJ.decision = acc.datosAml.decision || '';
                newAccionista.datosAMLPJ.motivo = acc.datosAml.motivo || '';
                newAccionista.datosAMLPJ.idUsuario = acc.datosAml.idUsuario || '';
                newAccionista.datosAMLPJ.nombreUsuario = acc.datosAml.nombre || '';
                newAccionista.datosAMLPJ.fecha = acc.datosAml.fecha || '';
              }
              if (!!acc.datosCumplimiento) {
                newAccionista.datosCumplimientoPJ.idDatosCumplimiento = acc.datosCumplimiento.idDatosAML;
                newAccionista.datosCumplimientoPJ.decision = acc.datosCumplimiento.decision || '';
                newAccionista.datosCumplimientoPJ.motivo = acc.datosCumplimiento.motivo || '';
                newAccionista.datosCumplimientoPJ.idUsuario = acc.datosCumplimiento.idUsuario || '';
                newAccionista.datosCumplimientoPJ.nombreUsuario = acc.datosCumplimiento.nombre || '';
                newAccionista.datosCumplimientoPJ.fecha = acc.datosCumplimiento.fecha || '';
              }
              if (!!acc.datosRiesgo) {
                newAccionista.datosRiesgoPJ.idDatosRiesgo = acc.datosRiesgo.idDatosRiesgo;
                newAccionista.datosRiesgoPJ.continuarPorProcuraduria = acc.datosRiesgo.continuarPorProcuraduria || null;
                newAccionista.datosRiesgoPJ.isMedia = acc.datosRiesgo.isMedia || null;
                newAccionista.datosRiesgoPJ.isPep = acc.datosRiesgo.isPep || null;
                newAccionista.datosRiesgoPJ.listasNoVinculantes = acc.datosRiesgo.listasNoVinculantes || null;
                if (!!acc.datosRiesgo.listasReportado && acc.datosRiesgo.listasReportado.length > 0) {
                  acc.datosRiesgo.listasReportado.forEach(
                    (listaReportado) => {
                      const listaReportadoNew = new EstradataPJ();
                      listaReportadoNew.idEstradata = listaReportado.idEstradata;
                      listaReportadoNew.identificacion = listaReportado.identificacion || '';
                      listaReportadoNew.nacionalidad = listaReportado.nacionalidad || '';
                      listaReportadoNew.nombreLista = listaReportado.nombreLista || '';
                      listaReportadoNew.porcentaje = listaReportado.porcentaje || '';
                      newAccionista.datosRiesgoPJ.listaEstradata.push(listaReportadoNew);
                    }
                  );
                }
                newAccionista.datosRiesgoPJ.listasVinculantes = acc.datosRiesgo.listasVinculantes || null;
                newAccionista.datosRiesgoPJ.nombreProcuraduria = acc.datosRiesgo.nombreProcuraduria || null;
                newAccionista.datosRiesgoPJ.pepReasons = acc.datosRiesgo.pepReasons || null;
                newAccionista.datosRiesgoPJ.porcentajeListaNoVinculante = acc.datosRiesgo.porcentajeListaNoVinculante || 0;
                newAccionista.datosRiesgoPJ.porcentajeListaVinculante = acc.datosRiesgo.porcentajeListaVinculante || 0;
                newAccionista.datosRiesgoPJ.porcentajeMedia = acc.datosRiesgo.porcentajeMedia || 0;
                newAccionista.datosRiesgoPJ.porcentajePep = acc.datosRiesgo.porcentajePep || 0;
                newAccionista.datosRiesgoPJ.risk = acc.datosRiesgo.risk || null;
                newAccionista.datosRiesgoPJ.scapRisk = acc.datosRiesgo.scapRisk || null;
                newAccionista.datosRiesgoPJ.siapRisk = acc.datosRiesgo.siapRisk || null;
              }
              newAccionista.nombre = acc.nombre || '';
              newAccionista.numeroDocumento = acc.numeroDocumento.replace(/\./g, '') || '';
              newAccionista.paisNacimiento = acc.paisNacimiento || '';
              newAccionista.participacion = acc.participacion || '';
              newAccionista.tipoDocumento = acc.tipoDocumento.split('-')[0].trim() || '';
              personaJuridica.datosAccionistasPJ.listaAccionistaPJS.push(newAccionista);
            }
          );
        }
      }

      // Mapping datos autorizados
      if (!!clienteJuridico.datosAutorizados && clienteJuridico.datosAutorizados.length > 0) {
        clienteJuridico.datosAutorizados.forEach(
          (aut) => {
            const newAutorizado = new DatosAutorizadosPJ();
            newAutorizado.idParticipante = aut.idParticipante;
            if (!!aut.datosAml) {
              newAutorizado.datosAMLPJ.idDatosAML = aut.datosAml.idDatosAML;
              newAutorizado.datosAMLPJ.decision = aut.datosAml.decision || '';
              newAutorizado.datosAMLPJ.motivo = aut.datosAml.motivo || '';
              newAutorizado.datosAMLPJ.idUsuario = aut.datosAml.idUsuario || '';
              newAutorizado.datosAMLPJ.nombreUsuario = aut.datosAml.nombre || '';
              newAutorizado.datosAMLPJ.fecha = aut.datosAml.fecha || '';
            }
            if (!!aut.datosCumplimiento) {
              newAutorizado.datosCumplimientoPJ.idDatosCumplimiento = aut.datosCumplimiento.idDatosAML;
              newAutorizado.datosCumplimientoPJ.decision = aut.datosCumplimiento.decision || '';
              newAutorizado.datosCumplimientoPJ.motivo = aut.datosCumplimiento.motivo || '';
              newAutorizado.datosCumplimientoPJ.idUsuario = aut.datosCumplimiento.idUsuario || '';
              newAutorizado.datosCumplimientoPJ.nombreUsuario = aut.datosCumplimiento.nombre || '';
              newAutorizado.datosCumplimientoPJ.fecha = aut.datosCumplimiento.fecha || '';
            }
            if (!!aut.datosRiesgo) {
              newAutorizado.datosRiesgoPJ.idDatosRiesgo = aut.datosRiesgo.idDatosRiesgo;
              newAutorizado.datosRiesgoPJ.continuarPorProcuraduria = aut.datosRiesgo.continuarPorProcuraduria || null;
              newAutorizado.datosRiesgoPJ.isMedia = aut.datosRiesgo.isMedia || null;
              newAutorizado.datosRiesgoPJ.isPep = aut.datosRiesgo.isPep || null;
              newAutorizado.datosRiesgoPJ.listasNoVinculantes = aut.datosRiesgo.listasNoVinculantes || null;
              if (!!aut.datosRiesgo.listasReportado && aut.datosRiesgo.listasReportado.length > 0) {
                aut.datosRiesgo.listasReportado.forEach(
                  (listaReportado) => {
                    const listaReportadoNew = new EstradataPJ();
                    listaReportadoNew.idEstradata = listaReportado.idEstradata;
                    listaReportadoNew.identificacion = listaReportado.identificacion || '';
                    listaReportadoNew.nacionalidad = listaReportado.nacionalidad || '';
                    listaReportadoNew.nombreLista = listaReportado.nombreLista || '';
                    listaReportadoNew.porcentaje = listaReportado.porcentaje || '';
                    newAutorizado.datosRiesgoPJ.listaEstradata.push(listaReportadoNew);
                  }
                );
              }
              newAutorizado.datosRiesgoPJ.listasVinculantes = aut.datosRiesgo.listasVinculantes || null;
              newAutorizado.datosRiesgoPJ.nombreProcuraduria = aut.datosRiesgo.nombreProcuraduria || null;
              newAutorizado.datosRiesgoPJ.pepReasons = aut.datosRiesgo.pepReasons || null;
              newAutorizado.datosRiesgoPJ.porcentajeListaNoVinculante = aut.datosRiesgo.porcentajeListaNoVinculante || 0;
              newAutorizado.datosRiesgoPJ.porcentajeListaVinculante = aut.datosRiesgo.porcentajeListaVinculante || 0;
              newAutorizado.datosRiesgoPJ.porcentajeMedia = aut.datosRiesgo.porcentajeMedia || 0;
              newAutorizado.datosRiesgoPJ.porcentajePep = aut.datosRiesgo.porcentajePep || 0;
              newAutorizado.datosRiesgoPJ.risk = aut.datosRiesgo.risk || null;
              newAutorizado.datosRiesgoPJ.scapRisk = aut.datosRiesgo.scapRisk || null;
              newAutorizado.datosRiesgoPJ.siapRisk = aut.datosRiesgo.siapRisk || null;
            }
            newAutorizado.nombre = aut.nombre || '';
            newAutorizado.numeroDocumento = aut.numeroDocumento.replace(/\./g, '') || '';
            newAutorizado.tipoDocumento = aut.tipoDocumento.split('-')[0].trim() || '';
            personaJuridica.listaAutorizados.push(newAutorizado);
          }
        );
      }

      // Mapping terceros
      if (!!clienteJuridico.datosTerceros && clienteJuridico.datosTerceros.length > 0) {
        clienteJuridico.datosTerceros.forEach(
          (ter) => {
            const newTercero = new DatosTercerosPJ();
            if (!!ter.datosAml) {
              newTercero.datosAMLPJ.idDatosAML = ter.datosAml.idDatosAML;
              newTercero.datosAMLPJ.decision = ter.datosAml.decision || '';
              newTercero.datosAMLPJ.motivo = ter.datosAml.motivo || '';
              newTercero.datosAMLPJ.idUsuario = ter.datosAml.idUsuario || '';
              newTercero.datosAMLPJ.nombreUsuario = ter.datosAml.nombre || '';
              newTercero.datosAMLPJ.fecha = ter.datosAml.fecha || '';
            }
            if (!!ter.datosCumplimiento) {
              newTercero.datosCumplimientoPJ.idDatosCumplimiento = ter.datosCumplimiento.idDatosAML;
              newTercero.datosCumplimientoPJ.decision = ter.datosCumplimiento.decision || '';
              newTercero.datosCumplimientoPJ.motivo = ter.datosCumplimiento.motivo || '';
              newTercero.datosCumplimientoPJ.idUsuario = ter.datosCumplimiento.idUsuario || '';
              newTercero.datosCumplimientoPJ.nombreUsuario = ter.datosCumplimiento.nombre || '';
              newTercero.datosCumplimientoPJ.fecha = ter.datosCumplimiento.fecha || '';
            }
            if (!!ter.datosRiesgo) {
              newTercero.datosRiesgoPJ.idDatosRiesgo = ter.datosRiesgo.idDatosRiesgo;
              newTercero.datosRiesgoPJ.continuarPorProcuraduria = ter.datosRiesgo.continuarPorProcuraduria || null;
              newTercero.datosRiesgoPJ.isMedia = ter.datosRiesgo.isMedia || null;
              newTercero.datosRiesgoPJ.isPep = ter.datosRiesgo.isPep || null;
              newTercero.datosRiesgoPJ.listasNoVinculantes = ter.datosRiesgo.listasNoVinculantes || null;
              if (!!ter.datosRiesgo.listasReportado && ter.datosRiesgo.listasReportado.length > 0) {
                ter.datosRiesgo.listasReportado.forEach(
                  (listaReportado) => {
                    const listaReportadoNew = new EstradataPJ();
                    listaReportadoNew.idEstradata = listaReportado.idEstradata;
                    listaReportadoNew.identificacion = listaReportado.identificacion || '';
                    listaReportadoNew.nacionalidad = listaReportado.nacionalidad || '';
                    listaReportadoNew.nombreLista = listaReportado.nombreLista || '';
                    listaReportadoNew.porcentaje = listaReportado.porcentaje || '';
                    newTercero.datosRiesgoPJ.listaEstradata.push(listaReportadoNew);
                  }
                );
              }
              newTercero.datosRiesgoPJ.listasVinculantes = ter.datosRiesgo.listasVinculantes || null;
              newTercero.datosRiesgoPJ.nombreProcuraduria = ter.datosRiesgo.nombreProcuraduria || null;
              newTercero.datosRiesgoPJ.pepReasons = ter.datosRiesgo.pepReasons || null;
              newTercero.datosRiesgoPJ.porcentajeListaNoVinculante = ter.datosRiesgo.porcentajeListaNoVinculante || 0;
              newTercero.datosRiesgoPJ.porcentajeListaVinculante = ter.datosRiesgo.porcentajeListaVinculante || 0;
              newTercero.datosRiesgoPJ.porcentajeMedia = ter.datosRiesgo.porcentajeMedia || 0;
              newTercero.datosRiesgoPJ.porcentajePep = ter.datosRiesgo.porcentajePep || 0;
              newTercero.datosRiesgoPJ.risk = ter.datosRiesgo.risk || null;
              newTercero.datosRiesgoPJ.scapRisk = ter.datosRiesgo.scapRisk || null;
              newTercero.datosRiesgoPJ.siapRisk = ter.datosRiesgo.siapRisk || null;
            }
            newTercero.nombre = ter.nombre || '';
            newTercero.numeroDocumento = ter.numeroDocumento.replace(/\./g, '') || '';
            newTercero.tipoDocumento = ter.tipoDocumento.split('-')[0].trim() || '';
            personaJuridica.listaTerceros.push(newTercero);
          }
        );
      }

      // Mapping datos riesgo
      if (!!clienteJuridico.datosRiesgo) {
        const datosRiesgo = clienteJuridico.datosRiesgo;
        personaJuridica.datosRiesgoPJ.idDatosRiesgo = datosRiesgo.idDatosRiesgo;
        personaJuridica.datosRiesgoPJ.continuarPorProcuraduria = datosRiesgo.continuarPorProcuraduria || null;
        personaJuridica.datosRiesgoPJ.isMedia = datosRiesgo.isMedia || null;
        personaJuridica.datosRiesgoPJ.isPep = datosRiesgo.isPep || null;
        personaJuridica.datosRiesgoPJ.listasNoVinculantes = datosRiesgo.listasNoVinculantes || null;
        if (!!datosRiesgo.listasReportado && datosRiesgo.listasReportado.length > 0) {
          datosRiesgo.listasReportado.forEach(
            (listaReportado) => {
              const listaReportadoNew = new EstradataPJ();
              listaReportadoNew.idEstradata  = listaReportado.idEstradata;
              listaReportadoNew.identificacion = listaReportado.identificacion || '';
              listaReportadoNew.nacionalidad = listaReportado.nacionalidad || '';
              listaReportadoNew.nombreLista = listaReportado.nombreLista || '';
              listaReportadoNew.porcentaje = listaReportado.porcentaje || '';
              personaJuridica.datosRiesgoPJ.listaEstradata.push(listaReportadoNew);
            }
          );
        }
        personaJuridica.datosRiesgoPJ.listasVinculantes = datosRiesgo.listasVinculantes || null;
        personaJuridica.datosRiesgoPJ.nombreProcuraduria = datosRiesgo.nombreProcuraduria || null;
        personaJuridica.datosRiesgoPJ.pepReasons = datosRiesgo.pepReasons || null;
        personaJuridica.datosRiesgoPJ.porcentajeListaNoVinculante = datosRiesgo.porcentajeListaNoVinculante || 0;
        personaJuridica.datosRiesgoPJ.porcentajeListaVinculante = datosRiesgo.porcentajeListaVinculante || 0;
        personaJuridica.datosRiesgoPJ.porcentajeMedia = datosRiesgo.porcentajeMedia || 0;
        personaJuridica.datosRiesgoPJ.porcentajePep = datosRiesgo.porcentajePep || 0;
        personaJuridica.datosRiesgoPJ.risk = datosRiesgo.risk || null;
        personaJuridica.datosRiesgoPJ.scapRisk = datosRiesgo.scapRisk || null;
        personaJuridica.datosRiesgoPJ.siapRisk = datosRiesgo.siapRisk || null;
      }

      // Mapping datos AML
      if (!!clienteJuridico.datosAml) {
        personaJuridica.datosAMLPJ.idDatosAML = clienteJuridico.datosAml.idDatosAML;
        personaJuridica.datosAMLPJ.decision = clienteJuridico.datosAml.decision || '';
        personaJuridica.datosAMLPJ.motivo = clienteJuridico.datosAml.motivo || '';
        personaJuridica.datosAMLPJ.idUsuario = clienteJuridico.datosAml.idUsuario || '';
        personaJuridica.datosAMLPJ.nombreUsuario = clienteJuridico.datosAml.nombre || '';
        personaJuridica.datosAMLPJ.fecha = clienteJuridico.datosAml.fecha || '';
      }

      // Mapping datos cumplimiento
      if (!!clienteJuridico.datosCumplimiento) {
        personaJuridica.datosCumplimientoPJ.idDatosCumplimiento = clienteJuridico.datosCumplimiento.idDatosAML;
        personaJuridica.datosCumplimientoPJ.decision = clienteJuridico.datosCumplimiento.decision || '';
        personaJuridica.datosCumplimientoPJ.motivo = clienteJuridico.datosCumplimiento.motivo || '';
        personaJuridica.datosCumplimientoPJ.idUsuario = clienteJuridico.datosCumplimiento.idUsuario || '';
        personaJuridica.datosCumplimientoPJ.nombreUsuario = clienteJuridico.datosCumplimiento.nombre || '';
        personaJuridica.datosCumplimientoPJ.fecha = clienteJuridico.datosCumplimiento.fecha || '';
      }

      // Mapping datos pep
      if (!!clienteJuridico.datosPepJuridico) {
        const datosPepJuridico = clienteJuridico.datosPepJuridico;
        personaJuridica.datosPepPJ.idDatosPEP = datosPepJuridico.idDatosPEP;
        personaJuridica.datosPepPJ.administraRecPublicos = (!!datosPepJuridico.administraRecPublicos && datosPepJuridico.administraRecPublicos.toLowerCase() === 'si');
        personaJuridica.datosPepPJ.clientePEP = (!!datosPepJuridico.clientePEP && datosPepJuridico.clientePEP.toLowerCase() === 'si');
        personaJuridica.datosPepPJ.descPerteneceGrupoEmpresarial = datosPepJuridico.descPerteneceGrupoEmpresarial || '';
        personaJuridica.datosPepPJ.descTieneCalificacionRiesgos = datosPepJuridico.descTieneCalificacionRiesgos || '';
        personaJuridica.datosPepPJ.perteneceGrupoEmpresarial = (!!datosPepJuridico.perteneceGrupoEmpresarial && datosPepJuridico.perteneceGrupoEmpresarial.toLowerCase() === 'si');
        personaJuridica.datosPepPJ.tieneCalificacionRiesgos = (!!datosPepJuridico.tieneCalificacionRiesgos && datosPepJuridico.tieneCalificacionRiesgos.toLowerCase() === 'si');
        personaJuridica.datosPepPJ.tieneRecPublicoMedComunicacion = (!!datosPepJuridico.tieneRecPublicoMedComunicacion && datosPepJuridico.tieneRecPublicoMedComunicacion.toLowerCase() === 'si');
      }

      // Mapping datos adicionales
      if (!!clienteJuridico.datosAdicionales) {
        personaJuridica.datosAdicionalesPJ.idDatosAdicionales = clienteJuridico.datosAdicionales.idDatosAdicionales;
        // Mapping datos facta
        if (!!clienteJuridico.datosAdicionales.datosClasificacionFatca) {
          const datosFacta = clienteJuridico.datosAdicionales.datosClasificacionFatca || null;
          personaJuridica.datosAdicionalesPJ.datosFatcaPJ.idDatosFacta = datosFacta.idDatosFacta;
          personaJuridica.datosAdicionalesPJ.datosFatcaPJ.descripcionRazonNoTin = datosFacta.descripcionRazonNoTin || null;
          personaJuridica.datosAdicionalesPJ.datosFatcaPJ.emisorInscrito = datosFacta.emisorInscrito || null;
          personaJuridica.datosAdicionalesPJ.datosFatcaPJ.entidadInversion = datosFacta.entidadInversion || null;
          personaJuridica.datosAdicionalesPJ.datosFatcaPJ.entidadVigilada = datosFacta.entidadVigilada || null;
          personaJuridica.datosAdicionalesPJ.datosFatcaPJ.institucionCustodia = datosFacta.institucionCustodia || null;
          personaJuridica.datosAdicionalesPJ.datosFatcaPJ.nombreDeLaBolsa = datosFacta.nombreDeLaBolsa || null;
          personaJuridica.datosAdicionalesPJ.datosFatcaPJ.nombreDeLaEntidad = datosFacta.nombreDeLaEntidad || null;
          personaJuridica.datosAdicionalesPJ.datosFatcaPJ.numeroIdentificacionTributaria = datosFacta.numeroIdentificacionTributaria || null;
          personaJuridica.datosAdicionalesPJ.datosFatcaPJ.otraEntidadInversion = datosFacta.otraEntidadInversion || null;
          personaJuridica.datosAdicionalesPJ.datosFatcaPJ.otroNumeroIdentificacionTributaria = datosFacta.otroNumeroIdentificacionTributaria || null;
          personaJuridica.datosAdicionalesPJ.datosFatcaPJ.otroPaisResidencia = datosFacta.otroPaisResidencia || null;
          personaJuridica.datosAdicionalesPJ.datosFatcaPJ.paisResidencia = datosFacta.paisResidencia || null;
          personaJuridica.datosAdicionalesPJ.datosFatcaPJ.razonNoTin = datosFacta.razonNoTin || null;
          personaJuridica.datosAdicionalesPJ.datosFatcaPJ.tipoEntidad = datosFacta.tipoEntidad || null;
          personaJuridica.datosAdicionalesPJ.datosFatcaPJ.transfiereFondos = datosFacta.transfiereFondos || null;
        }

        // Mapping datos cuenta bancaria
        if (!!clienteJuridico.datosAdicionales.datosCuentaBancaria) {
          const datosCuentaBancaria = clienteJuridico.datosAdicionales.datosCuentaBancaria  || null;
          personaJuridica.datosAdicionalesPJ.datosCuentaBancariaPJ.idDatosCuentaBancaria = datosCuentaBancaria.idDatosCuentaBancaria;
          personaJuridica.datosAdicionalesPJ.datosCuentaBancariaPJ.cedulaCiudadania = datosCuentaBancaria.cedulaCiudadania || null;
          personaJuridica.datosAdicionalesPJ.datosCuentaBancariaPJ.nombreBanco = datosCuentaBancaria.nombreBanco || null;
          personaJuridica.datosAdicionalesPJ.datosCuentaBancariaPJ.nombreTitular = datosCuentaBancaria.nombreTitular || null;
          personaJuridica.datosAdicionalesPJ.datosCuentaBancariaPJ.numeroCuenta = datosCuentaBancaria.numeroCuenta || null;
          personaJuridica.datosAdicionalesPJ.datosCuentaBancariaPJ.tipoCuenta = datosCuentaBancaria.tipoCuenta || null;
        }

        // Mapping datos financieros
        if (!!clienteJuridico.datosAdicionales.datosFinancieros) {
          const datosFinancieros = clienteJuridico.datosAdicionales.datosFinancieros;
          personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.idDatosFinancieros = datosFinancieros.idDatosFinancieros;
          personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.activos = datosFinancieros.activos || null;
          personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.detalleIngreso = datosFinancieros.detalleIngresos || null;
          personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.egresoMensual = datosFinancieros.egresosMensuales || null;
          personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.ingresoMensual = datosFinancieros.ingresosMensuales || null;
          personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.otrosEgresos = datosFinancieros.otrosEgresos || null;
          personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.otrosIngresos = datosFinancieros.otrosIngresos || null;
          personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.pasivos = datosFinancieros.pasivos || null;
          personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.patrimonio = datosFinancieros.patrimonio || null;
          personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.totalEgresos = datosFinancieros.totalEgresos || null;
          personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.totalIngresos = datosFinancieros.totalIngresos || null;
        }

        // Mapping datos operaciones internacionales
        if (!!clienteJuridico.datosAdicionales.datosOperacionesInternacionales) {
          const opInternacionales = clienteJuridico.datosAdicionales.datosOperacionesInternacionales;
          personaJuridica.datosAdicionalesPJ.datosOperacionesInternacionalesPJ.idDatosOpInternacionales = opInternacionales.idDatosOpInternacionales;
          if (!!opInternacionales.operacion && opInternacionales.operacion.length > 0) {
            opInternacionales.operacion.forEach(
              (op) => {
                const opInternacional = new OperacionInternacionalPJ();
                opInternacional.idOperacionInternacional = op.idOperacionInternacional;
                opInternacional.nombre = op.name;
                opInternacional.checked = op.checked;
                personaJuridica.datosAdicionalesPJ.datosOperacionesInternacionalesPJ.listaOperacionesInternacionales.push(opInternacional);
              }
            );
          }
          personaJuridica.datosAdicionalesPJ.datosOperacionesInternacionalesPJ.moneda = opInternacionales.moneda || null;
          personaJuridica.datosAdicionalesPJ.datosOperacionesInternacionalesPJ.monto = opInternacionales.monto || null;
          personaJuridica.datosAdicionalesPJ.datosOperacionesInternacionalesPJ.nombreEntidad = opInternacionales.nombreEntidad || null;
          personaJuridica.datosAdicionalesPJ.datosOperacionesInternacionalesPJ.operacionMonedaExt = opInternacionales.operacionMonedaExt || null;
          personaJuridica.datosAdicionalesPJ.datosOperacionesInternacionalesPJ.pais = opInternacionales.pais || null;
          personaJuridica.datosAdicionalesPJ.datosOperacionesInternacionalesPJ.tipoProducto = opInternacionales.tipoProducto || null;
        }
        // Mapping datos tributarios
        if (!!clienteJuridico.datosAdicionales.datosInformacionTributaria) {
          const datosInformacionTributaria = clienteJuridico.datosAdicionales.datosInformacionTributaria;
          personaJuridica.datosAdicionalesPJ.datosInformacionTributariaPJ.idDatosTributarios = datosInformacionTributaria.idDatosTributarios;
          personaJuridica.datosAdicionalesPJ.datosInformacionTributariaPJ.autoRetenedorRendimientos = datosInformacionTributaria.autoRetenedorRendimientos || null;
          personaJuridica.datosAdicionalesPJ.datosInformacionTributariaPJ.contribuyenteImpuesto = datosInformacionTributaria.contribuyenteImpuesto || null;
          personaJuridica.datosAdicionalesPJ.datosInformacionTributariaPJ.exentoGMF = datosInformacionTributaria.exentoGMF || null;
          personaJuridica.datosAdicionalesPJ.datosInformacionTributariaPJ.granContribuyente = datosInformacionTributaria.granContribuyente || null;
          personaJuridica.datosAdicionalesPJ.datosInformacionTributariaPJ.numeroResolucionRegimen = datosInformacionTributaria.numeroResolucionRegimen || null;
          personaJuridica.datosAdicionalesPJ.datosInformacionTributariaPJ.numeroResolucionRetenedor = datosInformacionTributaria.numeroResolucionRetenedor || null;
          personaJuridica.datosAdicionalesPJ.datosInformacionTributariaPJ.otroContribuyente = datosInformacionTributaria.otroContribuyente || null;
          personaJuridica.datosAdicionalesPJ.datosInformacionTributariaPJ.tipoContribuyente = datosInformacionTributaria.tipoContribuyente || null;
          personaJuridica.datosAdicionalesPJ.datosInformacionTributariaPJ.tipoRegimen = datosInformacionTributaria.tipoRegimen || null;
        }
      }
    } catch (error) {
      console.error(error);
      return personaJuridica;
    }
  }
  return personaJuridica;
}
