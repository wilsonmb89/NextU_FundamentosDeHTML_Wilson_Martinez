import { DatosRiesgo } from '../models/api-solicitud/DatosRiesgo';
import { DocumentRules } from '../models/reglas/DocumentRules';
import { RULE_ID, RULE_DATA_TYPES } from '../constants/utils.constant';
import { Variables } from '../models/reglas/Variables';
import { GenericType } from '../models/reglas/GenericType';
import { DatosContacto } from '../models/api-solicitud/DatosContacto';

/**
 * Metodo para la construccion de la variable de entrada que realiza
 * el consumo de la regla de enrutamiento
 * @param datosRiesgo insumo para enviar a la regla de enrutamiento
 */
export function mappingConsultaListas(datosRiesgo: DatosRiesgo) {
  const enrutamientoRq = new DocumentRules();
  enrutamientoRq.decisionId = RULE_ID.ENRUTAMIENTO_ID;
  enrutamientoRq.variables = new Variables();
  enrutamientoRq.variables.listaVinculantes = new GenericType();
  enrutamientoRq.variables.listaVinculantes.value = datosRiesgo.listasVinculantes || false;
  enrutamientoRq.variables.listaVinculantes.type = RULE_DATA_TYPES.BOOLEAN_TYPE;
  enrutamientoRq.variables.porcentajeListaVinculante = new GenericType();
  enrutamientoRq.variables.porcentajeListaVinculante.value = datosRiesgo.porcentajeListaVinculante || 0;
  enrutamientoRq.variables.porcentajeListaVinculante.type = RULE_DATA_TYPES.DOUBLE_TYPE;
  enrutamientoRq.variables.listaNoVinculantes = new GenericType();
  enrutamientoRq.variables.listaNoVinculantes.value = datosRiesgo.listasNoVinculantes || false;
  enrutamientoRq.variables.listaNoVinculantes.type = RULE_DATA_TYPES.BOOLEAN_TYPE;
  enrutamientoRq.variables.porcentajeListaNoVinculante = new GenericType();
  enrutamientoRq.variables.porcentajeListaNoVinculante.value = datosRiesgo.porcentajeListaNoVinculante || 0;
  enrutamientoRq.variables.porcentajeListaNoVinculante.type = RULE_DATA_TYPES.DOUBLE_TYPE;
  enrutamientoRq.variables.esMedia = new GenericType();
  enrutamientoRq.variables.esMedia.value = datosRiesgo.isMedia || false;
  enrutamientoRq.variables.esMedia.type = RULE_DATA_TYPES.BOOLEAN_TYPE;
  enrutamientoRq.variables.esPEP = new GenericType();
  enrutamientoRq.variables.esPEP.value = (!!datosRiesgo.isPep && datosRiesgo.isPep === 'si') ? true : false;
  enrutamientoRq.variables.esPEP.type = RULE_DATA_TYPES.BOOLEAN_TYPE;
  enrutamientoRq.variables.SCAP = new GenericType();
  enrutamientoRq.variables.SCAP.value = datosRiesgo.scapRisk || '';
  enrutamientoRq.variables.SCAP.type = RULE_DATA_TYPES.STRING_TYPE;
  enrutamientoRq.variables.SIAP = new GenericType();
  enrutamientoRq.variables.SIAP.value = datosRiesgo.siapRisk || '';
  enrutamientoRq.variables.SIAP.type = RULE_DATA_TYPES.STRING_TYPE;

  return enrutamientoRq;
}

export function mappingEnrutamiento(datosContacto: DatosContacto) {
  const enrutamientoRq = new DocumentRules();
  enrutamientoRq.decisionId = RULE_ID.ENRUTAMIENTO_PJ;
  enrutamientoRq.variables = new Variables();
  enrutamientoRq.variables.tipoEntidad = new GenericType();
  enrutamientoRq.variables.tipoEntidad.value = datosContacto.tipoEntidad.split(' - ')[0];
  enrutamientoRq.variables.tipoEntidad.type = RULE_DATA_TYPES.STRING_TYPE;
  enrutamientoRq.variables.claseSociedad = new GenericType();
  enrutamientoRq.variables.claseSociedad.value = datosContacto.claseSociedad.split(' - ')[0];
  enrutamientoRq.variables.claseSociedad.type = RULE_DATA_TYPES.STRING_TYPE;

  return enrutamientoRq;
}
