import { ClienteJuridico } from '../models/api-solicitud/ClienteJuridico';
import { OrdenanteRq } from 'src/app/shared/utils/models/Formatos/OrdenanteRq';
import { DatosOrdenantes } from '../models/api-solicitud/DatosOrdenantes';

/**
 * Metodo para construir request de generacion de formatos - Registro Firmas
 * @param cliente objeto con los datos del cliente
 */
export function firmasOrdenantes(cliente: ClienteJuridico): OrdenanteRq {
  const ordenanteRq = new OrdenanteRq();
  ordenanteRq.nombreCompleto = cliente.datosContacto.nombre;
  ordenanteRq.numDocumento = cliente.datosGenerales.numeroDocumento;
  return ordenanteRq;
}

/**
 * Metodo para construir request de generacion de formatos - Informacion Ordenantes
 * @param datosOrdenantes objeto con los datos de todos los ordenantes
 * @param idOrdenante Numero de identificacion del ordenante
 */
export function infoOrdenante(datosOrdenantes: Array<DatosOrdenantes>, idOrdenante: string): DatosOrdenantes {
  let participante: DatosOrdenantes;
  datosOrdenantes.forEach(ordenante => {
    if (ordenante.numeroDocumento === idOrdenante) {
      return participante = ordenante;
    }
  });
  return participante;
}
