import { FormGroup } from '@angular/forms';
import { Solicitud } from 'src/app/shared/utils/models/Solicitud/Solicitud';
import { DatosSolicitud } from '../models/api-solicitud/DatosSolicitud';
import { DatosContacto } from '../models/api-solicitud/DatosContacto';
import { ClienteJuridico } from '../models/api-solicitud/ClienteJuridico';
import { DatosGenerales } from '../models/api-solicitud/DatoGenerales';
import { DatosRiesgo } from '../models/api-solicitud/DatosRiesgo';
import { DatosDocumento } from '../models/api-solicitud/DatosDocumento';
import { DocumentoGenerado } from '../models/api-solicitud/DocumentoGenerado';
import { GENERATED_DOCUMENTS } from 'src/app/utils/constants/utils.constant';
import { DatosOperacionesInternacionales } from '../models/api-solicitud/DatosOperacionesInternacionales';
import { DatosPepJuridico } from '../models/api-solicitud/DatosPepJuridico';
import { ValidAddress } from 'src/app/shared/utils/functions/ValidAddress';

export function createSolicitudMapping(idSolicitud: string, formSolicitud: FormGroup, isCustomerFound: boolean, datosCliente?: any) {
  const solicitud = new Solicitud();
  solicitud.idSolicitud = idSolicitud;
  const datosSolicitud = new DatosSolicitud();
  if (datosCliente) {
    solicitud.setDatosSolicitud(datosCliente);
    return solicitud;
  }
  datosSolicitud.clienteJuridico = new ClienteJuridico();
  datosSolicitud.clienteJuridico.clientFound = isCustomerFound;
  datosSolicitud.clienteJuridico.datosGenerales = new DatosGenerales();
  datosSolicitud.clienteJuridico.datosGenerales.tipoDocumento = !!formSolicitud.get("tipoDocumento") ? formSolicitud.get("tipoDocumento").value : "";
  datosSolicitud.clienteJuridico.datosGenerales.numeroDocumento = !!formSolicitud.get("numDocumento") ? formSolicitud.get("numDocumento").value : "";
  solicitud.setDatosSolicitud(datosSolicitud);
  return solicitud;
}

/**
 * Metodo que se encarga de actualizar el BO con los datos en el SOR
 * @param datosSolicitud BO a actualizar los datos
 * @param formSolicitud FormGroup que contiene la informacion a guardar
 */
export function updateDatosContacto(datosSolicitud: DatosSolicitud, formSolicitud: FormGroup, datosRiesgo?: DatosRiesgo) {
  if (formSolicitud.dirty && !!datosSolicitud.clienteJuridico) {
    const validAdress = new ValidAddress();
    datosSolicitud.clienteJuridico.datosContacto = new DatosContacto();
    datosSolicitud.clienteJuridico.datosContacto.comercialRM = formSolicitud.get('comercialRM').value || '';
    datosSolicitud.clienteJuridico.datosContacto.nombre = formSolicitud.get('nombre').value || '';
    datosSolicitud.clienteJuridico.datosContacto.direccion = validAdress.validacionDireccion(formSolicitud.get('direccion').value || '');
    datosSolicitud.clienteJuridico.datosContacto.telefono = formSolicitud.get('telefono').value || '';
    datosSolicitud.clienteJuridico.datosContacto.pais = formSolicitud.get('pais').value || '';
    datosSolicitud.clienteJuridico.datosContacto.departamento = formSolicitud.get('departamento').value || '';
    datosSolicitud.clienteJuridico.datosContacto.ciudad = formSolicitud.get('ciudad').value || '';
    datosSolicitud.clienteJuridico.datosContacto.correo = formSolicitud.get('correo').value || '';
    datosSolicitud.clienteJuridico.datosContacto.checkCorreo = formSolicitud.get('checkCorreo').value || false;
    datosSolicitud.clienteJuridico.datosContacto.correoOpcional = formSolicitud.get('correoOpcional').value || '';
    datosSolicitud.clienteJuridico.datosContacto.tipoEntidad = formSolicitud.get('tipoEntidad').value || '';
    datosSolicitud.clienteJuridico.datosContacto.claseSociedad = formSolicitud.get('claseSociedad').value || '';
    datosSolicitud.clienteJuridico.datosContacto.codigoCIIU = formSolicitud.get('codigoCIIU').value || '';
    if (!(!!datosSolicitud.clienteJuridico.datosPepJuridico)) {
      datosSolicitud.clienteJuridico.datosPepJuridico = new DatosPepJuridico();
    }
    datosSolicitud.clienteJuridico.datosPepJuridico.administraRecPublicos = formSolicitud.get('administraRecPublicos').value || '';
    datosSolicitud.clienteJuridico.datosPepJuridico.clientePEP = formSolicitud.get('clientePEP').value || '';
    datosSolicitud.clienteJuridico.datosPepJuridico.descPerteneceGrupoEmpresarial = formSolicitud.get('descPerteneceGrupoEmpresarial').value || '';
    datosSolicitud.clienteJuridico.datosPepJuridico.descTieneCalificacionRiesgos = formSolicitud.get('descTieneCalificacionRiesgos').value || '';
    datosSolicitud.clienteJuridico.datosPepJuridico.perteneceGrupoEmpresarial = formSolicitud.get('perteneceGrupoEmpresarial').value || '';
    datosSolicitud.clienteJuridico.datosPepJuridico.tieneCalificacionRiesgos = formSolicitud.get('tieneCalificacionRiesgos').value || '';
    datosSolicitud.clienteJuridico.datosPepJuridico.tieneRecPublicoMedComunicacion = formSolicitud.get('tieneRecPublicoMedComunicacion').value || '';
  }
  if (!!datosRiesgo) {
    datosSolicitud.clienteJuridico.datosRiesgo = datosRiesgo;
  }
  return datosSolicitud;
}

/**
 * Metodo que se encarga de actualizar el BO con los datos en el SOR
 * @param datosSolicitud BO a actualizar los datos
 * @param formSolicitud FormGroup que contiene la informacion a guardar
 */
export function updateDatosOperacionInt(datosSolicitud: DatosSolicitud, formSolicitud: FormGroup, listOperations: any) {
  if (!!datosSolicitud.clienteJuridico.datosAdicionales) {
    datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales = new DatosOperacionesInternacionales();
    datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales.operacionMonedaExt = formSolicitud.get('operacionMonedaExt').value || '';
    datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales.tipoProducto = formSolicitud.get('tipoProducto').value || '';
    datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales.nombreEntidad = formSolicitud.get('nombreEntidad').value || '';
    datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales.monto = formSolicitud.get('monto').value || '';
    datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales.pais = formSolicitud.get('pais').value || '';
    datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales.moneda = formSolicitud.get('moneda').value || '';
    const operacion = formSolicitud.get("operaciones").value.map((item, index) => {
      listOperations[index].checked = item;
      return listOperations[index];
    });
    datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales.operacion = operacion;
  }

  return datosSolicitud;
}

/**
 * Metodo que se encarga de obtener los datos laborales del SOR y sincronizarlos en un
 * FormGroup para su posterior edicion
 * @param formSolicitud formulario al cual se le van a actualizar los datos laborales
 * @param datosSolicitud BO que contiene la informacion a recuperar
 */
export function getSolucitudMapping(formSolicitud: FormGroup, datosSolicitud: DatosSolicitud) {
  if (!!datosSolicitud && !!datosSolicitud.clienteJuridico && !!datosSolicitud.clienteJuridico.datosGenerales) {
    const datosBasicos = datosSolicitud.clienteJuridico.datosGenerales;
    formSolicitud.get('tipoDocumento').setValue(datosBasicos.tipoDocumento);
    formSolicitud.get('numeroDocumento').setValue(datosBasicos.numeroDocumento);
  }
  return formSolicitud;
}

/**
 * Metodo que se encarga de obtener los datos de contacto del SOR y sincronizarlos en un
 * FormGroup para su posterior edicion
 * @param formSolicitud formulario al cual se le van a actualizar los datos personales
 * @param datosSolicitud BO que contiene la informacion a recuperar
 */
export function getDatosContacto(formSolicitud: FormGroup, datosSolicitud: DatosSolicitud) {
  if (!!datosSolicitud && !!datosSolicitud.clienteJuridico) {
    if (!!datosSolicitud.clienteJuridico.datosContacto) {
      const datosPersonales = datosSolicitud.clienteJuridico.datosContacto;
      const validAddress = new ValidAddress();
      formSolicitud.get('comercialRM').setValue(datosPersonales.comercialRM || '');
      formSolicitud.get('nombre').setValue(datosPersonales.nombre || '');
      formSolicitud.get('direccion').setValue(validAddress.validacionDireccion(datosPersonales.direccion || ''));
      formSolicitud.get('telefono').setValue(datosPersonales.telefono || '');
      formSolicitud.get('pais').setValue(datosPersonales.pais || '');
      formSolicitud.get('departamento').setValue(datosPersonales.departamento || '');
      formSolicitud.get('ciudad').setValue(datosPersonales.ciudad || '');
      formSolicitud.get('correo').setValue(datosPersonales.correo || '');
      formSolicitud.get('checkCorreo').setValue(datosPersonales.checkCorreo || false);
      formSolicitud.get('correoOpcional').setValue(datosPersonales.correoOpcional || '');
      formSolicitud.get('tipoEntidad').setValue(datosPersonales.tipoEntidad || '');
      formSolicitud.get('claseSociedad').setValue(datosPersonales.claseSociedad || '');
      formSolicitud.get('codigoCIIU').setValue(datosPersonales.codigoCIIU || '');
    }
    if (!!datosSolicitud.clienteJuridico.datosGenerales) {
      const datosGenerales = datosSolicitud.clienteJuridico.datosGenerales;
      formSolicitud.get('numeroDocumento').setValue(datosGenerales.numeroDocumento || '');
    }
    if (!!datosSolicitud.clienteJuridico.datosPepJuridico) {
      const datosPepJuridico = datosSolicitud.clienteJuridico.datosPepJuridico;
      formSolicitud.get('administraRecPublicos').setValue(datosPepJuridico.administraRecPublicos || '');
      formSolicitud.get('clientePEP').setValue(datosPepJuridico.clientePEP || '');
      formSolicitud.get('descPerteneceGrupoEmpresarial').setValue(datosPepJuridico.descPerteneceGrupoEmpresarial || '');
      formSolicitud.get('descTieneCalificacionRiesgos').setValue(datosPepJuridico.descTieneCalificacionRiesgos || '');
      formSolicitud.get('perteneceGrupoEmpresarial').setValue(datosPepJuridico.perteneceGrupoEmpresarial || '');
      formSolicitud.get('tieneCalificacionRiesgos').setValue(datosPepJuridico.tieneCalificacionRiesgos || '');
      formSolicitud.get('tieneRecPublicoMedComunicacion').setValue(datosPepJuridico.tieneRecPublicoMedComunicacion || '');
    }
  }
  return formSolicitud;
}

/**
 * Metodo que se encarga de obtener los datos de Operacines Internacionaless del SOR
 * y sincronizarlos en un FormGroup para su posterior edicion
 * @param formSolicitud formulario al cual se le van a actualizar los datos
 * @param datosSolicitud BO que contiene la informacion a recuperar
 */
export function getDatosOperacionesInt(formSolicitud: FormGroup, datosSolicitud: DatosSolicitud) {
  if (!!datosSolicitud && !!datosSolicitud.clienteJuridico && datosSolicitud.clienteJuridico.datosAdicionales) {
    if (!!datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales) {
      const datosOperacionesInternacionales = datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales;
      formSolicitud.get('operacionMonedaExt').setValue(datosOperacionesInternacionales.operacionMonedaExt || '');
      formSolicitud.get('tipoProducto').setValue(datosOperacionesInternacionales.tipoProducto || '');
      formSolicitud.get('nombreEntidad').setValue(datosOperacionesInternacionales.nombreEntidad || '');
      formSolicitud.get('monto').setValue(datosOperacionesInternacionales.monto);
      formSolicitud.get('pais').setValue(datosOperacionesInternacionales.pais || '');
      formSolicitud.get('moneda').setValue(datosOperacionesInternacionales.moneda || '');
      if (datosSolicitud.clienteJuridico.clientFound) {
        Object.keys(formSolicitud.controls).forEach(key => {
          formSolicitud.get(key).markAllAsTouched();
        });
      }
    }
  }
  return formSolicitud;
}

/**
 * Metodo que se encarga de actualizar el BO con los datos
 * de documentos requeridos en el SOR
 * @param datosSolicitud BO que contiene la informacion a recuperar
 * @param response Lista con los documentos requeridos a almacenar
 */
export function updateDatosDocumento(datosSolicitud: DatosSolicitud, response: any) {
  if (!!response) {
    const solicitados = JSON.parse(response.documentacionSolicitada.value.replace(/'/g, '"'));
    datosSolicitud.clienteJuridico.datosDocumento = new DatosDocumento();
    datosSolicitud.clienteJuridico.datosDocumento.documentosSolicitados = solicitados.documentos;
  }
  return datosSolicitud;
}

/**
 * Metodo que se encarga de actualizar el BO con los datos
 * de generacion de documentos en el SOR
 * @param datosSolicitud BO con informacion del obejto DocumentoGenerado
 * @param response Lista con los documentos requeridos a almacenar
 */
export function getDocumentosGenerados(datosSolicitud: DatosSolicitud) {
  if (!!datosSolicitud && !!datosSolicitud.clienteJuridico && !!datosSolicitud.clienteJuridico.datosDocumento) {
    if (!(!!datosSolicitud.clienteJuridico.datosDocumento.documentosGenerados)) {
      datosSolicitud.clienteJuridico.datosDocumento.documentosGenerados = new Array<DocumentoGenerado>();
      GENERATED_DOCUMENTS.forEach(name => {
        const docGenerated = new DocumentoGenerado();
        docGenerated.nombre = name;
        docGenerated.upload = false;
        docGenerated.view = false;
        datosSolicitud.clienteJuridico.datosDocumento.documentosGenerados.push(docGenerated);
      });
      if (!!datosSolicitud.clienteJuridico.datosOrdenantes && datosSolicitud.clienteJuridico.datosOrdenantes.length > 0) {
        datosSolicitud.clienteJuridico.datosOrdenantes.forEach(ordenante => {
          const docGenerated = new DocumentoGenerado();
          docGenerated.nombre = "Información Ordenantes - " + ordenante.numeroDocumento;
          docGenerated.upload = false;
          docGenerated.view = false;
          datosSolicitud.clienteJuridico.datosDocumento.documentosGenerados.push(docGenerated);
        });
      }
    }
  }
  return datosSolicitud.clienteJuridico.datosDocumento.documentosGenerados;
}
