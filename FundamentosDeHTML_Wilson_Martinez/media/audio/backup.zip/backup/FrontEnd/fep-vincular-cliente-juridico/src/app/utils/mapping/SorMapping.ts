import { DatosSolicitud } from '../models/api-solicitud/DatosSolicitud';
import { ClienteJuridico } from '../models/api-solicitud/ClienteJuridico';
import { DatosAccionistas } from '../models/api-solicitud/DatosAccionistas';
import { DatosGenerales } from '../models/api-solicitud/DatoGenerales';
import { DatosDocumento } from '../models/api-solicitud/DatosDocumento';
import { DatosAdicionales } from '../models/api-solicitud/DatosAdiccionales';
import { DatosFinancieros } from '../models/api-solicitud/DatosFinancieros';

export function setSORData(persona: any, datosExtra: any) {
  const datosSolicitud = new DatosSolicitud();
  const personaJuridica = persona.personaJuridica;
  datosSolicitud.clienteJuridico = new ClienteJuridico();
  datosSolicitud.clienteJuridico.datosContacto = personaJuridica.datosContactoPJ;
  datosSolicitud.clienteJuridico.datosGenerales = new DatosGenerales();
  datosSolicitud.clienteJuridico.datosGenerales.numeroDocumento = datosExtra.numDocumento.replace(/[.]/g, "");
  datosSolicitud.clienteJuridico.datosGenerales.tipoDocumento = datosExtra.tipoDocumento;
  datosSolicitud.clienteJuridico.clientFound = persona.existe;
  datosSolicitud.clienteJuridico.idCliente = persona.idCliente;
  // Datos PEP
  datosSolicitud.clienteJuridico.datosPepJuridico = personaJuridica.datosPepPJ ? personaJuridica.datosPepPJ : undefined;
  datosSolicitud.clienteJuridico.datosPepJuridico.tieneCalificacionRiesgos = personaJuridica.datosPepPJ && personaJuridica.datosPepPJ.tieneCalificacionRiesgos === true ? "si" : "no";
  datosSolicitud.clienteJuridico.datosPepJuridico.tieneRecPublicoMedComunicacion = personaJuridica.datosPepPJ && personaJuridica.datosPepPJ.tieneRecPublicoMedComunicacion === true ? "si" : "no";
  datosSolicitud.clienteJuridico.datosPepJuridico.perteneceGrupoEmpresarial = personaJuridica.datosPepPJ && personaJuridica.datosPepPJ.perteneceGrupoEmpresarial === true ? "si" : "no";
  datosSolicitud.clienteJuridico.datosPepJuridico.administraRecPublicos = personaJuridica.datosPepPJ && personaJuridica.datosPepPJ.administraRecPublicos === true ? "si" : "no";
  datosSolicitud.clienteJuridico.datosPepJuridico.clientePEP = personaJuridica.datosPepPJ && personaJuridica.datosPepPJ.clientePEP === true ? "si" : "no";
  // Datos Riesgo
  datosSolicitud.clienteJuridico.datosRiesgo = personaJuridica.datosRiesgoPJ;
  // Representate legal
  datosSolicitud.clienteJuridico.datosRepresentanteLegal = personaJuridica.listaRepresentantesLegal;
  datosSolicitud.clienteJuridico.datosRepresentanteLegal = datosSolicitud.clienteJuridico.datosRepresentanteLegal
    .map(element => {
      element.datosDocumento = new DatosDocumento();
      element.datosDocumento.documentosSolicitados = {};
      const name = element.tipoDocumento.split("-")[0] + "-" + element.numeroDocumento + ".pdf";
      const ruta = datosSolicitud.clienteJuridico.datosGenerales.tipoDocumento.split("-")[1].trim() + "/"
        + datosSolicitud.clienteJuridico.datosGenerales.numeroDocumento.replace(/\D/g, '') + "/REP/" + name;
      element.datosDocumento.documentosSolicitados["DOC_IDENTIDAD"] = ruta;
      element.isPrincipal = element.isPrincipal ? "si" : "no";
      element.datosCumplimiento = JSON.parse(JSON.stringify(element["datosCumplimientoPJ"]));
      element.datosRiesgo = JSON.parse(JSON.stringify(element["datosRiesgoPJ"]));
      element.datosAml = JSON.parse(JSON.stringify(element["datosAMLPJ"]));
      element["datosAMLPJ"] = element["datosCumplimientoPJ"] = element["datosRiesgoPJ"] = undefined;
      element.isCliente = false;
      return element;
    });
  // Ordenantes
  datosSolicitud.clienteJuridico.datosOrdenantes = personaJuridica.listaOrdenantes;
  datosSolicitud.clienteJuridico.datosOrdenantes = datosSolicitud.clienteJuridico.datosOrdenantes
    .map(element => {
      element.datosDocumento = new DatosDocumento();
      element.datosDocumento.documentosSolicitados = {};
      const name = element.tipoDocumento.split("-")[0] + "-" + element.numeroDocumento + ".pdf";
      const ruta = datosSolicitud.clienteJuridico.datosGenerales.tipoDocumento.split("-")[1].trim() + "/"
        + datosSolicitud.clienteJuridico.datosGenerales.numeroDocumento.replace(/\D/g, '') + "/ORD/" + name;
      element.datosDocumento.documentosSolicitados["DOC_IDENTIDAD"] = ruta;
      element.datosCumplimiento = JSON.parse(JSON.stringify(element["datosCumplimientoPJ"]));
      element.datosRiesgo = JSON.parse(JSON.stringify(element["datosRiesgoPJ"]));
      element.datosAml = JSON.parse(JSON.stringify(element["datosAMLPJ"]));
      element["datosAMLPJ"] = element["datosCumplimientoPJ"] = element["datosRiesgoPJ"] = undefined;
      element.datosAdicionales = Object.assign(element["datosAdicionalesOrdenantePJ"]);
      element["datosAdicionalesOrdenantePJ"] = undefined;
      element.isCliente = false;
      return element;
    });
  // Autorizados
  datosSolicitud.clienteJuridico.datosAutorizados = personaJuridica.listaAutorizados;
  datosSolicitud.clienteJuridico.datosAutorizados = datosSolicitud.clienteJuridico.datosAutorizados
    .map(element => {
      element.datosDocumento = new DatosDocumento();
      element.datosDocumento.documentosSolicitados = {};
      const name = element.tipoDocumento.split("-")[0] + "-" + element.numeroDocumento + ".pdf";
      const ruta = datosSolicitud.clienteJuridico.datosGenerales.tipoDocumento.split("-")[1].trim() + "/"
        + datosSolicitud.clienteJuridico.datosGenerales.numeroDocumento.replace(/\D/g, '') + "/AUT/" + name;
      element.datosDocumento.documentosSolicitados["DOC_IDENTIDAD"] = ruta;
      element.datosCumplimiento = JSON.parse(JSON.stringify(element["datosCumplimientoPJ"]));
      element.datosRiesgo = JSON.parse(JSON.stringify(element["datosRiesgoPJ"]));
      element.datosAml = JSON.parse(JSON.stringify(element["datosAMLPJ"]));
      element["datosAMLPJ"] = element["datosCumplimientoPJ"] = element["datosRiesgoPJ"] = undefined;
      element.isCliente = false;
      return element;
    });
  // Accionistas
  datosSolicitud.clienteJuridico.datosAccionistas = new DatosAccionistas();
  datosSolicitud.clienteJuridico.datosAccionistas.emisorInscrito = personaJuridica.datosAccionistasPJ.emisorInscrito;
  datosSolicitud.clienteJuridico.datosAccionistas.accionistas = personaJuridica.datosAccionistasPJ.listaAccionistaPJS;
  datosSolicitud.clienteJuridico.datosAccionistas.accionistas = datosSolicitud.clienteJuridico.datosAccionistas.accionistas
    .map(element => {
      element.datosDocumento = new DatosDocumento();
      element.datosDocumento.documentosSolicitados = {};
      const name = element.tipoDocumento.split("-")[0] + "-" + element.numeroDocumento + ".pdf";
      const ruta = datosSolicitud.clienteJuridico.datosGenerales.tipoDocumento.split("-")[1].trim() + "/"
        + datosSolicitud.clienteJuridico.datosGenerales.numeroDocumento.replace(/\D/g, '') + "/ACC/" + name;
      element.datosDocumento.documentosSolicitados["DOC_IDENTIDAD"] = ruta;
      element.datosCumplimiento = JSON.parse(JSON.stringify(element["datosCumplimientoPJ"]));
      element.datosRiesgo = JSON.parse(JSON.stringify(element["datosRiesgoPJ"]));
      element.datosAml = JSON.parse(JSON.stringify(element["datosAMLPJ"]));
      element["datosAMLPJ"] = element["datosCumplimientoPJ"] = element["datosRiesgoPJ"] = undefined;
      element.isCliente = false;
      return element;
    });
  // Terceros
  datosSolicitud.clienteJuridico.datosTerceros = personaJuridica.listaTerceros;
  datosSolicitud.clienteJuridico.datosTerceros = datosSolicitud.clienteJuridico.datosTerceros
    .map(element => {
      element.datosDocumento = new DatosDocumento();
      element.datosDocumento.documentosSolicitados = {};
      const name = element.tipoDocumento.split("-")[0] + "-" + element.numeroDocumento + ".pdf";
      const ruta = datosSolicitud.clienteJuridico.datosGenerales.tipoDocumento.split("-")[1].trim() + "/"
        + datosSolicitud.clienteJuridico.datosGenerales.numeroDocumento.replace(/\D/g, '') + "/TER/" + name;
      element.datosDocumento.documentosSolicitados["DOC_IDENTIDAD"] = ruta;
      element.datosCumplimiento = JSON.parse(JSON.stringify(element["datosCumplimientoPJ"]));
      element.datosRiesgo = JSON.parse(JSON.stringify(element["datosRiesgoPJ"]));
      element.datosAml = JSON.parse(JSON.stringify(element["datosAMLPJ"]));
      element["datosAMLPJ"] = element["datosCumplimientoPJ"] = element["datosRiesgoPJ"] = undefined;
      element.isCliente = false;
      return element;
    });
  // Datos Adicionales
  datosSolicitud.clienteJuridico.datosAdicionales = new DatosAdicionales();
  datosSolicitud.clienteJuridico.datosAdicionales.idDatosAdicionales = personaJuridica.datosAdicionalesPJ.idDatosAdicionales;
  datosSolicitud.clienteJuridico.datosAdicionales.datosClasificacionFatca = personaJuridica.datosAdicionalesPJ.datosFatcaPJ;
  datosSolicitud.clienteJuridico.datosAdicionales.datosCuentaBancaria = personaJuridica.datosAdicionalesPJ.datosCuentaBancariaPJ;
  datosSolicitud.clienteJuridico.datosAdicionales.datosFinancieros = new DatosFinancieros();
  datosSolicitud.clienteJuridico.datosAdicionales.datosFinancieros.idDatosFinancieros = !!personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.idDatosFinancieros ? personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.idDatosFinancieros : null;
  datosSolicitud.clienteJuridico.datosAdicionales.datosFinancieros.ingresosMensuales = !!personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.ingresoMensual ? personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.ingresoMensual : null;
  datosSolicitud.clienteJuridico.datosAdicionales.datosFinancieros.egresosMensuales = !!personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.egresoMensual ? personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.egresoMensual : null;
  datosSolicitud.clienteJuridico.datosAdicionales.datosFinancieros.activos = !!personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.activos ? personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.activos : null;
  datosSolicitud.clienteJuridico.datosAdicionales.datosFinancieros.otrosIngresos = !!personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.otrosIngresos ? personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.otrosIngresos : null;
  datosSolicitud.clienteJuridico.datosAdicionales.datosFinancieros.otrosEgresos = !!personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.otrosEgresos ? personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.otrosEgresos : null;
  datosSolicitud.clienteJuridico.datosAdicionales.datosFinancieros.pasivos = !!personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.pasivos ? personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.pasivos : null;
  datosSolicitud.clienteJuridico.datosAdicionales.datosFinancieros.totalIngresos = !!personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.totalIngresos ? personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.totalIngresos : null;
  datosSolicitud.clienteJuridico.datosAdicionales.datosFinancieros.totalEgresos = !!personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.totalEgresos ? personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.totalEgresos : null;
  datosSolicitud.clienteJuridico.datosAdicionales.datosFinancieros.patrimonio = !!personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.patrimonio ? personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.patrimonio : null;
  datosSolicitud.clienteJuridico.datosAdicionales.datosFinancieros.detalleIngresos = !!personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.detalleIngreso ? personaJuridica.datosAdicionalesPJ.datosFinancierosPJ.detalleIngreso : null;
  datosSolicitud.clienteJuridico.datosAdicionales.datosInformacionTributaria = personaJuridica.datosAdicionalesPJ.datosInformacionTributariaPJ;
  datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales = personaJuridica.datosAdicionalesPJ.datosOperacionesInternacionalesPJ;
  datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales.operacion =
    JSON.parse(JSON.stringify(datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales["listaOperacionesInternacionales"]));
  datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales.operacion = datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales.operacion
    .map(operacion => {
      operacion.name = operacion["nombre"].toString(),
        operacion["nombre"] = undefined;
      return operacion;
    });
  datosSolicitud.clienteJuridico.datosAdicionales.datosOperacionesInternacionales["listaOperacionesInternacionales"] = undefined;
  return datosSolicitud;
}
