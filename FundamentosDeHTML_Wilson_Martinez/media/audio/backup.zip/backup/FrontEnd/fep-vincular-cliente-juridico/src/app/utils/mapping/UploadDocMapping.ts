import { UploadDocRq } from '../../shared/utils/models/api-documentos/UploadDocRq';
import { DatosGenerales } from '../models/api-solicitud/DatoGenerales';

/**
 * Metodo para scanear y almacenar un documento de identodad
 * @param doc objeto con informacion del documento
 * @param pdf documento en base 64
 * @param cliente objeto con los datos del cliente
 */
export function scanUploadDoc(file: File, participantType: string, cliente: DatosGenerales) {
    const formData = new FormData();
    const urlBase = cliente.tipoDocumento.split("-")[1] + '/' + cliente.numeroDocumento.replace(/\D/g, '');
    formData.append("file", file);
    formData.append("fileName", "_");
    formData.append("documentId", participantType);
    formData.append("documentType", urlBase);

    return formData;
}

/**
 * Metodo par obtener un documento a partir de los datos del cliente
 * mediante el api-documentos
 * @param nameDoc nombre del documento
 * @param cliente objeto con los datos del cliente
 */
export function getScanDoc(pathFile: string, participantType: string, cliente: DatosGenerales) {
    const documentRq = new UploadDocRq();
    documentRq.documentId = cliente.numeroDocumento.replace(/\D/g, '');
    documentRq.documentType = cliente.tipoDocumento.split("-")[1].trim();
    documentRq.fileName = pathFile;

    return documentRq;
}

/**
 * Metodo para subir un documento por medio del api-documentpos
 * @param doc objeto con informacion del documento
 * @param pdf documento en base 64
 * @param cliente objeto con los datos del cliente
 */
export function uploadDoc (file: File, docType: string, cliente: DatosGenerales, optionalName?: string): FormData {
    const fileName = cliente.tipoDocumento.split("-")[1].trim() + "/" + cliente.numeroDocumento.replace(/\D/g, '') + "/" + docType + "/" + (!!optionalName ? optionalName : file.name);
    const formData = new FormData();
    formData.append("file", file);
    formData.append("fileName", fileName);
    formData.append("documentId", cliente.numeroDocumento.replace(/\D/g, ''));
    formData.append("documentType", cliente.tipoDocumento.split("-")[1]);

    return formData;
}

/**
 * Metodo par obtener un documento a partir de los datos del cliente
 * mediante el api-documentos
 * @param nameDoc nombre del documento
 * @param cliente objeto con los datos del cliente
 */
export function getDoc (nameDoc: string, docType: string, cliente: DatosGenerales, optionalName?: string): UploadDocRq {
    const fileName = cliente.tipoDocumento.split("-")[1].trim() + "/" + cliente.numeroDocumento.replace(/\D/g, '') + "/" + docType + "/" + (!!optionalName ? optionalName : nameDoc);
    const documentRq = new UploadDocRq();
    documentRq.documentId = cliente.numeroDocumento.replace(/\D/g, '');
    documentRq.documentType = cliente.tipoDocumento.split("-")[1];
    documentRq.fileName = fileName;

    return documentRq;
}

/**
 * Metodo para eliminar un documento a partir de el nombre del documento
 * y de la informacion del cliente
 * @param nameDoc nombre del documento a eliminar
 * @param cliente objeto con los datos basicos del cliente
 */
export function deleteDocSoporte (nameDoc: string, docType: string, cliente: DatosGenerales, optionalName?: string): UploadDocRq {
    const fileName = cliente.tipoDocumento.split("-")[1].trim() + "/" + cliente.numeroDocumento.replace(/\D/g, '') + "/" + docType + "/" + (!!optionalName ? optionalName : nameDoc);
    const documentRq = new UploadDocRq();
    documentRq.documentId = cliente.numeroDocumento.replace(/\D/g, '');
    documentRq.documentType = cliente.tipoDocumento.split("-")[1];
    documentRq.fileName = fileName;

    return documentRq;
}
