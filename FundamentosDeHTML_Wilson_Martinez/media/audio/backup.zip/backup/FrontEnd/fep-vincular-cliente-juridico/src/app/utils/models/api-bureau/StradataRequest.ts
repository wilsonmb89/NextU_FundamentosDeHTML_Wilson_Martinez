export class StradataRequest {
	nombre: string;
	tipoDoc: string;
	numeroDoc: string;
}
