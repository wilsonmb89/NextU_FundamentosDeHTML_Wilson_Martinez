import { ParticipantePJ } from './ParticipantePJ';
import { EstradataPJ } from './EstradataPJ';

export class AccionistaPJ extends ParticipantePJ {
  paisNacimiento: string = null;
  participacion: string = null;

  constructor() {
    super();
  }
  getObject() {
    const object = JSON.parse(JSON.stringify(this));
    object.datosRiesgoPJ.listaEstradata = new EstradataPJ();
    return object;
  }
}
