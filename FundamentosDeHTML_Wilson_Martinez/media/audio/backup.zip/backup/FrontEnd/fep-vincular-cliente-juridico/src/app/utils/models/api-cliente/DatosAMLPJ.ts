export class DatosAMLPJ {
  idDatosAML: number = null;
  motivo: string = null;
  decision: string = null;
  idUsuario: string = null;
  nombreUsuario: string = null;
  fecha: string = null;

  constructor() { }
}
