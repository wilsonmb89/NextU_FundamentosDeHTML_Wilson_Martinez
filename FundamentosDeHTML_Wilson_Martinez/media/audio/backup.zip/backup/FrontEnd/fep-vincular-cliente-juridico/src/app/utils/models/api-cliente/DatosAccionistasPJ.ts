import { AccionistaPJ } from './AccionistaPJ';

export class DatosAccionistasPJ {
  idDatosAccionistas: number = null;
  emisorInscrito: string = null;
  listaAccionistaPJS: Array<AccionistaPJ>;

  constructor() {
    this.listaAccionistaPJS = new Array<AccionistaPJ>();
  }
  getObject() {
    return {
      emisorInscrito: null,
      listaAccionistaPJS: new AccionistaPJ().getObject(),
    };
  }
}
