export class DatosAdicionalesOrdenantePJ {
  idDatosAdicionales: number;
  vinculoEmpresa: string = null;
  nombreEmpresa: string = null;
  direccionEmpresa: string = null;
  cargo: string = null;
  paisEmpresa: string = null;
  deptoEmpresa: string = null;
  ciudadEmpresa: string = null;
  telEmpresa: string = null;
  ingresoMensual: number = null;
  egresoMensual: number = null;
  otrosIngresos: number = null;
  otrosEgresos: number = null;
  totalIngresos: number = null;
  totalEgresos: number = null;
  activos: number = null;
  pasivos: number = null;
  patrimonio: number = null;
  detalleIngreso: string = null;
  detalleEgreso: string = null;

  constructor() { }
}
