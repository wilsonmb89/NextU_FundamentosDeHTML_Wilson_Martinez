import { DatosFinancierosPJ } from './DatosFinancierosPJ';
import { DatosFatcaPJ } from './DatosFatcaPJ';
import { DatosCuentaBancariaPJ } from './DatosCuentaBancariaPJ';
import { DatosOperacionesInternacionalesPJ } from './DatosOperacionesInternacionalesPJ';
import { DatosInformacionTibutariaPJ } from './DatosInformacionTributariaPJ';

export class DatosAdicionalesPJ {
  idDatosAdicionales: number = null;
  datosFinancierosPJ: DatosFinancierosPJ;
  datosFatcaPJ: DatosFatcaPJ;
  datosCuentaBancariaPJ: DatosCuentaBancariaPJ;
  datosOperacionesInternacionalesPJ: DatosOperacionesInternacionalesPJ;
  datosInformacionTributariaPJ: DatosInformacionTibutariaPJ;

  constructor() {
    this.datosFinancierosPJ = new DatosFinancierosPJ();
    this.datosFatcaPJ = new DatosFatcaPJ();
    this.datosCuentaBancariaPJ = new DatosCuentaBancariaPJ();
    this.datosOperacionesInternacionalesPJ = new DatosOperacionesInternacionalesPJ();
    this.datosInformacionTributariaPJ = new DatosInformacionTibutariaPJ();
  }
  getObject() {
    const object = JSON.parse(JSON.stringify(this));
    object.datosOperacionesInternacionalesPJ = new DatosOperacionesInternacionalesPJ().getObject();
    return object;
  }
}
