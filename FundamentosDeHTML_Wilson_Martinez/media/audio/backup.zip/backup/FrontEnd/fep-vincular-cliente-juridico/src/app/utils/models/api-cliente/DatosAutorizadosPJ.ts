import { ParticipantePJ } from './ParticipantePJ';
import { EstradataPJ } from './EstradataPJ';

export class DatosAutorizadosPJ extends ParticipantePJ {

  constructor() {
    super();
  }
  getObject() {
    const object = JSON.parse(JSON.stringify(this));
    object.datosRiesgoPJ.listaEstradata = new EstradataPJ();
    return object;
  }
}
