export class DatosFinancierosPJ {
  idDatosFinancieros: number = null;
  ingresoMensual: number = null;
  egresoMensual: number = null;
  activos: number = null;
  otrosIngresos: number = null;
  otrosEgresos: number = null;
  pasivos: number = null;
  totalIngresos: number = null;
  totalEgresos: number = null;
  patrimonio: number = null;
  detalleIngreso: string = null;

  constructor() { }
}
