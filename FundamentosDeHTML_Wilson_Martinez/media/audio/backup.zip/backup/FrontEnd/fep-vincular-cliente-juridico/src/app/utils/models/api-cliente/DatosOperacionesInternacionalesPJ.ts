import { OperacionInternacionalPJ } from './OperacionInternacionalPJ';

export class DatosOperacionesInternacionalesPJ {
  idDatosOpInternacionales: number = null;
  operacionMonedaExt: string = null;
  listaOperacionesInternacionales: Array<OperacionInternacionalPJ>;
  tipoProducto: string = null;
  nombreEntidad: string = null;
  monto: number = null;
  pais: string = null;
  moneda: string = null;

  constructor() {
    this.listaOperacionesInternacionales = new Array<OperacionInternacionalPJ>();
  }
  getObject() {
    const object = JSON.parse(JSON.stringify(this));
    object.listaOperacionesInternacionales = new OperacionInternacionalPJ();
    return object;
  }
}
