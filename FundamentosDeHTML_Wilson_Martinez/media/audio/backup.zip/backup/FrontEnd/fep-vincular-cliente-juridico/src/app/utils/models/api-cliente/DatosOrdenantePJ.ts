import { ParticipantePJ } from './ParticipantePJ';
import { DatosAdicionalesOrdenantePJ } from './DatosAdicionalesOrdenantePJ';
import { EstradataPJ } from './EstradataPJ';


export class DatosOrdenantePJ extends ParticipantePJ {
  paisExpedicion: string = null;
  departamentoExpedicion: string = null;
  ciudadExpedicion: string = null;
  fechaExpedicion: string = null;
  paisNacimiento: string = null;
  departamentoNacimiento: string = null;
  ciudadNacimiento: string = null;
  direccionResidencia: string = null;
  paisResidencia: string = null;
  departamentoResidencia: string = null;
  ciudadResidencia: string = null;
  ocupacion: string = null;
  codigoCIIU: string = null;
  datosAdicionalesOrdenantePJ: DatosAdicionalesOrdenantePJ;

  constructor() {
    super();
    this.datosAdicionalesOrdenantePJ = new DatosAdicionalesOrdenantePJ();
  }
  getObject() {
    const object = JSON.parse(JSON.stringify(this));
    object.datosRiesgoPJ.listaEstradata = new EstradataPJ();
    return object;
  }
}
