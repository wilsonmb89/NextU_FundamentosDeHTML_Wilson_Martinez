export class DatosPepPJ {
  idDatosPEP: number = null;
  perteneceGrupoEmpresarial: boolean = null;
  descPerteneceGrupoEmpresarial: string = null;
  tieneCalificacionRiesgos: boolean = null;
  descTieneCalificacionRiesgos: string = null;
  administraRecPublicos: boolean = null;
  tieneRecPublicoMedComunicacion: boolean = null;
  clientePEP: boolean = null;

  constructor() { }
}
