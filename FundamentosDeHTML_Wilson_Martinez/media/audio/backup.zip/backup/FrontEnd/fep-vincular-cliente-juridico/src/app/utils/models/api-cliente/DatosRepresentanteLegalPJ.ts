import { ParticipantePJ } from './ParticipantePJ';
import { EstradataPJ } from './EstradataPJ';

export class DatosRepresentanteLegalPJ extends ParticipantePJ {
  paisExpedicion: string = null;
  departamentoExpedicion: string = null;
  ciudadExpedicion: string = null;
  fechaExpedicion: string = null;
  paisNacimiento: string = null;
  departamentoNacimiento: string = null;
  ciudadNacimiento: string = null;
  direccionResidencia: string = null;
  paisResidencia: string = null;
  departamentoResidencia: string = null;
  ciudadResidencia: string = null;
  isPrincipal: boolean = null;
  ocupacion: string = null;
  codigoCIIU: string = null;

  constructor() {
      super();
  }
  getObject() {
    const object = JSON.parse(JSON.stringify(this));
    object.datosRiesgoPJ.listaEstradata = new EstradataPJ();
    return object;
  }
}
