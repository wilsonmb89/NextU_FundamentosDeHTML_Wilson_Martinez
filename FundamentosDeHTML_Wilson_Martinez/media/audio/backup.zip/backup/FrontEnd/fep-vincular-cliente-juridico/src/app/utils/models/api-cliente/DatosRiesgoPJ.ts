import { EstradataPJ } from './EstradataPJ';

export class DatosRiesgoPJ {
  idDatosRiesgo: number = null;
  nombreProcuraduria: string = null;
  continuarPorProcuraduria: boolean = null;
  isPep: string = null;
  porcentajePep: number = null;
  pepReasons: string = null;
  isMedia: boolean = null;
  porcentajeMedia: number = null;
  listasVinculantes: boolean = null;
  porcentajeListaVinculante: number = null;
  listasNoVinculantes: boolean = null;
  porcentajeListaNoVinculante: number = null;
  listaEstradata: Array<EstradataPJ>;
  siapRisk: string = null;
  scapRisk: string = null;
  risk: string = null;

  constructor() {
    this.listaEstradata = new Array<EstradataPJ>();
  }
  getObject() {
    const object = JSON.parse(JSON.stringify(this));
    object.listaEstradata = new EstradataPJ();
    return object;
  }
}
