export class EstradataPJ {
  idEstradata: number = null;
  nombreLista: string = null;
  porcentaje: string = null;
  nacionalidad: string = null;
  identificacion: string = null;

  constructor() {}
}
