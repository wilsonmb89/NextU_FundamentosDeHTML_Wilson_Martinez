export class OperacionInternacionalPJ {
  idOperacionInternacional: number = null;
  nombre: string = null;
  checked: boolean = null;

  constructor() { }
}
