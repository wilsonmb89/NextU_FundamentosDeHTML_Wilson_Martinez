import { DatosRiesgoPJ } from './DatosRiesgoPJ';
import { DatosAMLPJ } from './DatosAMLPJ';
import { DatosCumplimientoPJ } from './DatosCumplimientoPJ';

export class ParticipantePJ {
  idParticipante: number = null;
  nombre: string = null;
  tipoDocumento: string = null;
  numeroDocumento: string = null;
  datosRiesgoPJ: DatosRiesgoPJ;
  datosAMLPJ: DatosAMLPJ;
  datosCumplimientoPJ: DatosCumplimientoPJ;

  constructor() {
    this.datosRiesgoPJ = new DatosRiesgoPJ();
    this.datosAMLPJ = new DatosAMLPJ();
    this.datosCumplimientoPJ = new DatosCumplimientoPJ();
  }
}
