import { DatosContactoPJ } from './DatosContactoPJ';
import { DatosRepresentanteLegalPJ } from './DatosRepresentanteLegalPJ';
import { DatosOrdenantePJ } from './DatosOrdenantePJ';
import { DatosAccionistasPJ } from './DatosAccionistasPJ';
import { DatosAutorizadosPJ } from './DatosAutorizadosPJ';
import { DatosTercerosPJ } from './DatosTercerosPJ';
import { DatosAMLPJ } from './DatosAMLPJ';
import { DatosPepPJ } from './DatosPepPJ';
import { DatosAdicionalesPJ } from './DatosAdicionalesPJ';
import { DatosRiesgoPJ } from './DatosRiesgoPJ';
import { DatosCumplimientoPJ } from './DatosCumplimientoPJ';

export class PersonaJuridica {
  idPersona: number;
  tipoIdentificacion: string;
  numeroIdentificacion: string;
  datosContactoPJ: DatosContactoPJ;
  listaRepresentantesLegal: Array<DatosRepresentanteLegalPJ>;
  listaOrdenantes: Array<DatosOrdenantePJ>;
  datosAccionistasPJ: DatosAccionistasPJ;
  listaAutorizados: Array<DatosAutorizadosPJ>;
  listaTerceros: Array<DatosTercerosPJ>;
  datosRiesgoPJ: DatosRiesgoPJ;
  datosAMLPJ: DatosAMLPJ;
  datosCumplimientoPJ: DatosCumplimientoPJ;
  datosPepPJ: DatosPepPJ;
  datosAdicionalesPJ: DatosAdicionalesPJ;

  constructor() {
    this.datosContactoPJ = new DatosContactoPJ();
    this.listaRepresentantesLegal = new Array<DatosRepresentanteLegalPJ>();
    this.listaOrdenantes = new Array<DatosOrdenantePJ>();
    this.datosAccionistasPJ = new DatosAccionistasPJ();
    this.listaAutorizados = new Array<DatosAutorizadosPJ>();
    this.listaTerceros = new Array<DatosTercerosPJ>();
    this.datosRiesgoPJ = new DatosRiesgoPJ();
    this.datosAMLPJ = new DatosAMLPJ();
    this.datosCumplimientoPJ = new DatosCumplimientoPJ();
    this.datosPepPJ = new DatosPepPJ();
    this.datosAdicionalesPJ = new DatosAdicionalesPJ();
  }
  getObjectPart1() {
    return {
      datosContactoPJ: new DatosContactoPJ(),
      listaRepresentantesLegal: new DatosRepresentanteLegalPJ().getObject(),
      datosAccionistasPJ: new DatosAccionistasPJ().getObject(),
      listaAutorizados: new DatosAutorizadosPJ().getObject()
    };
  }
  getObjectPart2() {
    return {
      listaTerceros: new DatosTercerosPJ().getObject(),
      listaOrdenantes: new DatosOrdenantePJ().getObject(),
      datosRiesgoPJ: new DatosRiesgoPJ().getObject(),
      datosAMLPJ: new DatosAMLPJ()
    };
  }
  getObjectPart3() {
    return {
      datosCumplimientoPJ: new DatosCumplimientoPJ(),
      datosPepPJ: new DatosPepPJ(),
      datosAdicionalesPJ: new DatosAdicionalesPJ().getObject()
    };
  }
}
