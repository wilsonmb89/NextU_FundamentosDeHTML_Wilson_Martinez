import { Participante } from './Participante';

export class Accionista extends Participante {
    paisNacimiento: string = null;
    participacion: string = null;

    constructor() {
        super();
    }
}
