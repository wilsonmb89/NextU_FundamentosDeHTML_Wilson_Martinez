import { DatosGenerales } from './DatoGenerales';
import { DatosContacto } from './DatosContacto';
import { DatosRepresentanteLegal } from './DatosRepresentanteLegal';
import { DatosOrdenantes } from './DatosOrdenantes';
import { DatosTerceros } from './DatosTerceros';
import { DatosDocumento } from './DatosDocumento';
import { DatosRiesgo } from './DatosRiesgo';
import { DatosAutorizados } from './DatosAutorizados';
import { DatosAccionistas } from './DatosAccionistas';
import { DatosAML } from './DatosAML';
import { DatosPepJuridico } from './DatosPepJuridico';
import { DatosAdicionales } from './DatosAdiccionales';
import { DatosActualizacionPantallas } from './datosActualizacionPantallas';

export class ClienteJuridico {
    idCliente: number;
    tipoCliente: string;
    clientFound: boolean;
    datosGenerales: DatosGenerales;
    datosContacto: DatosContacto;
    datosRepresentanteLegal: DatosRepresentanteLegal[];
    datosOrdenantes: DatosOrdenantes[];
    datosAccionistas: DatosAccionistas;
    datosAutorizados: DatosAutorizados[];
    datosTerceros: DatosTerceros[];
    datosDocumento: DatosDocumento;
    datosRiesgo: DatosRiesgo;
    datosAml: DatosAML;
    datosCumplimiento: DatosAML;
    datosPepJuridico: DatosPepJuridico;
    datosAdicionales: DatosAdicionales;
    datosActualizacionPantallas: DatosActualizacionPantallas;
}
