export class DatosGenerales {
    tipoDocumento: string;
    numeroDocumento: string;
}
