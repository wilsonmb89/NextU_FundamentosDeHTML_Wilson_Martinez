export class DatosAML {
    idDatosAML: number;
    motivo: string;
    decision: string;
    idUsuario: string;
    nombre: string;
    fecha: string;
    revisionOk: boolean;
}
