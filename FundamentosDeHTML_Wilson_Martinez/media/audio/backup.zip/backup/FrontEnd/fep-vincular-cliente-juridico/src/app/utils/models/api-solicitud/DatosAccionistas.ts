import { Accionista } from './Accionista';

export class DatosAccionistas {
    idDatosAccionistas: number;
    emisorInscrito: string = null;
    accionistas: Accionista[] = new Array<Accionista>();
}
