import { DatosFinancieros } from './DatosFinancieros';
import { DatosClasificacionFatca } from './DatosClasificacionFatca';
import { DatosCuentaBancaria } from './DatosCuentaBancaria';
import { DatosInformacionTibutaria } from './DatosInformacionTibutaria';
import { DatosOperacionesInternacionales } from './DatosOperacionesInternacionales';

export class DatosAdicionales {
    idDatosAdicionales: number;
    datosFinancieros: DatosFinancieros;
    datosClasificacionFatca: DatosClasificacionFatca;
    datosCuentaBancaria: DatosCuentaBancaria;
    datosInformacionTributaria: DatosInformacionTibutaria;
    datosOperacionesInternacionales: DatosOperacionesInternacionales;
}
