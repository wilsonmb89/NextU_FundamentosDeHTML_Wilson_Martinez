import { Participante } from './Participante';

export class DatosAutorizados extends Participante {

    constructor() {
        super();
    }
}
