export class DatosClasificacionFatca {
    idDatosFacta: number;
    tipoEntidad: string = null;
    entidadInversion: string = null;
    otraEntidadInversion: string = null;
    institucionCustodia: string = null;
    nombreDeLaBolsa: string = null;
    nombreDeLaEntidad: string = null;
    entidadVigilada: string = null;
    emisorInscrito: string = null;
    transfiereFondos: string = null;
    paisResidencia: string = null;
    numeroIdentificacionTributaria: string = null;
    otroPaisResidencia: string = null;
    otroNumeroIdentificacionTributaria: string = null;
    razonNoTin: string = null;
    descripcionRazonNoTin: string = null;
}
