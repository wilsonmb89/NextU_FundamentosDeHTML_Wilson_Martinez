export class DatosContacto {
    idDatosContacto: number = null;
    comercialRM: string = null;
    nombre: string = null;
    direccion: string = null;
    telefono: string = null;
    pais: string = null;
    departamento: string = null;
    ciudad: string = null;
    correo: string = null;
    checkCorreo: boolean = null;
    correoOpcional: string = null;
    tipoEntidad: string = null;
    claseSociedad: string = null;
    codigoCIIU: string = null;
}
