export class DatosCuentaBancaria {
  idDatosCuentaBancaria: number;
  nombreTitular: string = null;
  cedulaCiudadania: string = null;
  nombreBanco: string = null;
  tipoCuenta: string = null;
  numeroCuenta: string = null;
}
