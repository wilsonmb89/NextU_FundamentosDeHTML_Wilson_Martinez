import { DocumentoGenerado } from './DocumentoGenerado';

export class DatosDocumento {
  documentosSolicitados: any;
  documentosGenerados: Array<DocumentoGenerado>;
}
