export class DatosFinancieros {
  idDatosFinancieros: number;
  ingresosMensuales: number = null;
  egresosMensuales: number = null;
  activos: number = null;
  otrosIngresos: number = null;
  otrosEgresos: number = null;
  pasivos: number = null;
  totalIngresos: number = null;
  totalEgresos: number = null;
  patrimonio: number = null;
  detalleIngresos: string = null;
}
