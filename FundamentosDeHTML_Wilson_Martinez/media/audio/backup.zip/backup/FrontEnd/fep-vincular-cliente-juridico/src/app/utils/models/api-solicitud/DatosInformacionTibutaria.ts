export class DatosInformacionTibutaria {
    idDatosTributarios: number;
    contribuyenteImpuesto: string = null;
    tipoContribuyente: string = null;
    otroContribuyente: string = null;
    tipoRegimen: string = null;
    numeroResolucionRegimen: string = null;
    granContribuyente: string = null;
    autoRetenedorRendimientos: string = null;
    numeroResolucionRetenedor: string = null;
    exentoGMF: string = null;
}
