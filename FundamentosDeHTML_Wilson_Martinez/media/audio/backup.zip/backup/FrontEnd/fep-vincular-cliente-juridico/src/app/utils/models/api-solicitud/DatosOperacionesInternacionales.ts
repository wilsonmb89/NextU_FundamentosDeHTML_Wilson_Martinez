import { Operacion } from './Operacion';

export class DatosOperacionesInternacionales {
  idDatosOpInternacionales: number;
  operacionMonedaExt: string;
  operacion: Array<Operacion>;
  tipoProducto: string;
  nombreEntidad: string;
  monto: number;
  pais: string;
  moneda: string;

  constructor() {
    this.operacion = new Array<Operacion>();
  }

}
