import { Participante } from './Participante';
import { DatosAdicionalesOrdenante } from './DatosAdicionalesOrdenante';

export class DatosOrdenantes extends Participante {
    paisExpedicion: string = null;
    departamentoExpedicion: string = null;
    ciudadExpedicion: string = null;
    fechaExpedicion: string = null;
    paisNacimiento: string = null;
    departamentoNacimiento: string = null;
    ciudadNacimiento: string = null;
    direccionResidencia: string = null;
    paisResidencia: string = null;
    departamentoResidencia: string = null;
    ciudadResidencia: string = null;
    ocupacion: string = null;
    codigoCIIU: string = null;
    datosAdicionales: DatosAdicionalesOrdenante;

    constructor() {
        super();
    }
}
