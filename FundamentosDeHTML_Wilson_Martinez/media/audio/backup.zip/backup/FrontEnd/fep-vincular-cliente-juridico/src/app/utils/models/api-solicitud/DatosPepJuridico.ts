export class DatosPepJuridico {
  idDatosPEP: number = null;
  perteneceGrupoEmpresarial: string;
  descPerteneceGrupoEmpresarial: string;
  tieneCalificacionRiesgos: string;
  descTieneCalificacionRiesgos: string;
  administraRecPublicos: string;
  tieneRecPublicoMedComunicacion: string;
  clientePEP: string;
}
