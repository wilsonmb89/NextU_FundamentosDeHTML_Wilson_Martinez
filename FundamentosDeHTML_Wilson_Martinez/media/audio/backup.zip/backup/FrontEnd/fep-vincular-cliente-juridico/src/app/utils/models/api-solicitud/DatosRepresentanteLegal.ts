import { Participante } from './Participante';

export class DatosRepresentanteLegal extends Participante {
    paisExpedicion: string = null;
    departamentoExpedicion: string = null;
    ciudadExpedicion: string = null;
    fechaExpedicion: string = null;
    paisNacimiento: string = null;
    departamentoNacimiento: string = null;
    ciudadNacimiento: string = null;
    direccionResidencia: string = null;
    paisResidencia: string = null;
    departamentoResidencia: string = null;
    ciudadResidencia: string = null;
    isPrincipal = "no";
    ocupacion: string = null;
    codigoCIIU: string = null;

    constructor() {
        super();
    }
}
