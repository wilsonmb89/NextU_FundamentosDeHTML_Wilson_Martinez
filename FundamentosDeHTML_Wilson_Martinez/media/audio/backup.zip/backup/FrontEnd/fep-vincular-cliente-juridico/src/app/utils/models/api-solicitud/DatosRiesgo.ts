import { Estradata } from './Estradata';

export class DatosRiesgo {
  idDatosRiesgo: number;
  nombreProcuraduria: string;
  continuarPorProcuraduria: boolean;
  isPep: string;
  porcentajePep: number;
  pepReasons: string;
  isMedia: boolean;
  porcentajeMedia: number;
  listasVinculantes: boolean;
  porcentajeListaVinculante: number;
  listasNoVinculantes: boolean;
  porcentajeListaNoVinculante: number;
  listasReportado: Array<Estradata>;
  siapRisk: string;
  scapRisk: string;
  risk: string;

  constructor() {
    this.listasReportado = new Array<Estradata>();
  }
}
