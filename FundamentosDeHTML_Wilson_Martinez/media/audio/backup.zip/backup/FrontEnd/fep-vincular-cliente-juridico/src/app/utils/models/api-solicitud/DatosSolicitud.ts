import { ClienteJuridico } from 'src/app/utils/models/api-solicitud/ClienteJuridico';

export class DatosSolicitud {
    clienteJuridico: ClienteJuridico;
}
