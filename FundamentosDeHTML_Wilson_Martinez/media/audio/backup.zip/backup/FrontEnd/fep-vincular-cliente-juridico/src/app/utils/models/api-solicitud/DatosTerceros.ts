import { Participante } from './Participante';

export class DatosTerceros extends Participante {

    constructor() {
        super();
    }
}
