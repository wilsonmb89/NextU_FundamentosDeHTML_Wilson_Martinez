export class DocumentoGenerado {
  nombre: string;
  nombreArchivo: string;
  upload: boolean;
  view: boolean;
}
