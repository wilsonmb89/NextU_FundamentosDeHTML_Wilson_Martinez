export class DocumentoSoporte {
  nombre: string;
  estado: string;
  origen: string;
  [key: string]: any;
}
