export class Estradata {
    idEstradata: number;
    nombreLista: string;
    porcentaje: string;
    nacionalidad: string;
    identificacion: string;
}
