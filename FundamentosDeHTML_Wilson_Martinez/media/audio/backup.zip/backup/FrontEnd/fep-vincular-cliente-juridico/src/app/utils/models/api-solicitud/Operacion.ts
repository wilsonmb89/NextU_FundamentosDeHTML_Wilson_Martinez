export class Operacion {
    idOperacionInternacional: number;
    id: number;
    name: string;
    checked: boolean;
}
