import { DatosRiesgo } from './DatosRiesgo';
import { DocumentoSoporte } from './DocumentoSoporte';
import { DatosAML } from './DatosAML';
import { DatosDocumento } from './DatosDocumento';

export class Participante {
  idParticipante: number;
  nombre: string = null;
  tipoDocumento: string = null;
  numeroDocumento: string = null;
  isCliente: boolean = null;
  documentosSoporte: Array<DocumentoSoporte>;
  datosDocumento: DatosDocumento = null;
  datosRiesgo: DatosRiesgo;
  datosAml: DatosAML;
  datosCumplimiento: DatosAML;

  constructor() { }
}
