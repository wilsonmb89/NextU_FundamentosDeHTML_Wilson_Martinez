export class DatosActualizacionPantallas {
  representanteLegal: string = null;
  ordenantes: string = null;
  accionistas: string = null;
  terceros: string = null;
  infoAdicional: string = null;
}
