import { Variables } from './Variables';

export class DocumentRules {
    decisionId: string;
    variables: Variables;
}
