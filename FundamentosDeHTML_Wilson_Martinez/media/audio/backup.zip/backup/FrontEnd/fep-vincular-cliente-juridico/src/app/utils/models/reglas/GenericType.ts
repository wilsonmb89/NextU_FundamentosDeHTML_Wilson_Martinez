export class GenericType {
    value: any;
    type: string;
}
