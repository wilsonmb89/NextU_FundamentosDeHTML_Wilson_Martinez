import { GenericType } from './GenericType';

export class Variables {
  [key: string]: GenericType;
}
