export const environment = {
    enviroment: "PRE",
    production: false,
    API_GATEWAY: ""
};
