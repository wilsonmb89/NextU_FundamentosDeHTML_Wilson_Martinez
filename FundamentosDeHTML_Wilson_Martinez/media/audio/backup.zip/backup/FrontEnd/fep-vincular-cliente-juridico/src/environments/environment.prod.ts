export const environment = {
  enviroment: "PROD",
  production: true,
  API_GATEWAY: ""
};
